Agentk version 1.0b4

This package contains an extension to the Tcl/Tk widget set.  It requires
Tcl/Tk 8.1 (or a later version) and requires Jeff Hobbs' megawidget creation
package (included) to operate.  Note that this is a beta version and
contains some known bugs.

Several scripts in the demo directory showcase various Agentk widgets. See
the "README" file in that directory for more details.

The fade.tcl, roll, ticker.tcl, files contain the three widgets currently
included in Agentk.  See "manual.txt" for explanations on how to use them.

The widget directory contains Jeff Hobbs' megawidget creation package.  The
"wkludge.tcl" file is necessary to source in the files in this directory
(only necessary once in each application).

Updates will be posted to the Agentk Web page at:
    http://www.cc.gatech.edu/grads/m/Scott.McCrickard/agentk/

Please email any questions or comments to
    D. Scott McCrickard, mccricks@cc.gatech.edu
    College of Computing
    Georgia Institute of Technology
    Atlanta, GA 30332-0280
    U.S.A.
