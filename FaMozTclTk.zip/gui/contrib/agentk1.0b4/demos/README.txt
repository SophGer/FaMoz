Unix scripts in this directory showcase various Agentk widgets. Use
"-visual truecolor" on a TrueColor display to avoid a Tk color flickering
bug.  You may need to change the path names for some of the demos.  The
Agentk demo programs are:

NewsAgent/
	A simple news agent. See README in that directory for details.

checklpq
	Unix printer queue checker using a roll widget.

demo-fade
	Fade widgets that show images and captions in sync.

demo-navbar
	Navigation bar widget that highlights names in a list.

demo-roll
	Displays the script itself in a roll widget.

demo-ticker
	Displays the script itself in a ticker widget.

tkwatch
	Displays stock quotes, sports scores, news headlines, and more.

