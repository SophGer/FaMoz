NewsAgent demo by Emily Stretch
	Demonstrates the fade and ticker widgets

Executable:	NewsAgent
		(cd to this directory to run it)
