The tkwatch interface displays weather data, stock quotes, news
headlines, and sports scores using a fade, ticker, or list display.
The purpose of the interface is to help users maintain awareness of
various types of dynamic information.  It is not intended as a
replacement for traditional browsers but rather as a tool to augment
them.

To use the tool, enter the command "tkwatch" on Unix systems or start
the programs tkmon and tkdisp on Windows systems.

It is fully functional from a variety of UNIX platforms: Suns, SGIs,
etc.  One potential issue: tkwatch is not fully functional with the
xhost access control program.  If you use xhost, you will not be able
to reconfigure the list of items being monitored after dismissing the
configuration window.  It is mostly functional from Windows platforms,
but it is recommended that the configuration screens be iconized and
not dismissed to allow future configuration.

The available displays are the fade, the ticker, and the list.  The
fade display fades one piece of information out while fading the next
one in.  To jump rapidly from one item to another, click on the fade
display with the mouse.  The ticker display moves information across
the screen.  The mouse can be used to grab and move the ticker display.
The list display shows all selected information in a list.

The animated displays (fade and ticker) provide an option for
italicizing changes to the information.  For example, if a score changes
or a new news article appears, it is italicized.  In addition, the shadow
history option presents the previous information state in the background
of the display.  This allows the user to see the previous value of, say,
a stock quote or temperature reading.  The animated displays also allow
speed control.  Note that all of the display types allow the user to
select the font type and size as well as foreground and background color.

The types of information that can be monitored include weather data,
stock quotes, news headlines, and sports scores.  For the weather data,
you can select from a list of cities across the southeast and the nation.
The stock quotes ask you to enter one or more ticker symbols (separated
by a space) - the symbols can be found on Web sites like Yahoo.  The news
headlines allow you to select from various topics.  The sports scores
allow the user to select sports games of interest.  The scores are
divided up by sport - a user can select individual games or all games for
a sport from the cascading menus.

Upon startup, two control panels will appear, one for the display
options and one for the informational options.  These can be recalled
at any time by clicking on BUTTON-3 in the display.  Any of the windows
(including the display) can be dismissed using the "q" key.


CONFIGURATION:

To set up tkwatch, update the three programs (tkwatch, tkmon,tcl,
and tkdisp.tcl) to point to the correct wish versions and tkwatch
home directories.


BUGS/FEATURES:

Running tkwatch multiple times can cause interference between the
programs.

Data is stored in a .tkwatch directory in the user's home directory.

