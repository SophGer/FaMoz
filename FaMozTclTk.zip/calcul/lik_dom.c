#include <math.h>
#include <stdio.h>
#include "nrutil.h"
#include "read.h"
#include "sort.h"
#include "genetic.h"
#include "likely.h"

/**************************************************************************

Program to tabulate possible parent pairs, and log-likelihoods, for given
sets of juveniles, potential fathers, and potential mothers.
Ordered to find best 4 mums, best 4 dads, best 4 pairs.
Includes possibility of X-linked loci.

Modified from earlier programs; July 1996

Programme modifi� pour consid�rer des hermaphrodites, et int�grer possibles 
autof�condations 25/11/98

*** Pourcentage d'erreur ajout� dans les calculs 26/11/98
(inspir� de Marshall et al 1998)
utilis� en lan�ant le programme suivi de < fichier
le fichier contient (AFLP) 
nb_bandes  freq_bande1 freq_bande2 etc...
nb_parents nb_desc
num�ro_parent1 etat_bande_1 �tat_bande_2_ etc... 

Donne les 8 meilleurs parents et couples dans l'ordre.
Modifi� le 18/12/98 pour prendre les ln de la vraisemblance

7/1/99 Pour la recherche de parent� avec marqueurs dominants type AFLP
fichier d'exemple laflp : lik_aflp < laflp

Ne fais les calculs de vraisemblance que s'il n'y a aucune donn�e manquante
(indiqu�e par (-5))

28/9/00 Modified with malloc for FaMoz.tcl
***************************************************************************/

extern double rans();


main (int argc, char *argv[]) {
  int nloc, i,j,k, kk,tp1,tp2, *nallc;  
  int nkid,npar, npop, *listp, npopp, nb, cyt, **kidcyt, **parcyt;
  int *name_kid, *name_par, **kidgen, **pargen;
  double  E, F, *pf, **pfc, *best_pars, *best_pairs[2], *miss_par, *missm_pair, *loclod, *loclod1, *delta, *deltaC, deltamax;
  double *score, *pcore, cc, bc, pc;

  E=atof(argv[1]);
  nb=atoi(argv[2]);
  cyt=atoi(argv[3]);
  F=atof(argv[4]);

  scanf ("%d", &nloc);
  pf=(double *)malloc((nloc+1) * sizeof(double));
  if (cyt > 0) nallc=(int *)malloc((cyt+1)*sizeof(int));

  read_loci_dom (nloc, cyt, nallc, pf, &pfc);

  printf("\n Number of loci: %d",nloc);  
  printf("\n Among them, number of cytoplasmic markers: %d",cyt);
  scanf ("%d %d", &npar, &nkid);
  printf ("\n Number of parents: %d offspring: %d\n", npar,nkid);
  
  printf("\n Lod calculation error %f, Heterozygote deficit %f\n", E, F);    
  printf("\n Number of best parent / pair displayed: %d\n", nb); 
  printf ("\n For each likely parent: ");
  printf ("\n -Parent name -Parent score -Parent delta score");
  printf ("\n -Nb of missing locus in parent / nb of loci with a > 0 contribution in score\n");
  printf ("\n For each likely parent pair: ");
  printf ("\n -Names of parents -Parent pair score -Parent pair delta score");
  printf ("\n -Nb of loci with a > 0 contribution in score/ nb of pair-offspring mismatch among them\n");

  listp=(int *)malloc((npar+1)*sizeof(int));
  name_kid=(int *)malloc((nkid+1)*sizeof(int));
  name_par=(int *)malloc((npar+1)*sizeof(int));
  kidgen=(int **)malloc((nkid+1) * sizeof(int *));
  pargen=(int **)malloc((npar+1) * sizeof(int *));
  best_pars=(double *)malloc((nb+2)*sizeof(double));
  best_pairs[0]=(double *)malloc((nb+2)*sizeof(double));
  best_pairs[1]=(double *)malloc((nb+2)*sizeof(double));
  score=(double *)malloc((nb+2)*sizeof(double));
  pcore=(double *)malloc((nb+2)*sizeof(double));
  delta=(double *)malloc((nb+2)*sizeof(double));
  deltaC=(double *)malloc((nb+2)*sizeof(double));
  miss_par=(double *)malloc((nb+2)*sizeof(double));
  missm_pair=(double *)malloc((nb+2)*sizeof(double));
  loclod=(double *)malloc((nb+2)*sizeof(double));
  loclod1=(double *)malloc((nb+2)*sizeof(double));
  kidcyt=(int **)malloc((nkid+1) * sizeof(int *));
  parcyt=(int **)malloc((npar+1) * sizeof(int *));
  
  for (i=1; i<=nkid; i++)
    {
      kidgen[i]=(int *)malloc((nloc+1) * sizeof(int));      
      kidcyt[i]=(int *)malloc((cyt+1) * sizeof(int));
    }
  for (i=1; i<=npar; i++)
    {
      pargen[i]=(int *)malloc((nloc+1) * sizeof(int));  
      parcyt[i]=(int *)malloc((cyt+1) * sizeof(int));
    }
  
  read_gen_dat_dom (npar, nkid, name_kid, name_par, nloc, cyt, kidgen, pargen, kidcyt, parcyt);


/* Recherche des parents individuels les plus probables*/
  for (i=1; i<=nkid; ++i)
    {
      printf ("\n kid %d :", name_kid[i] ); 
      printf("( %.0f missing locus on %d nuclear loci)", missing_dom(kidgen[i], nloc-cyt), nloc-cyt);  
      npopp=0; npop=0;  bc=1.0E6; pc = 1.0E6; /* Number Possible Parent / Pairs */
      for (k=0; k< nb+1; ++k) {
	score[k]=0.0; 
	delta[k]=0.0; deltaC[k]=0.0;
	best_pars[k] =0; pcore[k]=0.0;
	best_pairs[0][k]=0; best_pairs[1][k]=0; 
	miss_par[k] =0; missm_pair[k] =0; 
	loclod[k] =0; loclod1[k] =0;
      }
      
      for (j=1; j<=npar; ++j) {
	/*printf ("\n parent %d :", name_par[j] );  */
	cc = uparchk_dom(nloc-cyt, kidgen[i],pargen[j], pf, E, F); /* proba maternit�:non maternit�*/
	if (cyt > 0) cc+=likr_cyt(cyt, kidcyt[i], parcyt[j], pfc, E, nallc);
	/*           printf("\n score : %f",cc); */
	if (cc > 0.0 && finite(cc)==1) { 
	  ++npop; 
	  listp[npop]=j; /*rang de tous les parents � proba > 0,npop observations*/
	  if (npop < nb+1) {
	    best_pars[npop] = name_par[j]; 
	    score[npop]=cc; 
	    miss_par[npop]=missing_dom(pargen[j], nloc-cyt);
	    loclod[npop]=loc_lod_1par_dom(nloc-cyt, kidgen[i], pargen[j], pf, E, F);
	    if (cc < bc)  bc = cc; 
	  } /* bc sera le score min parmi les 8 premiers >0 */
	  else {
	    if (cc > bc) { /*score sup�rieur au min pr�c�dent*/
	      k = dexmin(score, nb); /* rang du score minimum parmi les 10*/
	      best_pars[k] = name_par[j];  /*on remplace la m�re k  ...  */
	      score[k] = cc;               /* par la j, qui est meilleure */ 
	      miss_par[k]=missing_dom(pargen[j], nloc-cyt);
	      loclod[k]=loc_lod_1par_dom(nloc-cyt, kidgen[i], pargen[j], pf, E, F);
	      bc = valmin(score, nb); 
	    }
	  }  /*nouveau score min*/
	}
      }
      /* � la fin on a les 10 meilleures des nmum*/
      
      /* Ins�rer un tri sur best_pars[k] et score[k], 1<=k<=10 */
      sort4(nb,score,best_pars,miss_par, loclod);
      deltamax=score[nb];
      for (k=nb; k>=1; --k){ if (k==nb) delta[k]=deltamax; else if (k<nb && score[k]>0) delta[k]=deltamax-score[k];}
      /*       printf ("\n"); */
      /*       for (k=nb; k>=1; --k) printf ("\t %.0f",best_pars[k]); printf ("\n"); */
      /*       for (k=nb; k>=1; --k) printf ("\t %.2g",score[k]); printf ("\n"); fflush(stdout); */
      /*       for (k=nb; k>=1; --k) printf ("\t %.0f/%.0f", miss_par[k], loclod[k]);  printf ("\n");  */
      
      printf ("\n %d likely parent(s)", npop);
      if (npop>0) {
	if(npop > nb) 
	  for (k=nb; k>=1; k--) {
	    printf("\n %d \t %.0f \t %.2f \t %.2f \t", name_kid[i], best_pars[k], score[k], delta[k]);  
	    printf ("%.0f/%.0f ", miss_par[k], loclod[k]);  
	  }
	else 
	  for (k=nb; k>=nb-npop+1; k--) { 
	    printf("\n %d \t %.0f \t %.2f \t %.2f \t ", name_kid[i], best_pars[k], score[k], delta[k]);  
	    printf ("%.0f/%.0f ", miss_par[k], loclod[k]);  
	  } 
      }
      printf ("\n");
      for (j=1; j<=npar; ++j)
	for (k=1; k<=npar; ++k) {
	  /*printf("\nname_par[j] %d name_par[k] %d", name_par[j], name_par[k]); */
	  cc = pparchk_dom(nloc-cyt, kidgen[i],pargen[j],pargen[k], pf, E, F);
	}
      /* Recherche des couples de parents les plus probables*/
      pc=1.0E6; for (k=0; k< nb+1; ++k)  pcore[k]=0.0; 
      for (j=1; j<=npop; ++j) {
	tp1 = listp[j];
	if (npop > 0) {
	  for (kk=1; kk<=npop; ++kk) {
	    tp2 = listp[kk];
	    if (tp2>=tp1) {
	      cc = pparchk_dom(nloc-cyt, kidgen[i],pargen[tp1],pargen[tp2], pf, E, F); /*dans boucle en j*/
	      if (cyt > 0) cc+=likr_pair_cyt(cyt, kidcyt[i],parcyt[tp1],parcyt[tp2], pfc, E, nallc);
	      if (cc > 0.0 && finite(cc)==1) 
		{
		  ++npopp; 
		  if (npopp < nb+1) {
		    best_pairs[0][npopp] = *(name_par+tp1); 
		    best_pairs[1][npopp] =*(name_par+tp2); 
		    pcore[npopp]=cc; 
		    missm_pair[npopp]=mismatch2_dom(kidgen[i],pargen[tp1],pargen[tp2],nloc-cyt);
		    loclod1[npopp]=loc_lod_2par_dom(nloc-cyt, kidgen[i], pargen[tp1], pargen[tp2], pf, E, F);
		    if (cc < pc)  pc = cc; 
		  } 
		  else {
		    if (cc > pc) {
		      k = dexmin(pcore, nb);
		      best_pairs[0][k] =  *(name_par+tp1); 
		      best_pairs[1][k] =  *(name_par+tp2); 
		      pcore[k] = cc;
		      missm_pair[k]=mismatch2_dom(kidgen[i],pargen[tp1],pargen[tp2],nloc-cyt);
		      loclod1[k]=loc_lod_2par_dom(nloc-cyt, kidgen[i], pargen[tp1], pargen[tp2], pf, E, F);
		      pc = valmin(pcore, nb); 
		    }
		  }
		  
		}/* printf ("\n pc: %f \t",pc); */ 
	    }
	  }
	}
      } 
      
      sort5(nb,pcore,best_pairs[0],best_pairs[1], missm_pair, loclod1);			
      deltamax=pcore[nb];
      for (k=nb; k>=1; --k){ if (k==nb) deltaC[k]=deltamax; else if (k<nb && pcore[k]>0) deltaC[k]=deltamax-pcore[k];}
      /*       for (k=nb; k>=1; --k)  */
      /* 	printf ("\t (%3.0f %3.0f)",best_pairs[0][k], best_pairs[1][k]); printf ("\n");	 */
      /* 	for (k=nb; k>=1; --k) printf ("\t    %-7.2g",pcore[k]); printf ("\n"); */
      /* 	for (k=nb; k>=1; --k) printf ("\t  %3.0f /%2.0f", loclod1[k], missm_pair[k]);  printf ("\n");  */
      
      /*  printf ("\n number of possible parents, pairs: %5d %5d \n", */
      /* 	           npop, npopp); fflush(stdout); */
      printf (" %d likely parent pair(s)", npopp);
      if (npopp>0) {
	if(npopp > nb) 
	  for (k=nb; k>=1; k--) {
	    printf("\n %d \t (%.0f %.0f) \t %.2f \t %.2f \t ", name_kid[i], best_pairs[0][k], best_pairs[1][k], pcore[k], deltaC[k]);  
	    printf ("%.0f/%.0f ", loclod1[k], missm_pair[k]);  
	  }
	else for (k=nb; k>=nb-npopp+1; k--) { 
	  printf("\n %d \t (%.0f %.0f) \t %.2f \t %.2f \t ", name_kid[i], best_pairs[0][k], best_pairs[1][k], pcore[k], deltaC[k]);  
	  printf ("%.0f/%.0f ", loclod1[k], missm_pair[k]);  
	} 
      }	
      printf ("\n");
    }  
  
  return(0);
  
}
