#include <math.h>
#include <stdio.h>
#include "nrutil.h"
#include "read.h"
#include "sort.h"
#include "genetic.h"
#include "likely.h"

/**************************************************************************
31/10/00 Calculate father likelihood for dominant markers
***************************************************************************/

extern double rans();


main (int argc, char *argv[]) {
  int nloc, i,j,k, ii, *nallc;  
  int nkid,npar, npod, nb, mere, cyt, cytmater;
  int *name_mum, *name_kid, *name_par, **kidgen, **pargen, **kidcyt, **parcyt;
  double  E, F, *pf, **pfc, *best_dads, *miss_dad, *missm_dad, *loclod, *delta, deltamax; 
  /* nb missing data and missmatch for each dad and dad/offsp and number of loci with no missing data*/
  double *score, cc, bc;

  E=atof(argv[1]);
  nb=atoi(argv[2]);
  cyt=atoi(argv[3]);
  cytmater=atoi(argv[4]);
  F=atof(argv[5]);

  scanf ("%d", &nloc);
  pf=(double *)malloc((nloc-cyt+1) * sizeof(double));
  if (cyt > 0) nallc=(int *)malloc((cyt+1)*sizeof(int));

  read_loci_dom (nloc, cyt, nallc, pf, &pfc);

  printf("\n Number of loci: %d",nloc);
  printf("\n Among them, number of cytoplasmic markers: %d",cyt);
  scanf ("%d %d", &npar, &nkid);
  printf ("\n Number of parents: %d offspring: %d\n", npar,nkid);
  printf("\n Lod calculation error %f, Heterozygote deficit %f\n", E, F);    
  printf("\n Number of best fathers displayed: %d\n", nb); 
  printf("\n For each offspring and each likely father: "); 
  printf("  Kid n� / mother / likely father / lod score / delta");
  printf ("\n -Nb of missing locus in father / nb of loci with a > 0 contribution in score ");
  printf("\n  / nb of father-offspring mismatch among them\n");

  name_kid=(int *)malloc((nkid+1)*sizeof(int));
  name_par=(int *)malloc((npar+1)*sizeof(int));
  name_mum=(int *)malloc((nkid+1)*sizeof(int));
  kidgen=(int **)malloc((nkid+1) * sizeof(int *));
  pargen=(int **)malloc((npar+1) * sizeof(int *));
  best_dads=(double *)malloc((nb+2)*sizeof(double));
  score=(double *)malloc((nb+2)*sizeof(double));
  delta=(double *)malloc((nb+2)*sizeof(double));
  miss_dad=(double *)malloc((nb+2)*sizeof(double));
  missm_dad=(double *)malloc((nb+2)*sizeof(double));
  loclod=(double *)malloc((nb+2)*sizeof(double));
  kidcyt=(int **)malloc((nkid+1) * sizeof(int *));
  parcyt=(int **)malloc((npar+1) * sizeof(int *));

  for (i=1; i<=nkid; i++)
    {
      kidgen[i]=(int *)malloc((nloc+1) * sizeof(int));      
      kidcyt[i]=(int *)malloc((cyt+1) * sizeof(int));
    }
  for (i=1; i<=npar; i++)
    {
      pargen[i]=(int *)malloc((nloc+1) * sizeof(int));  
      parcyt[i]=(int *)malloc((cyt+1) * sizeof(int));
    }
    

  read_gen_dat_pat_dom (npar, nkid, name_kid, name_par, name_mum, nloc, cyt, kidgen, pargen, kidcyt, parcyt);


  /* Recherche des p�res  les plus probables*/
  for (i=1; i<=nkid; ++i)
    {
      printf ("\n kid %d :", name_kid[i] );
      printf("( %.0f missing locus on %d nuclear loci)", missing_dom(kidgen[i],(nloc-cyt)),(nloc-cyt));  
      npod=0; bc=1.0E6; /* Number Possible fathers */
      for (k=0; k< nb+1; ++k) 
	{
	  best_dads[k] =0; 
	  score[k]=0.0;
	  miss_dad[k] =0; 
	  missm_dad[k] =0; 
	  loclod[k] =0;
	}
      
      for (j=1; j<=npar; ++j)
	{
	  for (ii=1;ii<=npar;++ii) 
	    {
	      if (name_par[ii]==name_mum[i]) mere=ii; 
	    }
	  cc = pater_dom((nloc-cyt), kidgen[i],pargen[mere],pargen[j], pf, E, F); /* proba father:non father*/
	  if (cyt > 0 && cytmater==0) cc+=likr_pat_cyt(cyt, kidcyt[i], parcyt[j], pfc, E, nallc);
	  /*           printf("\n score : %f",cc); */
	  if (cc > 0.0 && finite(cc)==1) 
	    { 
	      ++npod; 
	      if (npod < nb +1) 
		{
		  best_dads[npod] = name_par[j]; 
		  score[npod]=cc; 
		  miss_dad[npod]=missing_dom(pargen[j], (nloc-cyt));
		  missm_dad[npod]=mismatch2_dom(kidgen[i], pargen[mere], pargen[j],(nloc-cyt));
		  loclod[npod]=loc_lod_pater_dom((nloc-cyt), kidgen[i], pargen[mere], pargen[j], pf, E, F);		  
		  if (cc < bc)  bc = cc; 
		} /* bc sera le score min parmi les 8 premiers >0 */
	      else
		{
		  if (cc > bc) /*score sup�rieur au min pr�c�dent*/
		    { 
		      k = dexmin(score, nb); /* rang du score minimum parmi les nb*/
		      best_dads[k] = name_par[j];  /*on remplace le p�re k  ...  */
		      score[k] = cc;               /* par le j, qui est meilleur */ 
		      miss_dad[k]=missing_dom(pargen[j], (nloc-cyt));
		      missm_dad[k]=mismatch2_dom(kidgen[i], pargen[mere], pargen[j],(nloc-cyt));
		      loclod[k]=loc_lod_pater_dom((nloc-cyt), kidgen[i], pargen[mere], pargen[j], pf, E, F);		  
		      bc = valmin(score, nb); 
		    }
		}  /*nouveau score min*/
	    }
	}
      /* � la fin on a les nb meilleurs p�re */
      
      /* Ins�rer un tri sur best_dads[k] et score[k], 1<=k<=nb */
      sort5(nb,score,best_dads,miss_dad, missm_dad, loclod);			
      deltamax=score[nb];
      for (k=nb; k>=1; --k){ if (k==nb) delta[k]=deltamax; else if (k<nb && score[k]>0) delta[k]=deltamax-score[k];}
      /*       printf ("\n"); */
      /*       for (k=nb; k>=1; --k) printf ("\t %.0f",best_dads[k]); printf ("\n"); */
      /*       for (k=nb; k>=1; --k) printf ("\t %.2g",score[k]); printf ("\n");  */
      /*       for (k=nb; k>=1; --k) printf ("\t %.0f/%.0f/%.0f", miss_dad[k], loclod[k], missm_dad[k]);  printf ("\n");  */
      printf (" %d likely fathers", npod); 
      if  (npod > 0 ) 
	{ 
	  if(npod > nb) 
	    for (k=nb; k>=1; k--)   
	      { 
		printf ("\n %d \t %d \t  %.0f \t %.2f \t %.2f \t", name_kid[i], name_mum[i], best_dads[k], score[k], delta[k]);  
		printf ("%.0f/%.0f/%.0f ", miss_dad[k], loclod[k], missm_dad[k]);  
	      } 
	  else for (k=nb; k>=nb-npod+1; k--)   
	    { 
	      printf ("\n %d \t %d \t  %.0f \t %.2f \t %.2f \t", name_kid[i], name_mum[i] , best_dads[k], score[k], delta[k]);  
	      printf ("%.0f/%.0f/%.0f ", miss_dad[k], loclod[k], missm_dad[k]);  
	    } 
	}
    }
  printf ("\n");
  return(0);
}
