#include <math.h>
#include <stdio.h>
#include "nrutil.h"
#include "sort.h"
#include "read.h"
#include "genetic.h"
#include "likely.h"

/**************************************************************************

Program to tabulate possible parent pairs, and log-likelihoods, for given
sets of juveniles, potential fathers, and potential mothers.
Ordered to find best 4 mums, best 4 dads, best 4 pairs.
Includes possibility of X-linked loci.

Modified from earlier programs; July 1996

Programme modifi� pour consid�rer des hermaphrodites, et int�grer possibles 
autof�condations 25/11/98

*** Pourcentage d'erreur ajout� dans les calculs 26/11/98
(inspir� de Marshall et al 1998)
utilis� en lan�ant le programme suivi de < fichier
le fichier contient 
nb_loc nb_all_loc1 0 freq_all1_loc1 freq_all2_loc2.... nb_all_loc2 0 etc...
nb_parents nb_desc
num�ro_parent1 all1_loc1 all2_loc1 etc... 
le fichier likh est un fichier d'exemple pour ce programme
Donne les 8 meilleurs parents et couples dans l'ordre.
Modifi� le 18/12/98 pour prendre les log 
de la vraisemblance
8/3/99 Fait le test sur des donn�es lues dans un fichier (exemple, descendances
maternelles R. Streiff, pour test (testpm.txt)) renvoie les parents probables
de vraisemblances >= SEUIL_P et les couples probables tels que les parents aient une 
vraisemblances >= SEUIL_P et la vraisemblances du couple >= SEUIL_C
15/11/00 Adapted to FaMoz
***************************************************************************/

extern double rans();

main (int argc, char *argv[])
{
  int i,j,k,l, kk,jj,tp1,tp2, npop, *listp, npopp, nb, nb_off_1par, nb_off_2par, miss, test_type;
  int nloc, *nall, cyt, *nallc, nkid, npar, *name_kid, *name_par, **kidcyt, **parcyt, *par1, *par2; 
  double *best_pars, *best_pairs[2], *miss_par, *match_par, *match_pair, *loclod, *loclod1, *delta, *deltaC, deltamax;
  double **pf, **pfc, E, SEUIL_P, SEUIL_C, SEUIL_dP, SEUIL_dC, *score, *pcore, cc, bc, pc, F, x, y;
  Geno **kidgen, **pargen;
  FILE *f, *g;



  /* Reading arguments */
  E = atof(argv[1]);        /* mistyping percentage*/
  nb=atoi(argv[2]);         /* Number of most likely displayed */
  cyt=atoi(argv[3]);
  F = atof(argv[4]); 
  miss=atoi(argv[5]);
  test_type=atoi(argv[6]); /* test type 1: test on lod scores 2: test on delta 3: test on both values*/
  if (test_type==1) {
    SEUIL_P=atof(argv[7]);  /* Lod-score threshold to choose a parent as the true one */
    SEUIL_C=atof(argv[8]);
  }
  else if  (test_type==2) {
    SEUIL_dP=atof(argv[7]);  /* Delta threshold to choose a parent as the true one */
    SEUIL_dC=atof(argv[8]);}
  else if  (test_type==3){
    SEUIL_P=atof(argv[7]);  /* Lod-score threshold to choose a parent as the true one */
    SEUIL_C=atof(argv[8]);  /* Delta threshold to choose a parent as the true one */
    SEUIL_dP=atof(argv[9]);  /* Delta threshold to choose a parent as the true one */
    SEUIL_dC=atof(argv[10]);}

  scanf ("%d", &nloc);
  nall=(int *)malloc((nloc-cyt+1)*sizeof(int));
  if (cyt > 0) nallc=(int *)malloc((cyt+1)*sizeof(int));
  read_loci (nloc, nall, &pf, cyt, nallc, &pfc);
  
  printf("\n Number of loci: %d",nloc);
  printf(" of which %d cytoplasmic markers",cyt);
  scanf ("%d %d", &npar, &nkid);    
  printf ("\n Number of parents: %d offspring: %d", npar,nkid);
  printf("\n Lod calculation error: %f, Heterozygote deficit %f", E, F);
  if (test_type==1) 
    printf("\n Lod-score thresholds to choose a parent as the true one = %.2f, parent pair = %.2f ", SEUIL_P, SEUIL_C);
  else if (test_type==2) 
    printf("\n Delta threshold to choose a parent as the true one = %.2f, parent pair = %.2f ", SEUIL_dP, SEUIL_dC);
  else if (test_type==3) 
    printf("\n Thresholds to choose a parent/parent pair as the true one, Lod-score = %.2f / %.2f, Delta = %.2f / %.2f\n", SEUIL_P, SEUIL_C, SEUIL_dP, SEUIL_dC);

  printf("\n Number of best parent / pair displayed: %d\n\n", nb); 
  printf (" For each likely parent:\n");
  printf ("  nb of missing locus / nb of loci with a non null contribution in score / nb of parent-offspring mismatch among them\n");
  printf (" For each likely parent pair:\n");
  printf ("  nb of loci with a non null contribution in score / nb of pair-offspring mismatch among them\n");



  /*Allocation*/
  listp=(int *)malloc((npar+1)*sizeof(int));
  name_kid=(int *)malloc((nkid+1)*sizeof(int));
  name_par=(int *)malloc((npar+1)*sizeof(int));
  kidgen=(Geno **)malloc((nkid+1) * sizeof(Geno *));
  pargen=(Geno **)malloc((npar+1) * sizeof(Geno *));
  best_pars=(double *)malloc((nb+2)*sizeof(double));
  best_pairs[0]=(double *)malloc((nb+2)*sizeof(double));
  best_pairs[1]=(double *)malloc((nb+2)*sizeof(double));
  score=(double *)malloc((nb+2)*sizeof(double));
  pcore=(double *)malloc((nb+2)*sizeof(double));
  delta=(double *)malloc((nb+2)*sizeof(double));
  deltaC=(double *)malloc((nb+2)*sizeof(double));
  miss_par=(double *)malloc((nb+2)*sizeof(double));
  match_par=(double *)malloc((nb+2)*sizeof(double));
  match_pair=(double *)malloc((nb+2)*sizeof(double));
  loclod=(double *)malloc((nb+2)*sizeof(double));
  loclod1=(double *)malloc((nb+2)*sizeof(double));
  kidcyt=(int **)malloc((nkid+1) * sizeof(int *));
  par1=(int *)malloc((nkid+1) * sizeof(int));
  par2=(int *)malloc((nkid+1) * sizeof(int));
  parcyt=(int **)malloc((npar+1) * sizeof(int *));

  for (i=1; i<=nkid; i++) 
    {
      par1[i]=0;
      par2[i]=0;
      kidgen[i]=(Geno *)malloc((nloc-cyt+1) * sizeof(Geno));
      kidcyt[i]=(int *)malloc((cyt+1) * sizeof(int));
    }
  for (i=1; i<=npar; i++) 
    {
      pargen[i]=(Geno *)malloc((nloc-cyt+1) * sizeof(Geno));
      parcyt[i]=(int *)malloc((cyt+1) * sizeof(int));
    }
  read_gen_dat(npar, nkid, name_kid, name_par, nloc, cyt, kidgen, pargen, kidcyt, parcyt);
  
  f = fopen ("respar1", "w");  
  g = fopen ("respar2", "w");  
  printf("\n ***** Compact results will be given in file \"respar1\"");
  printf(" for offspring with one parent\n\t\t\t \"respar2\" for offspring with a pair of parents *****\n");
  printf("\t\t\t  (Number of observations at the beginning of the files)");
  /*   if ( f != NULL) fprintf (f, "\n kid_n� nb_missing_alleles best_parent");   */
  /*   if ( f != NULL) fprintf (f, "\n \t nb_likely parent_pairs best_parent_pair\n"); */
  nb_off_1par=0;  nb_off_2par=0;

  for (i=1; i<=nkid; ++i){
      printf ("\n Kid number %d", name_kid[i]);
      printf(" ( %.0f missing data on %d alleles)\n", missing(kidgen[i], nloc-cyt), 2*(nloc-cyt));  


      npopp=0; npop=0;  bc=1.0E6; pc = 1.0E6;/* Number Possible Parent / Pairs */
      
      /* Calcul des vraisemblances des parents pour chaque descendant */
      
      for (k=0; k< nb+1; ++k) 
	{
	  score[k]=0.0; 
	  delta[k]=0.0; deltaC[k]=0.0;
	  best_pars[k] =0; pcore[k]=0.0;
	  best_pairs[0][k]=0; best_pairs[1][k]=0;
	  miss_par[k] =0; 
	  match_par[k] =0; match_pair[k] =0; 
	  loclod[k] =0; loclod1[k] =0;
	}
      for (j=1; j<=npar; ++j)
	{
	  cc = uparchk(nloc-cyt, *(kidgen+i), pargen[j], pf, E, F, nall, miss);  /* proba maternit�:non maternit�*/
	  if (cyt > 0) cc+=likr_cyt(cyt, kidcyt[i], parcyt[j], pfc, E, nallc);
	  if (cc > 0.0 && finite(cc)==1)
	    {
	      ++npop; 
	      listp[npop]=j; /*rang de tous les parents � proba > 0,npop observations*/
	      if (npop < nb+1) 
		{
		  best_pars[npop] = name_par[j]; 
		  score[npop]=cc; 
		  miss_par[npop]=missing(pargen[j], nloc-cyt);
		  match_par[npop]=match1(kidgen[i], pargen[j],nloc-cyt);
		  loclod[npop]=loc_lod_1par(nloc-cyt, kidgen[i], pargen[j], pf, E, F, nall, miss);
		  if (cc < bc)  bc = cc;
		} /* bc sera le score min parmi les 8 premiers >0 */
	      else
		{
		  if (cc > bc) /*score sup�rieur au min pr�c�dent*/
		    {
		      k = dexmin(score, nb); /* rang du score minimum parmi les 8*/
		      best_pars[k] = name_par[j];  /*on remplace la m�re k  ...  */
		      score[k] = cc;               /* par la j, qui est meilleure */ 
		      miss_par[k]=missing(pargen[j], nloc-cyt);
		      match_par[k]=match1(kidgen[i], pargen[j],nloc-cyt);
		      loclod[k]=loc_lod_1par(nloc-cyt, kidgen[i], pargen[j], pf, E, F, nall, miss);
		      bc = valmin(score, nb);
		    }
		}  /*nouveau score min*/
	    } 
	}                                  /* � la fin on a les 8 meilleurs*/
      
      /* Ins�rer un tri sur best_pars[k] et score[k], 1<=k<=8 */
      sort5(nb,score,best_pars,miss_par, match_par, loclod);
      deltamax=score[nb];
      for (k=nb; k>=1; --k){ if (k==nb) delta[k]=deltamax; else if (k<nb && score[k]>0) delta[k]=deltamax-score[k];}

      /* Affichage */
      jj=0;
      kk=0;
      for (k=nb; k>=1; --k){
	if (test_type==1){
	  if (score[k] > SEUIL_P) {
	    ++jj;
	    printf ("\tLikely parent n� %d: %5.0f\tscore:  %5.2f",jj, best_pars[k], score[k]);
	    printf ("\t %3.0f/%3.0f/%3.0f", miss_par[k], loclod[k], nloc-cyt-match_par[k]);  printf ("\n"); 
	    if (kk==0)  { par1[i] = best_pars[k]; kk+=1;} 
	    /*if ( f != NULL && kk==0) { fprintf (f, "\n %d %.0f", name_kid[i], best_pars[k]); kk+=1;}  */
	  }
	}      
	else if (test_type==2){
	  if (delta[k] > SEUIL_dP) {
	    ++jj;
	    printf ("\tLikely parent n� %d: %5.0f\tscore:  %5.2f",jj, best_pars[k], delta[k]);
	    printf ("\t %3.0f/%3.0f/%3.0f", miss_par[k], loclod[k], nloc-cyt-match_par[k]);  printf ("\n"); 
	    if (kk==0)  { par1[i] = best_pars[k]; kk+=1;} 
	    /*if ( f != NULL && kk==0) { fprintf (f, "\n %d %.0f", name_kid[i], best_pars[k]); kk+=1;}  */
	  }
	}      
	else if (test_type==3){
	  if (score[k] > SEUIL_P && delta[k] > SEUIL_dP) {
	    ++jj;
	    printf ("\tLikely parent n� %d: %5.0f\tlod score:  %5.2f\tdelta:  %5.2f",jj, best_pars[k], score[k],delta[k]);
	    printf ("\t %3.0f/%3.0f/%3.0f", miss_par[k], loclod[k], nloc-cyt-match_par[k]);  printf ("\n"); 
	    if (kk==0)  { par1[i] = best_pars[k]; kk+=1;} 
	  }
	}
      }

      if (jj!=0)  nb_off_1par+=1;  
      if (jj==0)  
	{
	  printf ("\tNo likely parent inside the stand\n");	      
	}


      fflush(stdout);    
      
      /* Calcul des vraisemblances pour les meilleurs couples*/
      pc=1.0E6; for (k=0; k< nb+1; ++k)  pcore[k]=0.0; 
      for (j=1; j<=npop; ++j)
	{ 
	  tp1 = listp[j];
	  if (npop > 0)
	    {
	      for (kk=1; kk<=npop; ++kk)
		{
		  tp2 = listp[kk];
		  if (tp2>=tp1)
		    {
		      cc = pparchk(nloc-cyt, kidgen[i], pargen[tp1], pargen[tp2], pf, E, F, nall, miss);  /*dans boucle en j*/
		      if (cyt > 0) cc+=likr_pair_cyt(cyt, kidcyt[i],parcyt[tp1],parcyt[tp2], pfc, E, nallc);
		      if (cc > 0.0 && finite(cc)==1) 
			{
			  ++npopp; 
			  if (npopp < nb+1) 
			    {
			      best_pairs[0][npopp] = name_par[tp1]; 
			      best_pairs[1][npopp] = name_par[tp2]; 
			      pcore[npopp]=cc; 
			      match_pair[npopp]=match2(kidgen[i],pargen[tp1],pargen[tp2],nloc-cyt);
			      loclod1[npopp]=loc_lod_2par(nloc-cyt, kidgen[i], pargen[tp1], pargen[tp2], pf, E, F, nall, miss);
			      if (cc < pc)  pc = cc; 
			    } 
			  else
			    {
			      if (cc > pc) 
				{
				  k = dexmin(pcore, nb);
				  best_pairs[0][k] = *(name_par+tp1); 
				  best_pairs[1][k] = *(name_par+tp2); 
				  pcore[k] = cc;
				  match_pair[k]=match2(kidgen[i],pargen[tp1],pargen[tp2],nloc-cyt);
				  loclod1[k]=loc_lod_2par(nloc-cyt, kidgen[i], pargen[tp1], pargen[tp2], pf, E, F, nall, miss);
				  pc = valmin(pcore, nb); 
				}
			    }
			  
			}/* printf ("\n pc: %f \t",pc); */ 
		    }
		}
	    }
	} 
      /* Tri*/
      sort5(nb,pcore,best_pairs[0],best_pairs[1], match_pair, loclod1);			
      deltamax=pcore[nb];
      for (k=nb; k>=1; --k){ if (k==nb) deltaC[k]=deltamax; else if (k<nb && score[k]>0) deltaC[k]=deltamax-pcore[k];}
           
      /* Affichage des meilleurs*/
      jj=0;
      kk=0;
      
      for (k=nb; k>=1; --k){
	if (test_type==1){
	  if (pcore[k] > SEUIL_C) {
	    for (j=nb; j>=1;--j) {
	      if (best_pairs[0][k]==best_pars[j] && score[j]> SEUIL_P){
		for (l=nb; l>=1;--l){
		  if (best_pairs[1][k]==best_pars[l] && score[l]> SEUIL_P){	     
		    ++jj;
		    printf ("\tLikely pair n� %d: (%4.0f %4.0f)\tscore:  %5.2f",
			    jj,best_pairs[0][k], best_pairs[1][k],pcore[k]);
		    printf ("\t  %3.0f/%2.0f", loclod1[k], nloc-cyt-match_pair[k]);  printf ("\n");
		    par1[i]=best_pairs[0][nb]; /* modif 7/7/15 [nb] remplac� par [1], marchait pas, remis � l'identique : fonctionne... */
		    par2[i]=best_pairs[1][nb];
		  }
		}			  
	      }
	    }
	  }
	}
	else if (test_type==2){
	  if (deltaC[k] > SEUIL_dC) {
	    for (j=nb; j>=1;--j) {
	      if (best_pairs[0][k]==best_pars[j] && delta[j]> SEUIL_dP){
		for (l=nb; l>=1;--l){
		  if (best_pairs[1][k]==best_pars[l] && delta[l]> SEUIL_dP){	     
		    ++jj;
		    printf ("\tLikely pair n� %d: (%4.0f %4.0f)\tdelta:  %5.2f",
			    jj,best_pairs[0][k], best_pairs[1][k],deltaC[k]);
		    printf ("\t  %3.0f/%2.0f", loclod1[k], nloc-cyt-match_pair[k]);  printf ("\n");
		    par1[i]=best_pairs[0][nb];
		    par2[i]=best_pairs[1][nb];
		  }
		}			  
	      }
	    }
	  }
	}
	else if (test_type==3){
	  if (pcore[k] > SEUIL_C && deltaC[k] > SEUIL_dC) {
	    for (j=nb; j>=1;--j) {
	      if (best_pairs[0][k]==best_pars[j] && score[j]>SEUIL_P && delta[j]> SEUIL_dP ){
		for (l=nb; l>=1;--l){
		  if (best_pairs[1][k]==best_pars[l]&& score[j]>SEUIL_P && delta[l]> SEUIL_dP){	     
		    ++jj;
		    printf ("\tLikely pair n� %d: (%4.0f %4.0f)\tlod: %5.2f, delta:  %5.2f",
			    jj,best_pairs[0][k], best_pairs[1][k],pcore[k], deltaC[k]);
		    printf ("\t  %3.0f/%2.0f", loclod1[k], nloc-cyt-match_pair[k]);  printf ("\n");
		    par1[i]=best_pairs[0][nb];
		    par2[i]=best_pairs[1][nb];
		  }
		}			  
	      }
	    }
	  }
	}
      }
      if (jj!=0) nb_off_2par+=1; 
      if (jj==0) printf ("\tNo likely pair inside the stand\n");
     
    }/* end loop i / nkid */ 
 
  printf("\n Among %d offspring, %d have one parent among the genotyped one, %d two", nkid, (nb_off_1par - nb_off_2par), nb_off_2par);
  printf ("\n");
  

  x=2*nkid-nb_off_1par+nb_off_2par-2*nb_off_2par;
  y=2*nkid;
  printf("\n Total gene flow \tnumber = %.0f \tpercentage = %.4f",x , x/y*100);
  printf ("\n");
/*modif 7 juillet 2015, affichage eronn� du plus mauvais des parents probables*/
  if ( f != NULL) fprintf (f, "\n %d ", (nb_off_1par - nb_off_2par));  
  for (i=1; i<=nkid; i++) 
    if ( f != NULL && par1[i]!=0 && par2[i]==0) fprintf (f, "\n %d %d", name_kid[i], par1[i]);
  if ( g != NULL) fprintf (g, "\n %d ", nb_off_2par);  
  for (i=1; i<=nkid; i++) 
    if ( g != NULL && par2[i]!=0) fprintf (g, "\n %d %d %d", name_kid[i], par1[i], par2[i]);

  fclose(f);
  fclose(g);
  return(0); 
 
}







