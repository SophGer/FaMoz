#include <math.h>
#include <stdio.h>
/* #include <time.h> */ /* pour initialiser le g�n�rateur de nombres al�atoires*/
#include <sys/time.h> /* If Linux, replace previous line by these two lines */
#include <unistd.h> 
#include <stdlib.h> 
#include "nrutil.h"
#include "read.h"
#include "sort.h"
#include "alea.h"
#include "genetic.h"
#include "likely.h"

/**************************************************************************
10/3/99
Programme pour comparer des individus par paire et calculer les vraisemblances
de plein-fr�res (FS), demi-fr�re (HS), non apparent�s (U). Et les lod-scores
associ�s.

11/3/99
simulation d'individus pleins fr�res et calculs de leur lod scores.
Fichier d'entr�e
nb_loci
nb_all_loc1 freq_all1_loc1 ....
nb_all_loc2 freq_all1_loc2 ....
number_individuals number_simulated_sib_pairs
number_ind1 genotype...
number_ind2 genotype...

***************************************************************************/

extern double rans();

main (int argc, char *argv[])
{ 
  char *name1, *name2;
  int nloc, *nall, cyt, *nallc, fhsu; /* number of alleles*/
  double **pf, **fcum, **fcumc, **pfc;	 /* loci details; prior freqs fr�quences cumul�es */
  int nkid, nkid1, npar;			 /* individual names etc. */
  int *name_par, *name_kid1, *name_kid2, **parcyt; /*kid 1 et 2 les deux pleins fr�res*/
  Geno **pargen, **kidgen1, **kidgen2; 	/* genotypic data */
  int **dadgam1, **mumgam1, **dadgam2, **mumgam2; /* Gam�tes paternel et paternel*/
  int i,ii,jj, mum, dad, *mere;
  double *hs, *fs, Es; 
  /* hs et fs lod scores demi fr�res et pleins fr�res*/
  
  /* initialisation du g�n�rateur de nombres al�atoires :*/
  long m;
  float rand;
  struct timeval temps; 
  struct timezone zone;
  gettimeofday(&temps,&zone);
  m=-temps.tv_usec; 
  rand=ran3(&m);
  
  nkid=atoi(argv[1]);
  fhsu=atoi(argv[2]);
  Es=atof(argv[3]);
  cyt=atoi(argv[4]);

  name1 = "Half-sib";
  name2 = "Full-sib";

  /* Lecture des donn�es locus */
  scanf ("%d", &nloc);
  nall=(int *)malloc((nloc-cyt+1)*sizeof(int));
  if (cyt > 0) nallc=(int *)malloc((cyt+1)*sizeof(int));
  read_loci_cum (nloc, nall, &pf, &fcum, cyt, nallc, &pfc, &fcumc);
  scanf ("%d %d", &npar, &nkid1); 
  
  /* Allocate memory */
  name_par=(int *)malloc((npar+1)*sizeof(int));
  name_kid1=(int *)malloc((nkid+1)*sizeof(int));
  name_kid2=(int *)malloc((nkid+1)*sizeof(int));
  mere=(int *)malloc((nkid+1)*sizeof(int));
  kidgen1=(Geno **)malloc((nkid+1) * sizeof(Geno *));
  kidgen2=(Geno **)malloc((nkid+1) * sizeof(Geno *));
  pargen=(Geno **)malloc((npar+1) * sizeof(Geno *));
  parcyt=(int **)malloc((npar+1) * sizeof(int *));
  hs=(double *)malloc((nkid+1)*sizeof(double));
  fs=(double *)malloc((nkid+1)*sizeof(double));
  
  for (i=1;i<=nkid;++i)
    { 
      kidgen1[i]=(Geno *)malloc((nloc-cyt+1) * sizeof(Geno));
      kidgen2[i]=(Geno *)malloc((nloc-cyt+1) * sizeof(Geno));
    }
  for (i=1;i<=npar;++i)
    {
      parcyt[i]=(int *)malloc((cyt+1) * sizeof(int));
      pargen[i]=(Geno *)malloc((nloc-cyt+1) * sizeof(Geno));
    }
  if (fhsu==1 ) 
    {
      dadgam1=(int **)malloc((npar+1) * sizeof(int *));
      mumgam1=(int **)malloc((npar+1) * sizeof(int *));
      dadgam2=(int **)malloc((npar+1) * sizeof(int *));
      mumgam2=(int **)malloc((npar+1) * sizeof(int *));
      for (i=1;i<=npar;++i) 
	{
	 dadgam1[i]=(int *)malloc((nloc-cyt+1) * sizeof(int));
	 mumgam1[i]=(int *)malloc((nloc+1) * sizeof(int));
	 dadgam2[i]=(int *)malloc((nloc-cyt+1) * sizeof(int));
	 mumgam2[i]=(int *)malloc((nloc+1) * sizeof(int));
	}
    }
  else if (fhsu==2)
    {
      dadgam1=(int **)malloc((nkid+1) * sizeof(int *));
      mumgam1=(int **)malloc((npar+1) * sizeof(int *));
      dadgam2=(int **)malloc((nkid+1) * sizeof(int *));
      mumgam2=(int **)malloc((npar+1) * sizeof(int *));
      for (i=1;i<=npar;++i) 
       {
	 mumgam1[i]=(int *)malloc((nloc+1) * sizeof(int));
	 mumgam2[i]=(int *)malloc((nloc+1) * sizeof(int));
       }
      for (i=1;i<=nkid;++i) 
	{
	  dadgam1[i]=(int *)malloc((nloc-cyt+1) * sizeof(int));
	  dadgam2[i]=(int *)malloc((nloc-cyt+1) * sizeof(int));
	}
    }
  else if (fhsu==3)
    {
      dadgam1=(int **)malloc((nkid+1) * sizeof(int *));
      mumgam1=(int **)malloc((nkid+1) * sizeof(int *));
      dadgam2=(int **)malloc((nkid+1) * sizeof(int *));
      mumgam2=(int **)malloc((nkid+1) * sizeof(int *));
      for (i=1;i<=nkid;++i) 
	{
	  mumgam1[i]=(int *)malloc((nloc+1) * sizeof(int));
	  mumgam2[i]=(int *)malloc((nloc+1) * sizeof(int));
	  dadgam1[i]=(int *)malloc((nloc-cyt+1) * sizeof(int));
	  dadgam2[i]=(int *)malloc((nloc-cyt+1) * sizeof(int));
	}
    }
  
  read_gen_dat_par(npar, name_par, pargen, parcyt, nloc, cyt);
  printf("\n Number of loci: %d",nloc);
  printf("\n Among them, number of cytoplasmic markers: %d",cyt);
  if (fhsu==1) printf("\n Full-sibs will be simulated\n");
  if (fhsu==2) printf("\n Half-sibs will be simulated\n");
  if (fhsu==3) printf("\n Unrelated individuals will be simulated\n");
  printf ("\n Number of genotyped individuals: %d, number of simulated individuals: %d", npar, nkid); 
  
  
  /* Simulated pairs of individuals with a given relatedness */
  for (ii=1;ii<=nkid;++ii)
    {
      name_kid1[ii]=1000+ii;
      name_kid2[ii]=2000+ii;
      
      if (fhsu==1 ) /* Simulate full-sibs */
	{
	  mum = 1+(int)(npar*alea()) ; /* Tirage al�atoire des deux parents : */
	  dad = 1+(int)(npar*alea()) ; /* nombre entier al�atoire dans [1,npar] */ 
	  gamete(pargen[mum],mumgam1[mum],nloc, nall, Es, cyt, nallc, parcyt[mum]); 
	  /* Simulation des gam�tes parentaux : */ 
	  gamete(pargen[dad],dadgam1[dad],nloc-cyt, nall, Es, cyt, nallc, parcyt[dad]);
	  gamete(pargen[mum],mumgam2[mum],nloc, nall, Es, cyt, nallc, parcyt[mum]);
	  gamete(pargen[dad],dadgam2[dad],nloc-cyt, nall, Es, cyt, nallc, parcyt[dad]);
	  for (jj=1;jj<=nloc-cyt;++jj)
	    { 
	      kidgen1[ii][jj].g1=mumgam1[mum][jj]; /* ii :enfant, jj locus*/
	      kidgen1[ii][jj].g2=dadgam1[dad][jj]; 
	      kidgen2[ii][jj].g1=mumgam2[mum][jj];
	      kidgen2[ii][jj].g2=dadgam2[dad][jj]; 
	    } 
	}
      
      else if (fhsu==2) /* Simulate half-sibs */
	{
	  mum = 1+(int)(npar*alea()) ; /* Tirage al�atoire d'un parents : */
	  mere[ii]=mum; /* nombre entier al�atoire dans [1,npar] */ 
	  gamete(pargen[mum],mumgam1[mum],nloc-cyt, nall, Es, cyt, nallc, parcyt[mum]); 
	  /* Simulation des gam�tes parentaux : */ 
	  gamete_hp(dadgam1[ii], nloc-cyt, nall, fcum, cyt, nallc, fcumc);
	  gamete(pargen[mum],mumgam2[mum],nloc-cyt, nall, Es, cyt, nallc, parcyt[mum]);
	  gamete_hp(dadgam2[ii], nloc-cyt, nall, fcum, cyt, nallc, fcumc);
	  for (jj=1;jj<=nloc-cyt;++jj)
	    { 
	      kidgen1[ii][jj].g1=mumgam1[mum][jj]; /* ii :enfant, jj locus*/
	      kidgen1[ii][jj].g2=dadgam1[ii][jj]; 
	      kidgen2[ii][jj].g1=mumgam2[mum][jj];
	      kidgen2[ii][jj].g2=dadgam2[ii][jj];
	    } 
	}
      
      else if (fhsu==3) /* Simulate half-sibs */
	{
	  gamete_hp(mumgam1[ii],nloc, nall, fcum, cyt, nallc, fcumc); 
	  /* Simulation des gam�tes parentaux : */ 
	  gamete_hp(dadgam1[ii], nloc, nall, fcum, cyt, nallc, fcumc);
	  gamete_hp(mumgam2[ii],nloc, nall, fcum, cyt, nallc, fcumc);
	  gamete_hp(dadgam2[ii],nloc, nall, fcum, cyt, nallc, fcumc);
	  for (jj=1;jj<=nloc-cyt;++jj)
	    {
	      kidgen1[ii][jj].g1=mumgam1[ii][jj]; /* ii :enfant, jj locus*/
	      kidgen1[ii][jj].g2=dadgam1[ii][jj]; 
	      kidgen2[ii][jj].g1=mumgam2[ii][jj];
	      kidgen2[ii][jj].g2=dadgam2[ii][jj]; 
	    } 
	}
      /*  else printf("\n Please give 1, 2 or 3 for value of fhsu \n"); */
    }
  
/*   if (fhsu==1 )  Simulate full-sibs */ 
/*     { */
/*       f = fopen ("FSlodHS", "w");  */
/*       g = fopen ("FSlodFS", "w");  */
/*     } */
/*   if (fhsu==2)  Simulate half-sibs */ 
/*     { */
/*       f = fopen ("HSlodHS", "w");  */
/*       g = fopen ("HSlodFS", "w");  */
/*     } */
/*   if (fhsu==3 )  Simulate unrel */ 
/*     { */
/*       f = fopen ("UlodHS", "w");  */
/*       g = fopen ("UlodFS", "w");  */
/*     } */
  for (i=1; i<=nkid; ++i)
    {
      /* printf("fr�re %d - fr�re %d \n", name_kid1[i], name_kid2[i]) ; */
      /* printf("g�notype fr�re 1") ; */
      /* print_geno(kidgen1[i]); printf("\n"); */
      /* printf("g�notype fr�re 2") ; */
      /* print_geno(kidgen2[i]); printf("\n") ; */
      /* verif_loc(pargen[i],pargen[j]); */
      hs[i]= half_sib(kidgen1[i],kidgen2[i], nloc-cyt, pf); /*lod score demi-fr�re*/
      fs[i]= full_sib(kidgen1[i],kidgen2[i], nloc-cyt, pf); /*lod score plein-fr�re*/
      /*if (finite(hs[i]) == 1) if ( f != NULL)  fprintf (f, " %f ",hs[i]);		  */
      /*if (finite(fs[i]) == 1) if ( g != NULL)  fprintf (g, " %f ",fs[i]);  */
    } 
  
  
  /*   fclose (f);  */
  /*   fclose (g);  */
  printf ("\n");
  
  hist1(hs, nkid, name1);
  hist1(fs, nkid, name2);

  return(0);

}
