/**************************************************************************************
  18/5/01 
  The genetic library contains programs for handling different genetic steps
 *************************************************************************************/

/* Number of missing data in genotype gen */

double missing (gen, nl)
     Geno *gen;
     int nl;
{
  int i;
  double miss;
  miss=0;
  for (i=1; i<=nl ; ++i)
    {
      if (gen[i].g1==(-5) || gen[i].g2==(-5)) miss+=1; 
    }
  return (miss);
}

/* For dominant markers */

double missing_dom (gen, nl)
     int *gen;
     int nl;
{
  int i;
  double miss;
  miss=0;
  for (i=1; i<=nl ; ++i) if (gen[i]==(-5)) miss+=1;
  return (miss);
}

/* Compare the genotypes gen1 and gen2 and gives the number of matches between them for each locus */
/* a missing data is considered as a match*/

double match1 (gen1, gen2, nl)
     Geno *gen1, *gen2;   
     int nl;
{ 
  int i;
  double match;
  match=0;
  for (i=1; i<=nl ; ++i)
    {
      if (gen1[i].g1 == gen2[i].g1 || gen1[i].g1 == gen2[i].g2
	  || gen1[i].g2 == gen2[i].g1 || gen1[i].g2 == gen2[i].g2
          || gen1[i].g1 == -5 || gen1[i].g2 == -5
	  || gen2[i].g1 == -5 || gen2[i].g2 == -5)
	match+=1; 
    }
  return (match);

}

/* Compare the genotypes gen1 (offspring) and (gen2, gen3) (parent pair)  */
/* and gives the number of matches between them for each locus */ 
/* a missing data is considered as a match*/

double match2 (gen1, gen2, gen3, nl)
     Geno *gen1, *gen2, *gen3;
     int nl;
{ 
  int i, g1, g2, g3, g4, g5, g6;
  double match;
  match=0;
  for (i=1; i<=nl ; ++i)
    {
      g1=gen1[i].g1;
      g2=gen1[i].g2;
      g3=gen2[i].g1;
      g4=gen2[i].g2;
      g5=gen3[i].g1;
      g6=gen3[i].g2;

      if ( g1 == -5 ||  g2 == -5 || g3 == -5 || g4 == -5 || g5 == -5 || g6 == -5 ||
	   (((g1 == g3 || g1 == g4) && (g2 == g5 || g2 == g6))
	    || ((g1 == g5 || g1 == g6) && (g2 == g3 || g2 == g4)))) match += 1;
    }
  return (match);

}

/* For dominant markers gen1: kid, 2 & 3 parents */

double mismatch2_dom (gen1, gen2, gen3, nl)
     int *gen1, *gen2, *gen3;   
     int nl;
{ 
  int i;
  double missm;
  missm=0;
  for (i=1; i<=nl ; ++i)
    {
      if (   gen1[i]==1 && gen2[i]==0 && gen3[i]==0
          && gen1[i] != -5 && gen2[i] != -5 && gen3[i] != -5) 
	missm+=1; 
    }
  return (missm);

}


/* Compare the genotypes gen1 and gen2 and gives the number of matches between them for each locus */
/* excluding missing data (returns 1 if gen1 and 2 are identical) *** Codominant markers ***/

int comp_id (gen1, gen2, lon, nl)
     Geno *gen1, *gen2;   
     int nl;
     double *lon;
{ 
  int i, j, id, ml;
  /*double id,ml; /*ml missing locus*/
  id=0; ml=0;
  for (i=1; i<=nl ; ++i)
    {
      j=lon[i];
      /* ajout d'une exclusion des données manquantes, août 2015 */
      if (gen1[j].g1 == -5 || gen1[j].g2 == -5 || gen2[j].g1 == -5 || gen2[j].g2 == -5) ml+=1;
      else if ((gen1[j].g1 == gen2[j].g1 && gen1[j].g2 == gen2[j].g2) || (gen1[j].g2 == gen2[j].g1 && gen1[j].g1 == gen2[j].g2))
      /*    && gen1[j].g1 != -5 && gen1[j].g2 != -5 && gen2[j].g1 != -5 && gen2[j].g2 != -5) */
		id+=1; 
    }
  /*if (id==(nl-ml)) {return (1); printf("ml %d id %d",ml,id)};*/
  if (id==(nl-ml)) return (1);
  else  return (0);

}

/* Compare the genotypes gen1 and gen2 and gives the number of matches between them for each locus */
/* excluding missing data (returns 1 if gen1 and 2 are identical)*** Dominant markers ***/

int comp_id_dom (gen1, gen2, lon, nl)
     int *gen1, *gen2, nl;
     double *lon;
{ 
  int i, j;
  double id;
  id=0;
  for (i=1; i<=nl ; ++i)
    {
      j=lon[i];
      if (   gen1[j] == gen2[j] && gen1[i] != -5 && gen1[i]!=-5) 
	id+=1; 
    }
  if (id==nl) return (1);
  else  return (0);
}


/* Compare the genotypes gen1 and gen2 and gives the number of matches between them for each locus */
/* excluding missing data (returns 1 if gen1 and 2 are identical)*** Co- and Dominant markers ***/

int comp_id_domcod (gen1, gen2, gend1, gend2, lon, loct, nl)
     Geno *gen1, *gen2;  
     int *gend1, *gend2, nl;
     double *lon, *loct;
{ 
  int i, j;
  double id;
  id=0;
  for (i=1; i<=nl ; ++i)
    {
      j=lon[i];
      if (loct[i]==1)
	{
	  if ((gen1[j].g1 == gen2[j].g1 && gen1[j].g2 == gen2[j].g2)
	      || (gen1[j].g2 == gen2[j].g1 && gen1[j].g1 == gen2[j].g2)
	      && gen1[j].g1 != -5 && gen1[j].g2 != -5
	      && gen2[j].g1 != -5 && gen2[j].g2 != -5)  id+=1; 
	}
      else if (loct[i]==2)
	if (gend1[j] == gend2[j] && gend1[i] != -5 && gend1[i]!=-5) id+=1; 
    }
  if (id == nl) return (1);
  else  return (0);
}
