#include <math.h>
#include <stdio.h>
/* #include <time.h> */ /* pour initialiser le g�n�rateur de nombres al�atoires*/
#include <sys/time.h>
#include <unistd.h>
#include <stdlib.h> 
#include "nrutil.h"
#include "read.h"
#include "sort.h"
#include "alea.h"
#include "likely.h"

/**************************************************************************
10/3/99
Programme pour comparer des individus par paire et calculer les vraisemblances
de plein-fr�res (FS), demi-fr�re (HS), non apparent�s (U). Et les lod-scores
associ�s.

11/3/99
simulation d'individus pleins fr�res et calculs de leur lod scores.
Fichier d'entr�e
nb_loci
nb_all_loc1 freq_all1_loc1 ....
nb_all_loc2 freq_all1_loc2 ....
number_individuals number_simulated_sib_pairs
number_ind1 genotype...
number_ind2 genotype...

***************************************************************************/

extern double rans();

main (int argc, char *argv[])
{ 
  char *name1, *name2;
  int nloc, *nall, cyt, *nallc, fhsu, *sp, *sp1, *sp2, spc; /* number of alleles*/
  double **pfs, **pfp, **fcums, **fcump, **fcum, **fcumc, **pfc;  /* loci details; prior freqs fr�quences cumul�es */
  int nkid, nkid1, npar;			 /* individual names etc. */
  int *name_par, *name_kid1, *name_kid2, **parcyt, **kidcyt, **kidcyt1; /*kid 1 et 2 les deux pleins fr�res*/
  Geno **pargen, **kidgen1, **kidgen2; 	/* genotypic data */
  int **dadgam1, **mumgam1, **dadgam2, **mumgam2; /* Gam�tes paternel et paternel*/
  int i,ii,jj, mum, dad, *mere;
  double *hs, *fs, Es, S, s, p; 
  /* hs et fs lod scores demi fr�res et pleins fr�res*/
  /*FILE *FSlodHS, *FSlodFS, *f, *g;  */
  
  /* initialisation du g�n�rateur de nombres al�atoires :*/
  long m;
  float rand;
  struct timeval temps; 
  struct timezone zone;
  gettimeofday(&temps,&zone);
  m=-temps.tv_usec; 
  rand=ran3(&m);
  
  nkid=atoi(argv[1]);
  fhsu=atoi(argv[2]);
  Es=atof(argv[3]);
  cyt=atoi(argv[4]);
  S=atof(argv[5]);
  s=atof(argv[6]);
  p=atof(argv[7]);
  spc=atoi(argv[8]); /* if spc==1(2), choose only species n�1(2) parents or gamete, if spc==3, mix */

  name1 = "Half-sib";
  name2 = "Full-sib";

  /* Lecture des donn�es locus */
  scanf ("%d", &nloc);
  nall=(int *)malloc((nloc-cyt+1)*sizeof(int));
  if (cyt > 0) nallc=(int *)malloc((cyt+1)*sizeof(int));
  read_loci_cum (nloc, nall, &pfs, &fcums, cyt, nallc, &pfc, &fcumc);
  read_loci_cum (nloc, nall, &pfp, &fcump, cyt, nallc, &pfc, &fcumc);
  scanf ("%d %d", &npar, &nkid1); 
  
  /* Allocate memory */
  name_par=(int *)malloc((npar+1)*sizeof(int));
  name_kid1=(int *)malloc((nkid+1)*sizeof(int));
  name_kid2=(int *)malloc((nkid+1)*sizeof(int));
  mere=(int *)malloc((nkid+1)*sizeof(int));
  kidgen1=(Geno **)malloc((nkid+1) * sizeof(Geno *));
  kidgen2=(Geno **)malloc((nkid+1) * sizeof(Geno *));
  pargen=(Geno **)malloc((npar+1) * sizeof(Geno *));
  parcyt=(int **)malloc((npar+1) * sizeof(int *));
  kidcyt=(int **)malloc((nkid+1) * sizeof(int *));
  kidcyt1=(int **)malloc((nkid+1) * sizeof(int *));
  sp=(int *)malloc((npar+1) * sizeof(int)); /* Species status*/
  sp1=(int *)malloc((nkid+1) * sizeof(int)); /* Species status*/
  sp2=(int *)malloc((nkid+1) * sizeof(int)); /* Species status*/
  hs=(double *)malloc((nkid+1)*sizeof(double));
  fs=(double *)malloc((nkid+1)*sizeof(double));
  
  for (i=1;i<=nkid;++i)
    { 
      kidgen1[i]=(Geno *)malloc((nloc-cyt+1) * sizeof(Geno));
      kidgen2[i]=(Geno *)malloc((nloc-cyt+1) * sizeof(Geno));
      kidcyt[i]=(int *)malloc((cyt+1) * sizeof(int));
      kidcyt1[i]=(int *)malloc((cyt+1) * sizeof(int));
    }
  for (i=1;i<=npar;++i)
    {
      parcyt[i]=(int *)malloc((cyt+1) * sizeof(int));
      pargen[i]=(Geno *)malloc((nloc-cyt+1) * sizeof(Geno));
    }
  if (fhsu==1 ) 
    {
      dadgam1=(int **)malloc((npar+1) * sizeof(int *));
      mumgam1=(int **)malloc((npar+1) * sizeof(int *));
      dadgam2=(int **)malloc((npar+1) * sizeof(int *));
      mumgam2=(int **)malloc((npar+1) * sizeof(int *));
      for (i=1;i<=npar;++i) 
	{
	 dadgam1[i]=(int *)malloc((nloc-cyt+1) * sizeof(int));
	 mumgam1[i]=(int *)malloc((nloc+1) * sizeof(int));
	 dadgam2[i]=(int *)malloc((nloc-cyt+1) * sizeof(int));
	 mumgam2[i]=(int *)malloc((nloc+1) * sizeof(int));
	}
    }
  else if (fhsu==2)
    {
      dadgam1=(int **)malloc((nkid+1) * sizeof(int *));
      mumgam1=(int **)malloc((npar+1) * sizeof(int *));
      dadgam2=(int **)malloc((nkid+1) * sizeof(int *));
      mumgam2=(int **)malloc((npar+1) * sizeof(int *));
      for (i=1;i<=npar;++i) 
       {
	 mumgam1[i]=(int *)malloc((nloc+1) * sizeof(int));
	 mumgam2[i]=(int *)malloc((nloc+1) * sizeof(int));
       }
      for (i=1;i<=nkid;++i) 
	{
	  dadgam1[i]=(int *)malloc((nloc-cyt+1) * sizeof(int));
	  dadgam2[i]=(int *)malloc((nloc-cyt+1) * sizeof(int));
	}
    }
  else if (fhsu==3)
    {
      dadgam1=(int **)malloc((nkid+1) * sizeof(int *));
      mumgam1=(int **)malloc((nkid+1) * sizeof(int *));
      dadgam2=(int **)malloc((nkid+1) * sizeof(int *));
      mumgam2=(int **)malloc((nkid+1) * sizeof(int *));
      for (i=1;i<=nkid;++i) 
	{
	  mumgam1[i]=(int *)malloc((nloc+1) * sizeof(int));
	  mumgam2[i]=(int *)malloc((nloc+1) * sizeof(int));
	  dadgam1[i]=(int *)malloc((nloc-cyt+1) * sizeof(int));
	  dadgam2[i]=(int *)malloc((nloc-cyt+1) * sizeof(int));
	}
    }
  
  read_gen_dat_par_sp(npar, name_par, sp, pargen, parcyt, nloc, cyt);
  printf("\n Number of loci: %d",nloc);
  printf("\n Among them, number of cytoplasmic markers: %d",cyt);
  if (fhsu==1) printf("\n Full-sibs will be simulated\n");
  if (fhsu==2) printf("\n Half-sibs will be simulated\n");
  if (fhsu==3) printf("\n Unrelated individuals will be simulated\n");
  if (spc==1) printf("\n Both simulated individuals will be from species n�1");
  if (spc==2) printf("\n Both simulated individuals will be from species n�2");
  if (spc==3) printf("\n Each simulated individual will be from a different species");
  printf ("\n Number of genotyped individuals: %d, number of simulated individuals: %d", npar, nkid); 
  
  
  /* Simulated pairs of individuals with a given relatedness */
  for (ii=1;ii<=nkid;++ii)
    {
      name_kid1[ii]=1000+ii;
      name_kid2[ii]=2000+ii;
      
      if (fhsu==1 ) /* Simulate full-sibs */
	{
	  mum = 1+(int)(npar*alea()) ; /* Tirage al�atoire des deux parents : */
	  if (spc==1) while (sp[mum]!=1)  mum = 1+(int)(npar*alea());
	  if (spc==2) while (sp[mum]!=2)  mum = 1+(int)(npar*alea());
	  if (spc==3) while (sp[mum]!=1)  mum = 1+(int)(npar*alea());
	  dad = 1+(int)(npar*alea()) ; /* nombre entier al�atoire dans [1,npar] */ 
	  if (spc==1) while (sp[dad]!=1)  dad = 1+(int)(npar*alea());
	  if (spc==2) while (sp[dad]!=2)  dad = 1+(int)(npar*alea());
	  if (spc==3) while (sp[dad]!=2)  dad = 1+(int)(npar*alea());

	  if (spc==1) { sp1[ii]=1; sp2[ii]=1;}
	  if (spc==2) { sp1[ii]=2; sp2[ii]=2;}
	  if (spc==3) { sp1[ii]=1; sp2[ii]=2;}

	  gamete(pargen[mum],mumgam1[mum],nloc, nall, Es, cyt, nallc, parcyt[mum]); /*Simulation des gam�tes parentaux*/ 
	  gamete(pargen[dad],dadgam1[dad],nloc, nall, Es, cyt, nallc, parcyt[dad]);
	  gamete(pargen[mum],mumgam2[mum],nloc, nall, Es, cyt, nallc, parcyt[mum]);
	  gamete(pargen[dad],dadgam2[dad],nloc, nall, Es, cyt, nallc, parcyt[dad]);
	  for (jj=1;jj<=nloc-cyt;++jj)
	    { 
	      kidgen1[ii][jj].g1=mumgam1[mum][jj]; /* ii :enfant, jj locus*/
	      kidgen1[ii][jj].g2=dadgam1[dad][jj]; 
	      kidgen2[ii][jj].g1=mumgam2[mum][jj];
	      kidgen2[ii][jj].g2=dadgam2[dad][jj]; 
	    } 
	  if  (cyt > 0) for (jj=1;jj<=cyt;++jj)  kidcyt[ii][jj] = parcyt[mum][jj];  
	}
      
      else if (fhsu==2) /* Simulate half-sibs */
	{
	  mum = 1+(int)(npar*alea()) ; /* Tirage al�atoire d'un parents : */
	  if (spc==1) while (sp[mum]!=1)  mum = 1+(int)(npar*alea());
	  if (spc==2) while (sp[mum]!=2)  mum = 1+(int)(npar*alea());
	  if (spc==3) while (sp[mum]!=1)  mum = 1+(int)(npar*alea());
	  mere[ii]=mum; /* nombre entier al�atoire dans [1,npar] */ 
	  gamete(pargen[mum],mumgam1[mum],nloc, nall, Es, cyt, nallc, parcyt[mum]); /*Simulation des gam�tes parentaux*/ 
	  if (spc==1) { fcum=fcums; sp1[ii]=1; sp2[ii]=1;}
	  if (spc==2) { fcum=fcump; sp1[ii]=2; sp2[ii]=2;}
	  if (spc==3) { fcum=fcump; sp1[ii]=1; sp2[ii]=2;}
	  gamete_hp(dadgam1[ii], parcyt[ii], nloc, nall, fcum, cyt, nallc, fcumc);
	  gamete(pargen[mum],mumgam2[mum],nloc, nall, Es, cyt, nallc, parcyt[mum]);
	  gamete_hp(dadgam2[ii], parcyt[ii],nloc, nall, fcum, cyt, nallc, fcumc);
	  for (jj=1;jj<=nloc-cyt;++jj)
	    { 
	      kidgen1[ii][jj].g1=mumgam1[mum][jj]; /* ii :enfant, jj locus*/
	      kidgen1[ii][jj].g2=dadgam1[ii][jj]; 
	      kidgen2[ii][jj].g1=mumgam2[mum][jj];
	      kidgen2[ii][jj].g2=dadgam2[ii][jj];
	    } 
	  if  (cyt > 0) for (jj=1;jj<=cyt;++jj)  kidcyt[ii][jj] = parcyt[mum][jj];  
	}
      
      else if (fhsu==3) /* Simulate unrelated-sibs */
	{
	  if (spc==1) 
	    {
	      fcum=fcums;
	      gamete_hp(mumgam1[ii], parcyt[ii],nloc, nall, fcum, cyt, nallc, fcumc); /* Simulation des gam�tes parentaux : */ 
	      gamete_hp(dadgam1[ii], parcyt[ii],nloc, nall, fcum, cyt, nallc, fcumc);
	      gamete_hp(mumgam2[ii], parcyt[ii],nloc, nall, fcum, cyt, nallc, fcumc);
	      gamete_hp(dadgam2[ii], parcyt[ii],nloc, nall, fcum, cyt, nallc, fcumc);
	      sp1[ii]=1; 
	      sp2[ii]=1;
	    }
	  if (spc==2)
	    {
	      fcum=fcump;
	      gamete_hp(mumgam1[ii], parcyt[ii],nloc, nall, fcum, cyt, nallc, fcumc); /* Simulation des gam�tes parentaux : */ 
	      gamete_hp(dadgam1[ii], parcyt[ii],nloc, nall, fcum, cyt, nallc, fcumc);
	      gamete_hp(mumgam2[ii], parcyt[ii],nloc, nall, fcum, cyt, nallc, fcumc);
	      gamete_hp(dadgam2[ii], parcyt[ii],nloc, nall, fcum, cyt, nallc, fcumc);
	      sp1[ii]=2; 
	      sp2[ii]=2;
	    }
	  if (spc==3)
	    {
	      gamete_hp(mumgam1[ii], parcyt[ii],nloc, nall, fcums, cyt, nallc, fcumc); /* Simulation des gam�tes parentaux : */ 
	      gamete_hp(dadgam1[ii], parcyt[ii],nloc, nall, fcums, cyt, nallc, fcumc);
	      gamete_hp(mumgam2[ii], parcyt[ii],nloc, nall, fcump, cyt, nallc, fcumc);
	      gamete_hp(dadgam2[ii], parcyt[ii],nloc, nall, fcump, cyt, nallc, fcumc);
	      sp1[ii]=1; 
	      sp2[ii]=2;
	    }
	      for (jj=1;jj<=nloc-cyt;++jj)
		{
		  kidgen1[ii][jj].g1=mumgam1[ii][jj]; /* ii :enfant, jj locus*/
		  kidgen1[ii][jj].g2=dadgam1[ii][jj]; 
		  kidgen2[ii][jj].g1=mumgam2[ii][jj];
		  kidgen2[ii][jj].g2=dadgam2[ii][jj]; 
		} 
	      if  (cyt > 0) for (jj=1;jj<=cyt;++jj)  
		{
		  kidcyt[ii][jj] = parcyt[ii][jj];  
		  kidcyt1[ii][jj] = parcyt[ii][jj]; 
		}
	  /*  else printf("\n Please give 1, 2 or 3 for value of fhsu \n"); */
	}
    }
      
  /*   if (fhsu==1 )  Simulate full-sibs */ 
  /*     { */
  /*       f = fopen ("FSlodHS", "w");  */ 
  /*       g = fopen ("FSlodFS", "w");  */ 
  /*     } */
  /*   if (fhsu==2)  Simulate half-sibs */ 
  /*     { */
  /*       f = fopen ("HSlodHS", "w");  */ 
  /*       g = fopen ("HSlodFS", "w");  */ 
  /*     } */
  /*   if (fhsu==3 )  Simulate unrel */ 
  /*     { */
  /*       f = fopen ("UlodHS", "w");  */ 
  /*       g = fopen ("UlodFS", "w"); */  
  /*     } */
  
  for (i=1; i<=nkid; ++i)
    {
	      /* printf("fr�re %d - fr�re %d \n", name_kid1[i], name_kid2[i]) ; */
	      /* printf("g�notype fr�re 1") ; */
	      /* print_geno(kidgen1[i]); printf("\n"); */
	      /* printf("g�notype fr�re 2") ; */
	      /* print_geno(kidgen2[i]); printf("\n") ; */
	      /* verif_loc(pargen[i],pargen[j]); */
	      hs[i]= half_sib_sp(kidgen1[i],kidgen2[i],nloc, pfs, pfp, sp1[i], sp2[i], S, s, p);
	      /*lod score demi-fr�re*/
	      fs[i]= full_sib_sp(kidgen1[i],kidgen2[i],nloc, pfs, pfp, sp1[i], sp2[i], S, s, p); 
	      /*lod score plein-fr�re*/
	      /*if (finite(hs[i]) == 1) if ( f != NULL)  fprintf (f, " %f ",hs[i]);*/
	      /*if (finite(fs[i]) == 1) if ( g != NULL)  fprintf (g, " %f ",fs[i]);  */
    }
  
  printf ("\n");
  
  hist1(hs, nkid, name1);
  hist1(fs, nkid, name2);

  return(0);  
}
  
