#include <math.h>
#include <stdio.h>
/* #include <time.h> */  /* pour initialiser le g�n�rateur de nombres al�atoires*/
#include <sys/time.h>
#include <unistd.h>
#include <stdlib.h>     
#include "nrutil.h"
#include "read.h"
#include "alea.h"


/**************************************************************************
15/3/2000

Program to create genotypes at a new locus, 
sim_newloc < new_loc
with new_loc : nb_loci nb_all_loc1 freq_all1-loc1, ....
               nb_simulated individuals
Add lines at the beginning of
Newloc to fit original_file, then do (unix)
paste original_file Newloc > result_file

***************************************************************************/

extern double rans();

main (int argc, char *argv[])
{  
  int nloc, *nall, cyt, *nallc, marker_type;          /* number of alleles*/
  double **pf, **fcum, *pfd, **pfc, **fcumc;	         /* loci details; prior freqs; fr�quences cumul�es */
  int nkid, nlo;			 /* individual names etc. */
  int *name_kid;
  int **dadgam, **mumgam, **parcyt, **kidcyt;      /* Gam�tes paternel et maternel tir�s au hasard dans la pop*/
  int i,ii,jj, kk; 
  
  /* initialisation du g�n�rateur de nombres al�atoires :*/
  long m;
  float rand;
  struct timeval temps; 
  struct timezone  zone;
  gettimeofday(&temps,&zone);
  m=-temps.tv_usec; 
  rand=ran3(&m);
 
  nkid=atoi(argv[1]);
  marker_type=atoi(argv[2]);
  cyt=atoi(argv[3]);
  nlo=atoi(argv[4]);

  /* Lecture des donn�es locus */
  scanf ("%d", &nloc);
  nall=(int *)malloc((nloc-cyt+1)*sizeof(int));
  if (cyt > 0) nallc=(int *)malloc((cyt+1)*sizeof(int));
  name_kid=(int *)malloc((nkid+1)*sizeof(int));

  printf ("\n Number of loci: %d ", nloc);
  printf ("\n Of which cytoplasmic markers: %d", cyt);
  printf ("\n Number of simulated individuals: %d", nkid);
  printf ("\n Number of loci in simulation (maximum: number of nuclear loci in data file): %d", nlo);

 
  if (marker_type==1) /* Codominant markers*/
    {   
      Geno **kidgen; 	/* genotypic data */
      read_loci_cum (nloc, nall, &pf, &fcum, cyt, nallc, &pfc, &fcumc);
      
      kidgen=(Geno **)malloc((nkid+1) * sizeof(Geno *));
      for (i=1;i<=nkid;++i) kidgen[i]=(Geno *)malloc((nloc-cyt+1) * sizeof(Geno));
      dadgam=(int **)malloc((nkid+1) * sizeof(int *));
      mumgam=(int **)malloc((nkid+1) * sizeof(int *));
      parcyt=(int **)malloc((nkid+1) * sizeof(int *));
      kidcyt=(int **)malloc((nkid+1) * sizeof(int *));
  
      for (i=1; i<=nkid; i++) 
	{    
	  kidgen[i]=(Geno *)malloc((nlo+1) * sizeof(Geno));
	  dadgam[i]=(int *)malloc((nlo+1) * sizeof(int));
	  mumgam[i]=(int *)malloc((nlo+1) * sizeof(int));
	  kidcyt[i]=(int *)malloc((cyt+1) * sizeof(int));
	  parcyt[i]=(int *)malloc((cyt+1) * sizeof(int));
	}
      
      /* Cr�ation de descendants*/
      printf("\n Simulated individual n�, genotype\n");
      for (ii=1;ii<=nkid;++ii)
	{ 
	  name_kid[ii]=ii;
	  gamete_hp(mumgam[ii], nlo, nall, fcum, cyt, nallc, fcumc);            /* Simulation des gam�tes parentaux : */ 
	  gamete_hp(dadgam[ii], nlo, nall, fcum, cyt, nallc, fcumc); 
	  for (jj=1;jj<=nlo;++jj)
	    {
	      kidgen[ii][jj].g1=mumgam[ii][jj];  /* ii :enfant, jj locus*/
	      kidgen[ii][jj].g2=dadgam[ii][jj];   
	    }
	  if  (cyt > 0)        
	     for (jj=nloc-cyt+1;jj<=nloc;++jj)  kidcyt[ii][jj-nloc+cyt] = mumgam[ii][jj];  
	  printf(" %d ", ii);
	  print_geno_cyt(kidgen[ii], kidcyt[ii], nlo, cyt);
	}
    }
  
  if (marker_type==2) /* Dominant markers*/
    { 
      int **kidgen; 	/* genotypic data */
      pfd=(double *)malloc((nloc-cyt+1) * sizeof(double));
      read_loci_dom_cum(nloc, cyt, nallc, pfd, &pfc, &fcumc);
      kidgen=(int **)malloc((nkid+1) * sizeof(int *));
      for (i=1;i<=nkid;++i) kidgen[i]=(int *)malloc((nlo) * sizeof(int));
      dadgam=(int **)malloc((nkid+1) * sizeof(int *));
      mumgam=(int **)malloc((nkid+1) * sizeof(int *));
      parcyt=(int **)malloc((nkid+1) * sizeof(int *));
      kidcyt=(int **)malloc((nkid+1) * sizeof(int *));
  
      for (i=1; i<=nkid; i++) 
	{    
	  kidgen[i]=(int *)malloc((nlo+1) * sizeof(int));
	  dadgam[i]=(int *)malloc((nlo+1) * sizeof(int));
	  mumgam[i]=(int *)malloc((nlo+1) * sizeof(int));
	  kidcyt[i]=(int *)malloc((cyt+1) * sizeof(int));
	  parcyt[i]=(int *)malloc((cyt+1) * sizeof(int));
	}

      /* Cr�ation de descendants*/
      printf("\n Simulated individual n�, genotype\n");
      for (ii=1;ii<=nkid;++ii)
	{ 
	  name_kid[ii]=ii;
	  gamete_hp_dom(mumgam[ii], nlo, pfd, cyt, nallc, fcumc);            /* Simulation des gam�tes parentaux : */ 
	  gamete_hp_dom(dadgam[ii], nlo, pfd, cyt, nallc, fcumc); 
	  for (jj=1;jj<=nlo;++jj)
	    {
	      if (mumgam[ii][jj] == 0 && dadgam[ii][jj] == 0) kidgen[ii][jj] = 0;  /* ii :enfant, jj locus*/
	      else if(mumgam[ii][jj] == 1 || dadgam[ii][jj] == 1) kidgen[ii][jj] = 1; 
	    }  	  
	  if  (cyt > 0)
	    for (jj=nloc-cyt+1;jj<=nloc;++jj)  kidcyt[ii][jj-nloc+cyt] = mumgam[ii][jj];             
	  printf("\n %d ", ii);
	  for (jj=1;jj<=nlo;++jj) printf(" %d ", kidgen[ii][jj]);
	  for (jj=1;jj<=cyt; ++jj) printf ("  %d", kidcyt[ii][jj]); 
	}
	  printf("\n");
    }
  return(0);
}
