#include <math.h>
#include <stdio.h>
#include "nrutil.h"
#include "read.h"
#include "sort.h"
#include "genetic.h"
#include "likely.h"

/**************************************************************************

Program to tabulate possible parent pairs, and log-likelihoods, for given
sets of juveniles, potential fathers, and potential mothers.
Ordered to find best 4 mums, best 4 dads, best 4 pairs.
Includes possibility of X-linked loci.

Modified from earlier programs; July 1996

Programme modifi� pour consid�rer des hermaphrodites, et int�grer possibles 
autof�condations 25/11/98

*** Pourcentage d'erreur ajout� dans les calculs 26/11/98
(inspir� de Marshall et al 1998)
utilis� en lan�ant le programme suivi de < fichier
le fichier contient 
nb_loc nb_all_loc1  freq_all1_loc1 freq_all2_loc2.... nb_all_loc2  etc...
nb_parents nb_desc
num�ro_parent1 all1_loc1 all2_loc1 etc... 
le fichier likh est un fichier d'exemple pour ce programme
Donne les 8 meilleurs parents et couples dans l'ordre.
Modifi� le 18/12/98 pour prendre les log 
de la vraisemblance

28/7/99 Adapt� avec donn�es manquantes, suppression du x-linked indicator,
qui, reconnaissez-le, nous emcombrait.

3/7/2000 Mis en forme (malloc) pour tcl/tk
first argument calculation error, 
second, number of best parents /parent pairs displayed
***************************************************************************/

extern double rans();
extern double pow();
extern double log();


main (int argc, char *argv[])
{   
  int i,j,k, kk, tp1,tp2, npop, *listp, npopp, miss;
  int nloc, *nall, cyt, *nallc, nkid, npar, *name_kid, *name_par, nb, **kidcyt, **parcyt;
  double  *best_pars, *best_pairs[2], *miss_par, *match_par, *match_pair, *loclod, *loclod1;
  double *score, *pcore, cc, bc, pc;
  double **pf, **pfc, E, F;    /* cf exclude.c   double pointeur suffit */
  Geno **kidgen, **pargen;
  /* si tu declares le pointeur dans le main il suffit d'avoir un double pointeur */

  E=atof(argv[1]);
  nb=atoi(argv[2]);
  cyt=atoi(argv[3]);
  F=atof(argv[4]); 
  miss=atoi(argv[5]);
 
  scanf ("%d", &nloc);
  nall=(int *)malloc((nloc-cyt+1)*sizeof(int));
  if (cyt > 0) nallc=(int *)malloc((cyt+1)*sizeof(int));
  read_loci (nloc, nall, &pf, cyt, nallc, &pfc);
  
  printf("\n Number of loci: %d",nloc);
  printf("\n Among them, number of cytoplasmic markers: %d",cyt);
  scanf ("%d %d", &npar, &nkid);  
  printf ("\n Number of parents: %d offspring: %d\n", npar,nkid);  
  printf("\n Lod calculation error: %f, Heterozygote deficit: %f", E, F); 
  printf("\n Number of best parent / pair displayed: %d\n", nb); 
  printf ("\n For each likely parent: \n");
  printf ("\n -Parent name -Parent score");
  printf ("\n -Nb of missing allele in parent / nb of nuclear loci with a > 0 contribution in score ");
  printf ("\n   / nb of parent-offspring mismatch among them\n"); 
  printf ("\n For each likely parent pair:\n");
  printf ("\n -Names of parents -Parent pair score");
  printf ("\n -Nb of nuclear loci with a > 0 contribution in score / nb of pair-offspring mismatch among them\n"); 


  listp=(int *)malloc((npar+1)*sizeof(int));
  name_kid=(int *)malloc((nkid+1)*sizeof(int));
  name_par=(int *)malloc((npar+1)*sizeof(int));
  kidgen=(Geno **)malloc((nkid+1) * sizeof(Geno *));
  pargen=(Geno **)malloc((npar+1) * sizeof(Geno *));
  best_pars=(double *)malloc((nb+2)*sizeof(double));
  best_pairs[0]=(double *)malloc((nb+2)*sizeof(double));
  best_pairs[1]=(double *)malloc((nb+2)*sizeof(double));
  score=(double *)malloc((nb+2)*sizeof(double));
  pcore=(double *)malloc((nb+2)*sizeof(double));
  miss_par=(double *)malloc((nb+2)*sizeof(double));
  match_par=(double *)malloc((nb+2)*sizeof(double));
  match_pair=(double *)malloc((nb+2)*sizeof(double));
  loclod=(double *)malloc((nb+2)*sizeof(double));
  loclod1=(double *)malloc((nb+2)*sizeof(double));
  kidcyt=(int **)malloc((nkid+1) * sizeof(int *));
  parcyt=(int **)malloc((npar+1) * sizeof(int *));

  
  for (i=1; i<=nkid; i++) 
    {
      kidgen[i]=(Geno *)malloc((nloc-cyt+1) * sizeof(Geno));
      kidcyt[i]=(int *)malloc((cyt+1) * sizeof(int));
    }
  for (i=1; i<=npar; i++)  
    {
      pargen[i]=(Geno *)malloc((nloc-cyt+1) * sizeof(Geno));
      parcyt[i]=(int *)malloc((cyt+1) * sizeof(int));
    }
  
  read_gen_dat(npar, nkid, name_kid, name_par, nloc, cyt, kidgen, pargen, kidcyt, parcyt);
  
  /* V�rification affichages */

/*   for(i=1;i<=nloc;i++) */
/*     { */
/*       for(j=1;j<=nall[i];j++) printf(" %g ",pf[i][j]); */

/*       printf("\n"); */
/*     } */
/*    for(i=1;i<=4;i++)  */
/*      {  */
/*        printf("%d ",name_par[i]);  */
/*        for(j=1;j<=nloc;j++) printf(" %d %d  ",pargen[i][j].g1,pargen[i][j].g2);  */
/*        printf("\n");  */
/*      }  */
/*   for(i=1;i<=nkid;i++) */
/*     { */
/*       printf("%d ",name_kid[i]); */
/*       for(j=1;j<=nloc;j++) printf(" %d %d  ",kidgen[i][j].g1,kidgen[i][j].g2); */
/*       printf("\n"); */
/*     } */

  
  for (i=1; i<=nkid; ++i)  
    {
      printf ("\n kid %d :", name_kid[i] ); 
      printf(" (%.0f missing data on %d alleles)", missing(kidgen[i], nloc-cyt), 2*(nloc-cyt));
  
      npopp=0; npop=0;  bc=1.0E6; pc = 1.0E6; /* Number Possible Parent / Pairs */
      
      for (k=0; k< nb+1; k++) 
	{   /* et PAS k< 11 !!!!   */
	  score[k]=0.0; 
	  best_pars[k] =0; pcore[k]=0.0;
	  best_pairs[0][k]=0; best_pairs[1][k]=0; 
	  miss_par[k] =0; 
	  match_par[k] =0; match_pair[k] =0; 
	  loclod[k] =0; loclod1[k] =0;
	}
      
      for (j=1; j<=npar; ++j) 
	{
	  if (name_par[j] != name_kid[i])
	  {  
	   /*printf("\n kid %d par %d ", i, j);  */
	  cc = uparchk(nloc-cyt, *(kidgen+i), pargen[j], pf, E, F, nall, miss); /* proba maternit�:non maternit�*/
	  if (cyt > 0) cc+=likr_cyt(cyt, kidcyt[i], parcyt[j], pfc, E, nallc);
	  /* 	  printf(" cc=%f \n",cc); */
	  if (cc > 0.0 && finite(cc)==1) 
	    {
	      npop++; 
	      listp[npop]=j; /*rang de tous les parents � proba > 0,npop observations*/
	      if (npop < nb+1)
		{ 
		  best_pars[npop] = name_par[j]; 
		  score[npop]=cc;
		  miss_par[npop]=missing(pargen[j], nloc-cyt);
		  match_par[npop]=match1(kidgen[i], pargen[j],nloc-cyt);
		  loclod[npop]=loc_lod_1par(nloc-cyt, kidgen[i], pargen[j], pf, E, F, nall, miss);
		  if (cc < bc)  bc = cc; 
		} 
	      /* bc sera le score min parmi les 8 premiers >0 */
	      else 
		{ 
		  if (cc > bc) 
		    {
		      /*score sup�rieur au min pr�c�dent*/
		      k = dexmin(score, nb); /* rang du score minimum parmi les 8*/
		      best_pars[k] = name_par[j];  /*on remplace la m�re k  ...  */
		      score[k] = cc;               /* par la j, qui est meilleure */ 
		      miss_par[k]=missing(pargen[j], nloc-cyt);
		      match_par[k]=match1(kidgen[i], pargen[j],nloc-cyt);
		      loclod[k]=loc_lod_1par(nloc-cyt, kidgen[i], pargen[j], pf, E, F, nall, miss);
		      bc = valmin(score, nb); 
		    } 
		}          /*nouveau score min*/
	    }              /* � la fin on a les 8 meilleures des nmum*/
	}
    }
      /* Ins�rer un tri sur best_pars[k] et score[k] */
      sort5(nb,score,best_pars,miss_par, match_par, loclod);
      /*       printf ("\n"); */
      /*       for (k=nb; k>=1; --k) printf ("\t %.0f",best_pars[k]); printf ("\n"); */
      /*       for (k=nb; k>=1; --k) printf ("\t %.2g",score[k]); printf ("\n"); fflush(stdout); */
      /*       for (k=nb; k>=1; --k) printf ("\t %.0f/%.0f/%.0f", miss_par[k], loclod[k], match_par[k]);  printf ("\n");  */
      
      printf ("\n %d likely parent(s)", npop);
      if (npop>0)
	{
	  if(npop > nb) 
	    for (k=nb; k>=1; k--)   
	      {
		printf("\n %d \t %.0f \t %.2f \t ", name_kid[i], best_pars[k], score[k]);  
		printf ("%.0f/%.0f/%.0f ", miss_par[k], loclod[k], nloc-cyt-match_par[k]);   
	      }
	  else for (k=nb; k>=nb-npop+1; k--)   
	    { 
	      printf("\n %d \t %.0f \t %.2f \t ", name_kid[i], best_pars[k], score[k]);  
	      printf ("%.0f/%.0f/%.0f ", miss_par[k], loclod[k], nloc-cyt-match_par[k]); 
	    } 
	}
      printf ("\n");
      
      pc=1.0E6; for (k=0; k< nb+1; ++k)  pcore[k]=0.0; 
      for (j=1; j<=npop; ++j)    
	{  
	  tp1 = listp[j];
	  if (npop > 0) 
	    {
	      for (kk=1; kk<=npop; ++kk) 
		{
		  tp2 = listp[kk];
		  if (tp2>=tp1) 
		    {
		      cc = pparchk(nloc-cyt, kidgen[i], pargen[tp1], pargen[tp2], pf, E, F, nall, miss); /*dans boucle en j*/
		      if (cyt > 0) cc+=likr_pair_cyt(cyt, kidcyt[i],parcyt[tp1],parcyt[tp2], pfc, E, nallc);
		      if (cc > 0.0 && finite(cc)==1) 
			{		      
			  ++npopp; 
			  if (npopp < nb+1) 
			    {
			      best_pairs[0][npopp] = *(name_par+tp1); 
			      best_pairs[1][npopp] = *(name_par+tp2); 
			      pcore[npopp]=cc; 
			      match_pair[npopp]=match2(kidgen[i],pargen[tp1],pargen[tp2],nloc-cyt);
			      loclod1[npopp]=loc_lod_2par(nloc-cyt, kidgen[i],pargen[tp1],pargen[tp2],pf, E, F, nall, miss);
			      
			      if (cc < pc)  pc = cc; 
			    } 
			  else  
			    { 
			      if (cc > pc)  
				{
				  k = dexmin(pcore, nb);
				  best_pairs[0][k] = *(name_par+tp1); 
				  best_pairs[1][k] = *(name_par+tp2); 
				  pcore[k] = cc;
				  match_pair[k]=match2(kidgen[i],pargen[tp1],pargen[tp2],nloc-cyt);
				  loclod1[k]=loc_lod_2par(nloc-cyt, kidgen[i],pargen[tp1],pargen[tp2],pf, E, F, nall, miss);
				  pc = valmin(pcore, nb); 
				} 
			    }
			}
		    }
		} 
	    } 
	}
      
      sort5(nb,pcore,best_pairs[0],best_pairs[1], match_pair, loclod1);			
      /*      for (k=nb; k>=1; --k)  */
      /* 	printf ("\t (%3.0f %3.0f)",best_pairs[0][k], best_pairs[1][k]); printf ("\n");	 */
      /* 	for (k=nb; k>=1; --k) printf ("\t    %-7.2g",pcore[k]); printf ("\n"); */
      /* 	for (k=nb; k>=1; --k) printf ("\t  %3.0f /%2.0f", loclod1[k], match_pair[k]);  printf ("\n");  */
      printf (" %d likely parent pair(s)", npopp);
      if (npopp>0)
	{
	  if(npopp > nb) 
	    for (k=nb; k>=1; k--)   
	      {
		printf("\n %d \t (%.0f %.0f) \t %.2f \t ", name_kid[i], best_pairs[0][k], best_pairs[1][k], pcore[k]);  
		printf ("%.0f/%.0f ", loclod1[k], nloc-cyt-match_pair[k]);   
	      }
	  else for (k=nb; k>=nb-npopp+1; k--)   
	    { 
	      printf("\n %d \t (%.0f %.0f) \t %.2f \t ", name_kid[i], best_pairs[0][k], best_pairs[1][k], pcore[k]);  
	      printf ("%.0f/%.0f ", loclod1[k], nloc-cyt-match_pair[k]);   
	    } 
	}	
      printf ("\n");
    }
  return(0);
  
}





