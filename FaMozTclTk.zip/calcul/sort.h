/**************************************************************************************
  18/6/01 
  The sort library contains programs to sort data adapted from Numerical recipies in C 
  
*************************************************************************************/
extern double log();


/* Les trois programmes suivants indexx et sort2 et sort3  servent � faire le tri des r�sultats */


#define SWAP(a,b) itemp=(a);(a)=(b);(b)=itemp; 
#define MM 7 
#define NSTACK 50 

void indexx(unsigned long n, double arr[], unsigned long indx[]) 
     
     /* Indexes an array arr[1..n], i.e., outputs the array indx[1..n] */ 
     /*such that arr[indx[j]] is  */
     /* in ascending order for j = 1; 2; : : : ; N . The input quantities */ 
     /*n and arr are not changed.  */
{ 
  unsigned long i,indxt,ir=n,itemp,j,k,l=1; 
  int jstack=0,*istack; 
  double a; 
  
  istack=ivector(1,NSTACK); 
  for (j=1;j<=n;j++) indx[j]=j; 
  for (;;) { 
    if (ir-l < MM) { 
      for (j=l+1;j<=ir;j++) { 
	indxt=indx[j]; 
	a=arr[indxt]; 
	for (i=j-1;i>=l;i--) { 
	  if (arr[indx[i]] <= a) break; 
	  indx[i+1]=indx[i]; 
	} 
	indx[i+1]=indxt; 
      } 
      if (jstack == 0) break; 
      ir=istack[jstack--]; 
      l=istack[jstack--]; 
    } else { 
      k=(l+ir) >> 1; 
      SWAP(indx[k],indx[l+1]); 
      if (arr[indx[l]] > arr[indx[ir]]) { 
	SWAP(indx[l],indx[ir]) 
	  } 
      if (arr[indx[l+1]] > arr[indx[ir]]) { 
	SWAP(indx[l+1],indx[ir]) 
	  } 
      if (arr[indx[l]] > arr[indx[l+1]]) { 
	SWAP(indx[l],indx[l+1]) 
	  } 
      i=l+1; 
      j=ir; 
      indxt=indx[l+1]; 
      a=arr[indxt]; 
      for (;;) { 
	do i++; while (arr[indx[i]] < a); 
	do j--; while (arr[indx[j]] > a); 
	if (j < i) break; 
	SWAP(indx[i],indx[j]) 
	  } 
      indx[l+1]=indx[j]; 
      indx[j]=indxt; 
      jstack += 2; 
      if (jstack > NSTACK) nrerror("NSTACK too small in indexx."); 
      if (ir-i+1 >= j-l) { 
	istack[jstack]=ir; 
	istack[jstack-1]=i; 
	ir=j-1; 
      } else { 
	istack[jstack]=j-1; 
	istack[jstack-1]=l; 
	l=i; 
      } 
    } 
  } 
  free_ivector(istack,1,NSTACK); 
} 

void sort2(unsigned long n, double ra[],double rb[])

/* Sorts an array ra[1..n] into ascending numerical order while making the corresponding re-  */
/* arrangements of the arrays rb[1..n]. An index table is constructed via the  */
/* routine indexx.  */

{ 
  void indexx(unsigned long n, double arr[], unsigned long indx[]); 
  unsigned long j,*iwksp; 
  double *wksp;
  iwksp=lvector(1,n); 
  wksp=vector(1,n); 
  indexx(n,ra,iwksp);                                /* Make the index table. */ 
  for (j=1;j<=n;j++) wksp[j]=ra[j];                  /*  Save the array ra.  */
  for (j=1;j<=n;j++) ra[j]=wksp[iwksp[j]];           /*  Copy it back in rearranged order */ 
  for (j=1;j<=n;j++) wksp[j]=rb[j];                  /*  Do it to rb. */ 
  for (j=1;j<=n;j++) rb[j]=wksp[iwksp[j]]; 
  free_vector(wksp,1,n); 
  free_lvector(iwksp,1,n); 
} 

void sort3(unsigned long n,  double ra[],double  rb[], double  rc[])

     /* Sorts an array ra[1..n] into ascending numerical order while making */ 
     /*the corresponding re-arrangements of the arrays rb[1..n] and rc[1..n]. */ 
     /* An index table is constructed via the  routine indexx.  */

{ 
  void indexx(unsigned long n, double arr[], unsigned long indx[]); 
  unsigned long j,*iwksp; 
  double /*double*/ *wksp;
  iwksp=lvector(1,n); 
  wksp=vector(1,n); 
  indexx(n,ra,iwksp);                                /* Make the index table. */ 
  for (j=1;j<=n;j++) wksp[j]=ra[j];                  /*  Save the array ra.  */
  for (j=1;j<=n;j++) ra[j]=wksp[iwksp[j]];           /*  Copy it back in rearranged order */ 
  for (j=1;j<=n;j++) wksp[j]=rb[j];                  /*  Do it to rb. */ 
  for (j=1;j<=n;j++) rb[j]=wksp[iwksp[j]]; 
  for (j=1;j<=n;j++) wksp[j]=rc[j];                  /* Do it to rc. */ 
  for (j=1;j<=n;j++) rc[j]=wksp[iwksp[j]]; 
  free_vector(wksp,1,n); 
  free_lvector(iwksp,1,n); 
} 


void sort4(unsigned long n,  double ra[],double  rb[], double  rc[], double  rd[])

     /* Sorts an array ra[1..n] into ascending numerical order while making */ 
     /*the corresponding re-arrangements of the arrays rb[1..n] and rc[1..n]. and rd[1..n] */ 
     /* An index table is constructed via the  routine indexx.  */

{ 
  void indexx(unsigned long n, double arr[], unsigned long indx[]); 
  unsigned long j,*iwksp; 
  double /*double*/ *wksp;
  iwksp=lvector(1,n); 
  wksp=vector(1,n); 
  indexx(n,ra,iwksp);                                /* Make the index table. */ 
  for (j=1;j<=n;j++) wksp[j]=ra[j];                  /*  Save the array ra.  */
  for (j=1;j<=n;j++) ra[j]=wksp[iwksp[j]];           /*  Copy it back in rearranged order */ 
  for (j=1;j<=n;j++) wksp[j]=rb[j];                  /*  Do it to rb. */ 
  for (j=1;j<=n;j++) rb[j]=wksp[iwksp[j]]; 
  for (j=1;j<=n;j++) wksp[j]=rc[j];                  /* Do it to rc. */ 
  for (j=1;j<=n;j++) rc[j]=wksp[iwksp[j]]; 
  for (j=1;j<=n;j++) wksp[j]=rd[j];                  /* Do it to rd. */ 
  for (j=1;j<=n;j++) rd[j]=wksp[iwksp[j]]; 
  free_vector(wksp,1,n); 
  free_lvector(iwksp,1,n); 
} 

void sort5(unsigned long n,  double ra[],double  rb[], double  rc[], double  rd[], double re[])

     /* Sorts an array ra[1..n] into ascending numerical order while making */ 
     /*the corresponding re-arrangements of the arrays rb[1..n] and rc[1..n]. rd[1..n] and re[1..n] */ 
     /* An index table is constructed via the  routine indexx.  */

{ 
  void indexx(unsigned long n, double arr[], unsigned long indx[]); 
  unsigned long j,*iwksp; 
  double /*double*/ *wksp;
  iwksp=lvector(1,n); 
  wksp=vector(1,n); 
  indexx(n,ra,iwksp);                                /* Make the index table. */ 
  for (j=1;j<=n;j++) wksp[j]=ra[j];                  /*  Save the array ra.  */
  for (j=1;j<=n;j++) ra[j]=wksp[iwksp[j]];           /*  Copy it back in rearranged order */ 
  for (j=1;j<=n;j++) wksp[j]=rb[j];                  /*  Do it to rb. */ 
  for (j=1;j<=n;j++) rb[j]=wksp[iwksp[j]]; 
  for (j=1;j<=n;j++) wksp[j]=rc[j];                  /* Do it to rc. */ 
  for (j=1;j<=n;j++) rc[j]=wksp[iwksp[j]]; 
  for (j=1;j<=n;j++) wksp[j]=rd[j];                  /* Do it to rd. */ 
  for (j=1;j<=n;j++) rd[j]=wksp[iwksp[j]]; 
  for (j=1;j<=n;j++) wksp[j]=re[j];                  /* Do it to re. */ 
  for (j=1;j<=n;j++) re[j]=wksp[iwksp[j]]; 
  free_vector(wksp,1,n); 
  free_lvector(iwksp,1,n); 
} 

/* Find min and max */

int dexmin( a, n)
     double *a; 
     int n;
{
  int i,k; double cc=1.0E6;
  for (i=1; i<=n; ++i)
    if (a[i] < cc) 
      {
	k=i;
	cc=a[i]; 
      }
  return(k); 
}

double valmin( a, n)
     double *a; 
     int n;
{
  int i;
  double cc=1.0E6;
  for (i=1; i<=n; ++i)
    if (finite(a[i])==1 && a[i] > 0.00000) if (a[i] < cc) cc=a[i]; 
  return(cc); 
}

double valmin_neg ( a, n)
     double *a; 
     int n;
{
  int i;
  double cc=1.0E6;
  for (i=1; i<=n; ++i)
    if (finite(a[i])==1) if (a[i] < cc) cc=a[i]; 
  return(cc); 
}

double valmax(a, n)
     double *a;
     int n;
{
  int i; 
  double cc=0.0;
  for (i=1; i<=n; ++i) 
    if (finite(a[i])==1) if (a[i] > cc) cc=a[i]; 
  return(cc); 
}

int valmax_int(a, n)
     int *a;
     int n;
{
  int i; 
  int cc=0;
  for (i=1; i<=n; ++i) 
    if (a[i] > cc) cc=a[i]; 
  return(cc); 
}


/* Creating a table to draw an histogram of ONE series of data*/
/* First allocate memory to all elements */
/* Define the number of classes , see "Modern applied statistics with Splus, pages 126 and 137 */

void hist1 (type1, n, n1)
     double *type1;
     int n;
     char *n1;
{
  double  *class1, *name_class1;
  double *fr_elt_class1, *frcum_elt_class1;
  int  *nb_elt_class1, sizeH, nb_tot1, i, j;
  double class_min1, class_max1, x, y, size_class1;

  sizeH= 2*(log(n)/log(2)+1);
  /*printf("\nsizeH : %d\n",sizeH);*/
  
  class1=(double *)malloc((sizeH +1)*sizeof(double)); 
  name_class1=(double *)malloc((sizeH +1)*sizeof(double)); 
  fr_elt_class1=(double *)malloc((sizeH +1)*sizeof(double)); 
  frcum_elt_class1=(double *)malloc((sizeH +1)*sizeof(double)); 
  nb_elt_class1=(int *)malloc((sizeH +1)*sizeof(int)); 


  class_min1= valmin_neg(type1,n);
  class_max1 = valmax(type1,n);

  /* To avoid extreme cases where default value of valmin and valmax have been kept */
  if (class_min1 > class_max1) 
    {
      class_min1=0; 
      class_max1=0;
    }

  /*printf("\nclassmin1 %f, max1 %f, min2 %f, max2 %f\n",class_min1,class_max1,class_min2,class_max2);*/
  
  /* Initializations */
  for (i=0; i<=sizeH; i++)
    {
      class1[i]=0.0;
      fr_elt_class1[i]=0.0;
      nb_elt_class1[i]=0;
      nb_tot1=0;
    }
  
  
  x=sizeH;
  size_class1 = (class_max1 - class_min1)/x;
  
  /*printf("\nsize_class1 %f\n",size_class1);*/
    
  for (i=0; i<=sizeH; i++) 
    {
      x=i; class1[i]=class_min1 + x*size_class1; 
      /*printf("\nclass1 n� %d value %f\n",i, class1[i]);*/
    }

  /* Fill the table */
  for (i=0; i<=(sizeH-1); i++)
    {
      for (j=1; j<=n; j++)	
	{
	  if (i==0)
	    {
	      if (*(type1+j) >= class1[i])
		  {
		    if  (*(type1+j) <= class1[i+1])			 
		      {
			nb_elt_class1[i]+=1;
			/*printf("\nclass %d individual %d type1 %f, nb_elt %d\n",i,j,*(type1+j), nb_elt_class1[i]);*/
		      }
		  }
	    }
	  else
	    {
	      if (*(type1+j) > class1[i]) 
		{
		  if (*(type1+j) <= class1[i+1])
		      {			  		
			nb_elt_class1[i]+=1;
			/*printf("\nclass %d individual %d type1 %f, nb_elt %d\n",i,j,*(type1+j), nb_elt_class1[i]);*/
		      }
		}
	    }
	}
    }
  for (i=0; i<=(sizeH-1); i++)  nb_tot1+=nb_elt_class1[i];
  for (i=0; i<=(sizeH-1); i++)  frcum_elt_class1[i]=0.0;

  i=0; 
  x = nb_elt_class1[i]; 
  y = nb_tot1;
  fr_elt_class1[i] = x/y;
  frcum_elt_class1[i]= fr_elt_class1[i];

  for (i=1; i<=(sizeH-1); i++)  
    {
      x= nb_elt_class1[i]; 
      y=nb_tot1;
      fr_elt_class1[i]=x/y;
      frcum_elt_class1[i]= frcum_elt_class1[i-1] + fr_elt_class1[i];
    }
  

  /* Create the name of the class = the middle point between class[i]and class[i+1] */
  for (i=1; i<=sizeH; i++) 
    {
      x=i;
      name_class1[i]=class_min1 + (2*x-1)*0.5*size_class1;
    }
  
  printf("\n %s scores class names, class sizes, class frequencies and cumulated class frequencies \n", n1);   
  for (j=1; j<=sizeH; j++) printf("\t%.2f ", name_class1[j]);
  printf("\n");
  for (j=0; j<=sizeH-1; j++) printf("\t %d", nb_elt_class1[j]);   
  printf("\n"); 
  for (j=0; j<=sizeH-1; j++) printf("\t%.2f ", fr_elt_class1[j]);
  printf("\n"); 
  for (j=0; j<=sizeH-1; j++) printf("\t%.2f", frcum_elt_class1[j]);
  printf("\n"); 
}




