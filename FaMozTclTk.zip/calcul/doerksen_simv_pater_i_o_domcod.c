#include <math.h>
#include <stdio.h>
/* #include <time.h> */  /* pour initialiser le g�n�rateur de nombres al�atoires*/
#include <sys/time.h>
#include <unistd.h>
#include <stdlib.h>     
#include "nrutil.h"
#include "read.h"
#include "sort.h"
#include "alea.h"
#include "genetic.h"
#include "likely.h"

/**************************************************************************
14/2/2 Simulate paternity with cod and dominant markers
***************************************************************************/

extern double rans();
extern double log();


main (int argc, char *argv[])
{   
  char *name1, *name2, *name3;  
  int nloc, nlocd, *nall, cyt, *nallc, cytmater, miss;
  double **pf, **pfc, *pfd, **fcum, **fcumc, E, Es, F, f;	         /* loci details; prior freqs; fr�quences cumul�es*/
  /* E pourcentage d'erreurs de g�notypage dans le calcul de vrsb*/
  /* Es pourcentage d'erreurs de g�notypage dans les simulations */ 
  int nkid, nkid1, npar1, npar2, **kidgend, **pargend1, **pargend2;			 /*number of kids, parents */
  int  *name_kid, *name_par1, *name_par2 , **parcyt, **kidcyt;            /* individual names etc. */
  Geno **kidgen, **pargen1, **pargen2; 	/* genotypic data */
  Geno *kidpar;                        /* nom des vrais parents du descendant*/
  int **dadgam, **mumgam, **dadgamd, **mumgamd;      /* Gam�tes paternel et paternel*/
  int i,j,k,ii,jj, iii, dad, mum, mere, bdp, mdp, d; 
  int npod, io;
  double  best_dads[10], bp, bdpf;
  double score[10], cc, bc;
  double *bestf, x, y, *deltatrue, *deltawrong, *deltawrongi, *deltawrongo1,*deltawrongo2 , deltamax, delta1, delta2;

  /* Initialisation du g�n�rateur de nombres al�atoires :*/
  long m;
  float rand;
  struct timeval temps; 
  struct timezone  zone;
  gettimeofday(&temps,&zone);
  m=-temps.tv_usec; 
  rand=ran3(&m);
  
  name1="Best fathers";
  name2="Delta, true fathers";
  name3="Delta, wrong fathers";

  /* Reading arguments */
  nkid=atoi(argv[1]);
  E=atof(argv[2]); 
  Es=atof(argv[3]);
  cyt=atoi(argv[4]);
  cytmater=atoi(argv[5]); /* Maternal heredity of cytoplasme : yes=1 */
  io=atoi(argv[6]); /*=1 : sample fathers among genotyped, =2 sample according to allele freq */
  F=atof(argv[7]); 
  miss=atoi(argv[8]);
  
  /* Lecture des donn�es locus */
  scanf ("%d", &nloc);
  nall=(int *)malloc((nloc-cyt+1)*sizeof(int));
  if (cyt > 0) nallc=(int *)malloc((cyt+1)*sizeof(int));
  read_loci_cum (nloc, nall, &pf, &fcum, cyt, nallc, &pfc, &fcumc);
  scanf ("%d", &nlocd);
  pfd=(double *)malloc((nlocd+1) * sizeof(double));
  read_loci_dom_cum (nlocd, 0, nallc, pfd, &pfc, &fcumc);
  printf("\n Number of loci, codominant %d, dominant %d, cytoplasmic %d",nloc-cyt, nlocd, cyt);
  
  scanf ("%d %d %d", &npar1, &npar2, &nkid1);
  printf ("\n Number of mothers: %d  Number of fathers:%d Number of simulated offspring: %d\n", npar1, npar2,nkid);

  if (io==1) printf("\n***** Simulating offpring with father from genotyped parents *****\n");
  if (io==2) printf("\n***** Simulating offpring with father according to allele frequencies *****\n");

  printf("\n Simulation error %f, Lod calculation error %f, Heterozygote deficit %f\n", Es, E, F);    
  
  name_kid=(int *)malloc((nkid+1)*sizeof(int));
  name_par1=(int *)malloc((npar1+1)*sizeof(int));
  name_par2=(int *)malloc((npar2+1)*sizeof(int));
  kidgen=(Geno **)malloc((nkid+1) * sizeof(Geno *));
  kidpar=(Geno *)malloc((nkid+1) * sizeof(Geno));
  pargen1=(Geno **)malloc((npar1+1) * sizeof(Geno *));
  pargen2=(Geno **)malloc((npar2+1) * sizeof(Geno *));
  mumgam=(int **)malloc((npar1+1) * sizeof(int *));
  mumgamd=(int **)malloc((npar1+1) * sizeof(int *));
  kidcyt=(int **)malloc((nkid+1) * sizeof(int *));
  kidgend=(int **)malloc((nkid+1) * sizeof(int *));
  pargend1=(int **)malloc((npar1+1) * sizeof(int *));
  pargend2=(int **)malloc((npar2+1) * sizeof(int *));
 
  if (io==1) j=npar1;
  else if (io==2) j=nkid;
  dadgam=(int **)malloc((j+1) * sizeof(int *));
  dadgamd=(int **)malloc((j+1) * sizeof(int *));
  parcyt=(int **)malloc((j+1) * sizeof(int *));

  for (i=1; i<=j; i++)  
    {
      dadgam[i]=(int *)malloc((nloc+1) * sizeof(int));
      dadgamd[i]=(int *)malloc((nlocd+1) * sizeof(int));
      parcyt[i]=(int *)malloc((cyt+1) * sizeof(int));
    }  

  for (i=1; i<=nkid; i++)  
    {
      kidgen[i]=(Geno *)malloc((nloc-cyt+1) * sizeof(Geno));
      kidgend[i]=(int *)malloc((nlocd+1) * sizeof(int));
      kidcyt[i]=(int *)malloc((cyt+1) * sizeof(int));
    }
  for (i=1; i<=npar1; i++)  
    {
      pargen1[i]=(Geno *)malloc((nloc-cyt+1) * sizeof(Geno));
      pargend1[i]=(int *)malloc((nlocd+1) * sizeof(int));
      mumgam[i]=(int *)malloc((nloc+1) * sizeof(int));
      mumgamd[i]=(int *)malloc((nlocd+1) * sizeof(int));
    }
    for (i=1; i<=npar2; i++)  
    {
      pargen2[i]=(Geno *)malloc((nloc-cyt+1) * sizeof(Geno));
      pargend2[i]=(int *)malloc((nlocd+1) * sizeof(int));
    }
  
  for (i=1; i<=npar1; ++i ) 
    {
      scanf("%d",name_par1+i);
      read_gen (pargen1[i] ,nloc-cyt); 
      if (cyt > 0)
	for (j=(1); j<= cyt; ++j) 
	  {
	    scanf ("%d",&d);
	    parcyt[i][j]=d; 
	  }
      read_gen_dom ( pargend1[i],nlocd);   
    }
  for (i=1; i<=npar2; ++i ) 
    {
      scanf("%d",name_par2+i);
      read_gen ( pargen2[i] ,nloc-cyt); 
      if (cyt > 0)
	for (j=(1); j<= cyt; ++j) 
	  {
	    scanf ("%d",&d);
	    parcyt[i][j]=d; 
	  }
      read_gen_dom ( pargend2[i],nlocd);   
    }
 

  /*Initialisations*/
  bdp=0; mdp=0; 
  
  
  /* Cr�ation de descendants*/
  printf("\n Simulation step");

  if(io==1)
    {
      for (ii=1;ii<=nkid;++ii)
	{
	  name_kid[ii]=ii;
	  mum = 1+(int)(npar1*alea()) ;         /* Tirage al�atoire des deux parents : */
	  f=alea();
	  if (f<=2*F/(1+F)) dad=mum;         /*selfing at equilibrium = [2*F/(1+F)] */
	  else dad = 1+(int)(npar2*alea()) ;         /* nombre entier al�atoire dans [1,npar] */ 
	  gamete(pargen1[mum],mumgam[mum],nloc,nall,Es, cyt, nallc, parcyt[mum]); /* Simulation des gam�tes parentaux : */ 
	  gamete_dom(pargend1[mum],mumgamd[mum], parcyt[mum], nlocd, Es, pfd, 0, nallc); 
	  gamete(pargen2[dad],dadgam[dad],nloc,nall,Es, cyt, nallc, parcyt[dad]);
	  gamete_dom(pargend2[dad],dadgamd[dad], parcyt[dad], nlocd, Es, pfd, 0, nallc); 
	  kidpar[ii].g1=name_par1[mum]; 
	  kidpar[ii].g2=name_par2[dad];  
	  for (jj=1;jj<=nloc-cyt;++jj)
	    {
	      kidgen[ii][jj].g1=mumgam[mum][jj];  /* ii :enfant, jj locus*/
	      kidgen[ii][jj].g2=dadgam[dad][jj];  
	    }  
	  if  (cyt > 0)
	    { 
	      if (cytmater==1) for (jj=nloc-cyt+1;jj<=nloc;++jj)  kidcyt[ii][jj-nloc+cyt] = mumgam[mum][jj];  
	      else if (cytmater==0) for (jj=nloc-cyt+1;jj<=nloc;++jj)  kidcyt[ii][jj-nloc+cyt] = dadgam[dad][jj];  
	    }
	  for (jj=1;jj<=nlocd;++jj)
	    {
	      if (mumgamd[mum][jj] == 0 && dadgamd[dad][jj] == 0) kidgend[ii][jj] = 0;
	      else if(mumgamd[mum][jj] == 1 || dadgamd[dad][jj] == 1) kidgend[ii][jj] = 1;   
	    }  	
	}
    }
  else if (io==2)
    {
      for (ii=1;ii<=nkid;++ii)
	{
	  name_kid[ii]=ii;
	  mum = 1+(int)(npar1*alea()) ;      
	  /* Tirage al�atoire d'un parent parmi ceux de la parcelle */
	  
	  gamete(pargen1[mum], mumgam[mum], nloc, nall, Es, cyt, nallc, parcyt[mum]);   
	  gamete_dom(pargend1[mum],mumgamd[mum], parcyt[mum], nlocd, Es, pfd, 0, nallc); 
	  /* Simulation des gam�tes parentaux : dans la parcelle*/    
	  gamete_hp(dadgam[ii], nloc, nall, fcum, cyt, nallc, fcumc);  /* hors parcelle*/
	  gamete_hp_dom(dadgamd[ii], nlocd, pfd, 0, nallc, fcumc);  
	  kidpar[ii].g1=name_par1[mum];            /* Nom du parent de la parcelle*/
	  
	  for (jj=1;jj<=nloc-cyt;++jj)
	    {
	      kidgen[ii][jj].g1=mumgam[mum][jj];  /* ii :enfant, jj locus*/
	      f=alea();
	      if(f<=F) kidgen[ii][jj].g2=mumgam[mum][jj];
	      else kidgen[ii][jj].g2=dadgam[ii][jj];
	    }
	  if  (cyt > 0)
	    {
	      if (cytmater==1) for (jj=nloc-cyt+1;jj<=nloc;++jj)  kidcyt[ii][jj-nloc+cyt] = mumgam[mum][jj];             
	      else if (cytmater==0) for (jj=nloc-cyt+1;jj<=nloc;++jj)  kidcyt[ii][jj-nloc+cyt] = dadgam[ii][jj];  
	    }
	  /* Paternal cytoplasmic heredity, if maternal, */
	  /* not interesting to use the information, except for checking right knownn mother*/
	  for (jj=1;jj<=nlocd;++jj)
	    {
	      f=alea();
	      if (mumgamd[mum][jj] == 0)
		{ if( f<=F || dadgamd[ii][jj] == 0) kidgend[ii][jj] = 0; }
	      else if(mumgamd[mum][jj] == 1 || dadgamd[ii][jj] == 1) kidgend[ii][jj] = 1;   
	    } 
	}
    }

  printf("\n End of simulation step \n");
  printf("\n Calculation step");
   
  /* 	First allocate memory to store data: draw a histogram later thanks to them */

  bestf=(double *)malloc((nkid+1)*sizeof(double));
  for (i=1; i<=nkid; i++) bestf[i]=0.0;
  deltatrue=(double *)malloc((2*nkid+1)*sizeof(double));
  deltawrongi=(double *)malloc((2*nkid+1)*sizeof(double));
  deltawrongo1=(double *)malloc((nkid+1)*sizeof(double));
  deltawrongo2=(double *)malloc((nkid+1)*sizeof(double));
  deltawrong=(double *)malloc((4*nkid+1)*sizeof(double));
 
  for (i=1; i<=nkid; ++i)
    {
      /*printf ("\t%5d\t", name_kid[i]); printf ("\b\b\b\b\b\b\b\b\b\b");      */
      /*printf ("\n kid %d mum %d dad %d\n", name_kid[i], kidpar[i].g1, kidpar[i].g2);         */
      /*print_geno(kidgen[i], nloc);   */
      /*for (l=1; l<=npar; ++l) if (kidpar[i].g1==name_par[l])   print_geno(pargen[l], nloc);       */
      /*for (l=1; l<=npar; ++l) if (kidpar[i].g2==name_par[l])   print_geno(pargen[l], nloc);      */
      
      /* Calcul des vraisemblances des p�res pour chaque descendant */
      
      npod=0; bc=1.0E6;
      for (k=1; k< 9; ++k) { best_dads[k] =0; score[k]=0.0;} 
      for (j=1; j<=npar2; ++j)
	{
	  for (ii=1; ii<=npar1; ++ii)
	    {
	      if ( kidpar[i].g1==name_par1[ii]) mere=ii;
	    }

	  cc = pater(kidgen[i], pargen1[mere], pargen2[j], nloc-cyt, pf, E, F, nall, miss); 
	  cc += pater_dom((nlocd), kidgend[i],pargend1[mere],pargend2[j], pfd, E, F); /* proba father:non father*/
	  if (cyt > 0 && cytmater==0) cc+=likr_cyt(cyt, kidcyt[i], parcyt[j], pfc, E, nallc);
/* 	  printf("\ncc %f", cc);  */
/* 	  printf("\ni %d, kidgen[i]", i); print_geno(kidgen[i], nloc);     */
/* 	  printf("\npargen[mere]"); print_geno(pargen[mere], nloc);     */
/* 	  printf("\npargen[j]"); print_geno(pargen[j], nloc);     */
/* 	  printf("\nnloc-cyt %d, E %f, F %f",  nloc-cyt, E, F);     */

	  if (cc > 0.0 && finite(cc)==1) 
	    {
	      ++npod;
	      if (npod < 9) 
		{
		  best_dads[npod] = name_par2[j]; 
		  score[npod]=cc; 
		  if (cc < bc)  bc = cc; 
		  /*printf("\nbest_dads[npod] %f,score[npod] %f",best_dads[npod],score[npod]);  */
		} 
	      else
		{
		  if (cc > bc) 
		    {
		      k = dexmin(score, 8);
		      best_dads[k] = name_par2[j];
		      score[k] = cc;
		      bc = valmin(score, 8); 
		      /*printf("\nbest_dads[k] %f,score[k] %f",best_dads[k],score[k]);  */
		    }
		}
	    }	  
	  /* printf ("\n pc: %f \t",pc); */ 
	} 
      
      sort2(8,score,best_dads);			
      
      /* Affichage */
      /*printf ("\n Meilleurs p�res et leurs scores:\n");     */
      /*for (k=8; k>=4; --k) printf ("\t %.0f",best_dads[k]); printf ("\n");     */
      /*for (k=8; k>=4; --k) printf ("\t %.2g",score[k]); fflush(stdout);     */
            
      k=8; 
      bestf[i]= score[k];
      deltamax=score[8];
      delta1= deltamax; /*delta of the first most likely father*/
      delta2= score[7]-deltamax; /*delta of the second most likely father*/
      if(io==1) { 
	if (best_dads[8]==kidpar[i].g2) {deltatrue[iii]=delta1; iii+=1;} else deltawrongi[i]=delta1;
	if (best_dads[7]==kidpar[i].g2) {deltatrue[iii]=delta2; iii+=1;} else deltawrongi[i]=delta2;
      }
      if (io==2) { deltawrongo1[i]=delta1; deltawrongo2[i]=delta2; } 

      /* Stocker les vraisemblances de bonne  (bd) et mauvaise d�cision (md) pour les meilleurs p�res*/
      if (io==1)
	{    
	  bp=best_dads[k]; 
	  if (bp==kidpar[i].g2)    		
	    if (score[k]>0.000000) ++bdp; 
	    else ++mdp;
	}
    }
  if (io==1)
    {
      x=bdp;
      y=nkid;
      bdpf=100*x/y; /* Percentage of correct classification */
      printf("\n The most likely father is the right father in %d simulations (%.2f %%)",bdp,bdpf); 
    }
  printf("\n End of calculation step\n");	
  /*     printf("\nbdp %d, mdp %d",bdp,mdp);   */
  
  hist1(bestf, nkid, name1);
  if (io==1) hist1(deltatrue, (iii-1), name2);
  for (i=1; i<=2*nkid; ++i) deltawrong[i]=deltawrongi[i];
  for (i=2*nkid+1; i<=3*nkid; ++i)  deltawrong[i]=deltawrongo1[i-2*nkid];
  for (i=3*nkid+1; i<=4*nkid; ++i)  deltawrong[i]=deltawrongo2[i-3*nkid];

  if (io==2) hist1(deltawrong, 4*nkid, name3);
  printf("\n");

  return(0);

}
