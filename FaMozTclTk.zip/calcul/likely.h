
/**************************************************************************************
  18/5/01 
  The likely library contains programs for calculating likelihood
 *************************************************************************************/

/********** Paternity: codominant markers ***************/

double seg_prob (gch,  gseg) 
     Geno gch, *gseg;
     /* calcule la proba que les deux parents aient engendr� le descendant */
{
  double cc=0.0; int j;
  if (gch.g1 == 0) return(1.0); /* pourquoi ??? */
  for (j=1; j<=4; ++j)
    {
      if (((gch.g1 == gseg[j].g1) && (gch.g2 == gseg[j].g2))
       || ((gch.g2 == gseg[j].g1) && (gch.g1 == gseg[j].g2)))
	cc += 0.25 ; 
    }
  return (cc); 
}

void make_segs (gmum, gdad, gseg) 
     Geno gmum,gdad, *gseg ;
     /* Attribue � gseg les g�notypes des deux parents pour envisager */
     /*  toutes les combinaisons possibles deux � deux dans seg_prob */
{
  gseg[1].g1 = gdad.g1; gseg[1].g2 = gmum.g1;
  gseg[2].g1 = gdad.g1; gseg[2].g2 = gmum.g2;
  gseg[3].g1 = gdad.g2; gseg[3].g2 = gmum.g1;
  gseg[4].g1 = gdad.g2; gseg[4].g2 = gmum.g2; 
}

double parent (i,j, gset, pally)  
     int i,j, *gset; double *pally;
     /* Conditional probability for single parent likelihood */
     
{
  double p3,p4; 
  int g1,g2,g3,g4, ic;
  g1=gset[j+j-1]; g2=gset[j+j]; /* i=1 j=2 g1=3 g2=4 /parent1 g3=1 g4=2/desc || j=2 g1=5 g2=6 /parent2 */
  g3=gset[i+i-1]; g4=gset[i+i];/*fr�quences parent/desc (pourquoi i,j?)*/
  p3=pally[i+i-1]; p4=pally[i+i]; /* fr�quences all�liques du descendant, [1] [2] */
  ic = genopair (g1,g2,g3,g4); /* ic est la relation entre les all�les m�re/desc id ou dif*/
/*   if (ic<=2) return(p3); */
/*   else if (ic==3) return (p4); */
/*   else if (ic <=5) return(0.5*p4); */
/*   else if (ic <=8) return(0.0); */
/*   else if (ic ==9) return(0.5*(p3+p4)); */
/*   else if (ic==10) return(0.5*p3); */
/*   else if (ic==11) return(0.5*p4); */
/*   else return(0.0); */
  if (ic<=2) return(p4);
  else if (ic==3) return (p3);
  else if (ic <=5) return(0.5*p4);
  else if (ic <=8) return(0.0);
  else if (ic ==9) return(0.5*(p3+p4));
  else if (ic==10) return(0.5*p4);
  else if (ic==11) return(0.5*p3);
  else return(0.0);
}

int genopair (g1, g2, g3, g4)
     int g1,g2,g3,g4;
     /* routine to identify the case (1-12) of the genotype pair */
{ 
  if (g1==g2) {
    if (g3==g4) {
      if (g1==g3) return(1); else return(6); 
    }
    else if (g3==g1) return(2);
    else if (g4==g1) return(3);
    else return(7);  
  }
  else if (g3==g4) {
    if (g1==g3) return(4);
    else if (g2==g3) return(5); 
    else return(8); 
  }
  else if (g1==g3) {
    if (g2==g4) return(9); 
    else return(10); 
  }
  else if (g2==g3) return(10);
  else if ((g4==g1) |(g4==g2)) return(11); 
  else return(12); 
}

double unrel(gset, pally, i, F) 
     double *pally, F; 
     int i, *gset;
     /* prob for unrelated individual i */
     /*Calcule la proba du g�notype du descendant*/
{ 
  double cc;
  int j=i+i-1;
  cc = pally[j]*pally[j+1] + F*pally[j]*(1-pally[j]);                  /* cas homozygote*/ 
  if (gset[j] != gset[j+1])  cc = 2*pally[j]*pally[j+1]*(1-F);  /* cas h�t�rozygote*/
  return(cc); 
}

double pater (gk, gm, gd, nl, pf1, E, F, na, miss) 
     Geno *gk, *gm, *gd;
     double **pf1, E, F;
     int nl, *na, miss;
     /* paternity likelihood ratio */
{
  int i, j, k, l, gset[7], gset2[7], nmanq, j2, *a, posmanq[7], ntot; 
  Geno gseg[5], gk2, gm2, gd2;  
  double pally[7], qp, ppar1, ppar2, pdes, pdp1, pdp2, pdpp, p, q, mult;
  qp=0; ppar1=0; ppar2=0; pdes=0; pdp1=0; pdp2=0 ;pdpp=0; p=0; q=0;
  /* ppar1, ppar2, pdes : proba des g�notypes des parents 1 et 2, desc,  */
  /* pdp1, pdp2, pdpp : proba que le desc soit issu du parent 1, 2, de la paire  */

  if (miss==1) { /*replace each missing data by any allele at the locus (time consuming)*/
    for (i=1; i<=nl ; ++i) {   
      gset[1]=gk[i].g1; gset[2]=gk[i].g2;  
      gset[3]=gm[i].g1; gset[4]=gm[i].g2;  
      gset[5]=gd[i].g1; gset[6]=gd[i].g2;  
      /*       for (j=1; j<= 6; ++j) if (gset[j]!=-5) pally[j]= pf1[i][gset[j]];  range dans le tableau pally...*/    
      /*1, 2 desc    <- */ 
      /*3, 4 parent 1<-Fr�quences des all�les*/  
      /*5, 6parent 2<- */  
      nmanq=0; 
      
      for (j=1;j<=6;j++)
	{ 
	  gset2[j]=gset[j]; 
	  if (gset[j]==(-5))
	    { 
	      nmanq+=1;  
	      posmanq[nmanq]=j;  
	    } 
	} 
      a=(int *)malloc((nmanq+1)*sizeof(int)); 
      pdpp=0;
      pdes=0; 
      ppar1=0; 
      ppar2=0; 
      pdp1=0; 
      pdp2=0; 
      ntot=pow((double) na[i],(double) nmanq);
      /*
	Par exemple, exprimer tous les cas en base deux pour parcourir facilement tous les �tats possibles 
	(Technique Austerlitz brevet�e), dans le cas de donn�es manquantes    
	exemple de 3 positions, �tat all�lique 0 ou 1 soit
	�tats :     expression en base 2 (deux �tats 0 ou 1)
	1/ 0 0 0    0=0*2^0 + 0*2^1 + 0*2^2 =0
	2/ 0 0 1    1=0*2^0 + 0*2^1 + 1*2^2 =4
	3/ 0 1 0    2=0*2^0 + 1*2^1 + 0*2^2 =2
	4/ 1 0 0    3=1*2^0 + 0*2^1 + 0*2^2 =1
	5/ 1 1 0    4=1*2^0 + 1*2^1 + 0*2^2 =3
	6/ 0 1 1    5=0*2^0 + 1*2^1 + 1*2^2 =6
	7/ 1 0 1    6=1*2^0 + 0*2^1 + 1*2^2 =5
	8/ 1 1 1    7=1*2^0 + 1*2^1 + 1*2^2 =7
	on a plus g�n�ralement : j=c0*b^0 + c1*b^1 + c2*b^2 + .... + c(n-1)*b^(n-1)
	d'o� c(n-1) = partie_enti�re(j/b^(n-1))        
	c(i) : �tat all�lique, b : nombre d'all�les, n : nombre de positions manquantes
	ensuite j-=c(n-1)*b^(n-1)
	et c(n-2) = partie_enti�re(j/b^(n-2)) etc...
	*/
      for (j=0; j<ntot; j++) 
	/* ntot = (number of allele)^(number of missing data); no missing data= one loop only (j=0)*/
	{ 
	  j2=j; 
	  for (k=nmanq-1;k>=0;k--) 
	    { 
	      a[k+1]=j2/pow((double)(na[i]),(double)k)+1;
	      j2-=(a[k+1]-1)*pow((double)(na[i]),(double)k); 
	      /* all possible allelic states at the missing data are found here */
	    } 
	  mult=1; 
	  for (l=1;l<=nmanq;l++) 
	    { 
	      mult*=pf1[i][a[l]]; 
	      /*multiply allele frequencies at the missing data: probability of observing the replaced genotype*/
	      gset2[posmanq[l]]=a[l]; 
	    }
	  pally[1] = pf1[i][gset2[1]]; pally[2] = pf1[i][gset2[2]];/*desc    <- */ 
	  pally[3] = pf1[i][gset2[3]]; pally[4] = pf1[i][gset2[4]];/*parent 1<-Fr�quences des all�les*/ 
	  pally[5] = pf1[i][gset2[5]]; pally[6] = pf1[i][gset2[6]];/*parent 2<- */ 
	  gk2.g1=gset2[1]; gk2.g2=gset2[2]; 
	  gm2.g1=gset2[3]; gm2.g2=gset2[4]; 
	  gd2.g1=gset2[5]; gd2.g2=gset2[6]; 
	  make_segs (gm2, gd2, gseg);  
	  pdpp += mult*seg_prob (gk2, gseg); 
	  pdes +=  mult*unrel (gset2, pally, 1, F); 
	  ppar1 += mult* unrel (gset2, pally, 2, F);  
	  ppar2 += mult*unrel (gset2, pally, 3, F); 
	  pdp1 += mult*parent(1,2,gset2,pally); 
	  pdp2 += mult*parent(1,3,gset2,pally);      
	}
      free(a); 
      p  =  ((1-E)*(1-E)*(1-E)*pdpp*ppar1*ppar2 +  
	     E*(1-E)*(1-E)*( ppar1*ppar2 + pdp1*ppar1 + pdp2*ppar2) +  
	     E*E*(1-E)*(pdes + ppar1 + ppar2) + E*E*E);    
      q  = ((1-E)*(1-E)*(1-E)*pdp1*ppar1*ppar2 +   
	    E*(1-E)*(1-E)*(pdp1*ppar1 + pdes*ppar2 + ppar1*ppar2) +   
	    E*E*(1-E)*(pdes + ppar1 + ppar2) + E*E*E);  
      qp += log(p)-log(q);   
    }
    return(qp); 
  }
 
  else if (miss==0) { /*Ignore missing data in lod calculation*/
    for (i=1; i<=nl ; ++i) {   
      if (gk[i].g1 !=(-5) && gk[i].g2 !=(-5) &&   
	  gm[i].g1 !=(-5) && gm[i].g2 !=(-5) && gd[i].g1 !=(-5) && gd[i].g2 !=(-5))                 
	{  
	  gset[1]=gk[i].g1; gset[2]=gk[i].g2;  
	  gset[3]=gm[i].g1; gset[4]=gm[i].g2;  
	  gset[5]=gd[i].g1; gset[6]=gd[i].g2;  
	  pally[1] = pf1[i][gset[1]]; pally[2] = pf1[i][gset[2]]; 
	  pally[3] = pf1[i][gset[3]]; pally[4] = pf1[i][gset[4]];  
	  pally[5] = pf1[i][gset[5]]; pally[6] = pf1[i][gset[6]];  
	  make_segs (gm[i], gd[i], gseg);  
	  pdpp = seg_prob (gk[i], gseg);  
	  pdes = unrel (gset, pally, 1, F);  
	  ppar1 = unrel (gset, pally, 2, F);   
	  ppar2 = unrel (gset, pally, 3, F);  
	  pdp1 = parent(1,2,gset,pally);  
	  pdp2 = parent(1,3,gset,pally);    
	  p  =  ((1-E)*(1-E)*(1-E)*pdpp*ppar1*ppar2 +   
		 E*(1-E)*(1-E)*( ppar1*ppar2 + pdp1*ppar1 + pdp2*ppar2) +   
		 E*E*(1-E)*(pdes + ppar1 + ppar2) + E*E*E);     
	  q  = ((1-E)*(1-E)*(1-E)*pdp1*ppar1*ppar2 +    
		E*(1-E)*(1-E)*(pdp1*ppar1 + pdes*ppar2 + ppar1*ppar2) +    
		E*E*(1-E)*(pdes + ppar1 + ppar2) + E*E*E);   
	  qp += log(p)-log(q);    
	} 
    } 
    return(qp); 
  }
} 






/********** Single parent and parent pair: codominant markers ***************/


double uparchk (nloc, gk, gp, pf, E, F, na, miss) 
     int nloc, *na, miss; 
     Geno *gk, *gp;
     double **pf, E, F;
     /* single-parent likelihood  */                                   
{ 
  int i, j, k, l, m, gset[5], gset2[5], nmanq, j2, *a, posmanq[5], ntot; 
  double pally[5], qp, ppar, pdes, pdp, p, q, mult; 
  qp=0; ppar=0; pdes=0; pdp=0; p=0; q=0;
  /* ppar/pdes : proba g�notype parent/des, pdp : proba desc est celui du parent */
  m=missing(gk, nloc);
 
  if (miss==1) {  
    for (i=1; i<=nloc ; ++i) {
      if (m<=1 || (m>1 && gp[i].g1!=-5 && gp[i].g2!=-5)) /* The likelihood is impossible to calculate if there are no data at the locus*/
	{
	  gset[1] = gk[i].g1; gset[2] = gk[i].g2; /*nom des all du desc au locus i*/  
	  gset[3] = gp[i].g1; gset[4] = gp[i].g2; /*nom des all de la m�re au locus i*/  
	  /*     for (j=1; j< 5; ++j) if (gset[j]!=-5) pally[j]= pf[i][gset[j]];  range dans le tableau pally...*/    
	  nmanq=0;                                      /*...les fr�q des 4 all�les*/  
	  
	  for (j=1;j<=4;j++)
	    {  
	      gset2[j]=gset[j];  
	      if (gset[j]==(-5))
		{  
		  nmanq+=1;   
		  posmanq[nmanq]=j;   
		}  
	    }  
	  a=(int *)malloc((nmanq+1)*sizeof(int));  
	  pdp=0; 
	  pdes=0;  
	  ppar=0;  
	  ntot=pow((double) na[i],(double) nmanq); 
	  for (j=0; j<ntot; j++) 
	    {
	      j2=j;  
	      for (k=nmanq-1;k>=0;k--)
		{  
		  a[k+1]=j2/pow((double)(na[i]),(double)k)+1; 
		  j2-=(a[k+1]-1)*pow((double)(na[i]),(double)k); 
		}  
	      mult=1;  
	      for (l=1;l<=nmanq;l++) 
		{  
		  mult*=pf[i][a[l]];  
		  gset2[posmanq[l]]=a[l];  
		}  
	      pally[1] = pf[i][gset2[1]]; pally[2] = pf[i][gset2[2]]; /*desc    <- */  
	      pally[3] = pf[i][gset2[3]]; pally[4] = pf[i][gset2[4]]; /*parent 1<-Fr�quences des all�les*/  
	      pdp += mult* parent(1, 2, gset2, pally);         
	      pdes +=  mult*unrel (gset2, pally, 1, F);  
	      ppar +=  mult*unrel (gset2, pally, 2, F);  
	    } 
	  free(a); 
	  p = ((1-E)*(1-E)*(pdp*ppar) + E*(1-E)*(pdes + ppar) + E*E) ;   
	  q = ((1-E)*(1-E)*(pdes*ppar) + E*(1-E)*(pdes + ppar) + E*E) ;    
	  qp += log(p)-log(q);    
	  /*printf("\n pdp %f pdes %f ppar %f p %f q %f ln(p/q) %f qp %f", pdp, pdes, ppar, p, q, log(p)-log(q), qp); */
	}  
    }  
  return(qp);  
  }
  
  else if (miss==0) {
    for (i=1; i<=nloc ; ++i) {  
      if (gk[i].g1 !=(-5) && gk[i].g2 !=(-5) && gp[i].g1 !=(-5) && gp[i].g2 !=(-5))   
  	{   
  	  gset[1] = gk[i].g1; gset[2] = gk[i].g2;   
  	  gset[3] = gp[i].g1; gset[4] = gp[i].g2;   
  	  for (j=1; j< 5; ++j) pally[j]= pf[i][gset[j]];    
  	  pdp = parent(1, 2, gset, pally);                 
  	  pdes = unrel (gset, pally, 1, F);  
  	  ppar = unrel (gset, pally, 2, F);  
  	  p = ((1-E)*(1-E)*(pdp*ppar) + E*(1-E)*(pdes + ppar) + E*E) ;   
  	  q = ((1-E)*(1-E)*(pdes*ppar) + E*(1-E)*(pdes + ppar) + E*E) ;    
  	  qp += log(p)-log(q) ;   
  	}  
      }  
    return(qp);  
  }
}  

double pparchk (nloc, gk, gm, gd, pf, E, F, na, miss) 
     int nloc, *na, miss;
     Geno *gk, *gm, *gd;
     double **pf, E, F;
     /* parent pair likelihood ratio */
{ 
  int i,j, k, l,gset[7], gset2[7], nmanq, j2, *a, posmanq[7], ntot; 
  Geno gseg[5], gk2, gm2, gd2;  
  double pally[7],qp, ppar1, ppar2, pdes, pdp1, pdp2, pdpp, p, q, mult, m, n;
  qp=0; ppar1=0; ppar2=0; pdes=0; pdp1=0; pdp2=0 ;pdpp=0; p=0; q=0;
  /* ppar1, ppar2, pdes : proba des g�notypes des parents 1 et 2, desc,  */
  /* pdp1, pdp2, pdpp : proba que le desc soit issu du parent 1, 2, de la paire  */
  
  m=missing(gm, nloc);
  n=missing(gd, nloc);
 
  if (miss==1) {    
    for (i=1; i<=nloc ; ++i) {  
      if (m<=1 || (m>1 && gm[i].g1!=-5 && gm[i].g2!=-5))
	if (n<=1 || (n>1 && gd[i].g1!=-5 && gd[i].g2!=-5))
	  {
	    gset[1]=gk[i].g1; gset[2]=gk[i].g2; 
	    gset[3]=gm[i].g1; gset[4]=gm[i].g2; 
	    gset[5]=gd[i].g1; gset[6]=gd[i].g2; 
	  /*       for (j=1; j<= 6; ++j) if (gset[j]!=-5) pally[j]= pf[i][gset[j]]; */
	  nmanq=0;  
	  for (j=1;j<=6;j++) 
	    {  
	      gset2[j]=gset[j];  
	      if (gset[j]==(-5))
		{  
		  nmanq+=1;   
		  posmanq[nmanq]=j;   
		}  
	    }  
	  a=(int *)malloc((nmanq+1)*sizeof(int));  
	  pdpp=0; 
	  pdes=0;  
	  ppar1=0;  
	  ppar2=0;  
	  pdp1=0;  
	  pdp2=0;  
	  ntot=pow((double) na[i],(double) nmanq); 
	  
	  for (j=0; j<ntot; j++) 
	    {  
	      j2=j;  
	      for (k=nmanq-1;k>=0;k--) 
		{  
		  a[k+1]=j2/pow((double)(na[i]),(double)k)+1; 
		  j2-=(a[k+1]-1)*pow((double)(na[i]),(double)k);  
		}  
	      mult=1;  
	      for (l=1;l<=nmanq;l++) 
		{  
		  mult*=pf[i][a[l]];  
		  gset2[posmanq[l]]=a[l];  
		}  
	      pally[1] = pf[i][gset2[1]]; pally[2] = pf[i][gset2[2]]; /* desc    <- */  
	      pally[3] = pf[i][gset2[3]]; pally[4] = pf[i][gset2[4]]; /* parent 1<-Fr�quences des all�les*/  
	      pally[5] = pf[i][gset2[5]]; pally[6] = pf[i][gset2[6]]; /* parent 2<- */  
	      gk2.g1=gset2[1]; gk2.g2=gset2[2];  
	      gm2.g1=gset2[3]; gm2.g2=gset2[4];  
	      gd2.g1=gset2[5]; gd2.g2=gset2[6];  
	      make_segs (gm2, gd2, gseg); 
	      pdpp += mult*seg_prob (gk2, gseg); 
	      pdes += mult*unrel (gset2, pally, 1, F); 
	      ppar1 += mult*unrel (gset2, pally, 2, F);  
	      ppar2 += mult*unrel (gset2, pally, 3, F); 
	      pdp1 += mult*parent(1,2,gset2,pally); 
	      pdp2 += mult*parent(1,3,gset2,pally); 
	    } 
	  free(a); 
	  p  =  ((1-E)*(1-E)*(1-E)*pdpp*ppar1*ppar2 +  
		 E*(1-E)*(1-E)*(ppar1*ppar2 + pdp1*ppar1 + pdp2*ppar2) +  
		 E*E*(1-E)*(pdes + ppar1 + ppar2) + E*E*E);    
	  q  = ((1-E)*(1-E)*(1-E)*pdes*ppar1*ppar2 +   
		E*(1-E)*(1-E)*(pdes*ppar1 + pdes*ppar2 + ppar1*ppar2) +   
		E*E*(1-E)*(pdes + ppar1 + ppar2) + E*E*E);   
	  qp += log(p)-log(q); 
	} 
    } 
    return(qp); 
  }

  else if (miss==0) { 
    for (i=1; i<=nloc ; ++i)  {  
      if (gk[i].g1 !=(-5) && gk[i].g2 !=(-5)   
  	  && gm[i].g1 !=(-5) && gm[i].g2 !=(-5) && gd[i].g1 !=(-5) && gd[i].g2 !=(-5))    
  	{  
  	  gset[1]=gk[i].g1; gset[2]=gk[i].g2;  
  	  gset[3]=gm[i].g1; gset[4]=gm[i].g2;  
  	  gset[5]=gd[i].g1; gset[6]=gd[i].g2;  
  	  pally[1] = pf[i][gset[1]]; pally[2] = pf[i][gset[2]];  
  	  pally[3] = pf[i][gset[3]]; pally[4] = pf[i][gset[4]];  
  	  pally[5] = pf[i][gset[5]]; pally[6] = pf[i][gset[6]];  
  	  make_segs (gm[i], gd[i], gseg);  
  	  pdpp = seg_prob (gk[i], gseg);  
  	  pdes = unrel (gset, pally, 1, F);  
  	  ppar1 = unrel (gset, pally, 2, F);   
  	  ppar2 = unrel (gset, pally, 3, F);  
  	  pdp1 = parent(1,2,gset,pally);  
  	  pdp2 = parent(1,3,gset,pally);  
  	  p  =  ((1-E)*(1-E)*(1-E)*pdpp*ppar1*ppar2 +   
  		 E*(1-E)*(1-E)*(ppar1*ppar2 + pdp1*ppar1 + pdp2*ppar2) +   
  		 E*E*(1-E)*(pdes + ppar1 + ppar2) + E*E*E);     
  	  q  = ((1-E)*(1-E)*(1-E)*pdes*ppar1*ppar2 +    
  		E*(1-E)*(1-E)*(pdes*ppar1 + pdes*ppar2 + ppar1*ppar2) +    
  		E*E*(1-E)*(pdes + ppar1 + ppar2) + E*E*E);    
  	  qp += log(p)-log(q);  
	} 
    } 
    return(qp);  
  }  
}

/* Number of loci contributing to lod calculation for paternity and parent */

double loc_lod_pater (gk, gm, gd, nl, pf1, E, F, na, miss)
     Geno *gk, *gm, *gd;
     double **pf1, E, F;
     int nl, *na, miss;
{
  int i, j, k, l, gset[7], gset2[7], nmanq, j2, *a, posmanq[7], ntot, locl; 
  Geno gseg[5], gk2, gm2, gd2;  
  double pally[7], qp, ppar1, ppar2, pdes, pdp1, pdp2, pdpp, p, q, mult;
  qp=0; ppar1=0; ppar2=0; pdes=0; pdp1=0; pdp2=0 ;pdpp=0; p=0; q=0; locl=0;
 
  if (miss==1) { 
    for (i=1; i<=nl ; ++i) {
      qp=0;
      gset[1]=gk[i].g1; gset[2]=gk[i].g2;  
      gset[3]=gm[i].g1; gset[4]=gm[i].g2;  
      gset[5]=gd[i].g1; gset[6]=gd[i].g2;  
      /*for (j=1; j<= 6; ++j) if (gset[j]!=-5) pally[j]= pf1[i][gset[j]];  range dans le tableau pally...*/    
      nmanq=0; 
      
      for (j=1;j<=6;j++) 
	{ 
	  gset2[j]=gset[j]; 
	  if (gset[j]==(-5)){ 
	    nmanq+=1;  
	    posmanq[nmanq]=j;  
	  } 
	} 
      a=(int *)malloc((nmanq+1)*sizeof(int)); 
      pdpp=0;
      pdes=0; 
      ppar1=0; 
      ppar2=0; 
      pdp1=0; 
      pdp2=0; 
      ntot=pow((double) na[i],(double) nmanq);
      for (j=0; j<ntot; j++) 
	{ 
	  j2=j; 
	  for (k=nmanq-1;k>=0;k--)
	    { 
	      a[k+1]=j2/pow((double)(na[i]),(double)k)+1;
	      j2-=(a[k+1]-1)*pow((double)(na[i]),(double)k); 
	    } 
	  mult=1; 
	  for (l=1;l<=nmanq;l++)
	    { 
	      mult*=pf1[i][a[l]]; 
	      gset2[posmanq[l]]=a[l]; 
	    } 
	  pally[1] = pf1[i][gset2[1]]; pally[2] = pf1[i][gset2[2]];
	  pally[3] = pf1[i][gset2[3]]; pally[4] = pf1[i][gset2[4]];
	  pally[5] = pf1[i][gset2[5]]; pally[6] = pf1[i][gset2[6]];
	  gk2.g1=gset2[1]; gk2.g2=gset2[2]; 
	  gm2.g1=gset2[3]; gm2.g2=gset2[4]; 
	  gd2.g1=gset2[5]; gd2.g2=gset2[6]; 
	  make_segs (gm2, gd2, gseg);  
	  pdpp += mult*seg_prob (gk2, gseg); 
	  pdes +=  mult*unrel (gset2, pally, 1, F); 
	  ppar1 += mult* unrel (gset2, pally, 2, F);  
	  ppar2 += mult*unrel (gset2, pally, 3, F); 
	  pdp1 += mult*parent(1,2,gset2,pally); 
	  pdp2 += mult*parent(1,3,gset2,pally);      
	}
      free(a); 
      p  =  ((1-E)*(1-E)*(1-E)*pdpp*ppar1*ppar2 +  
	     E*(1-E)*(1-E)*( ppar1*ppar2 + pdp1*ppar1 + pdp2*ppar2) +  
	     E*E*(1-E)*(pdes + ppar1 + ppar2) + E*E*E);    
      q  = ((1-E)*(1-E)*(1-E)*pdp1*ppar1*ppar2 +   
	    E*(1-E)*(1-E)*(pdp1*ppar1 + pdes*ppar2 + ppar1*ppar2) +   
	    E*E*(1-E)*(pdes + ppar1 + ppar2) + E*E*E);  
      qp = log(p)-log(q);   
      if (qp > 0) locl+=1;
    } 
    return(locl); 
  } 

  else if (miss==0) { 
    for (i=1; i<=nl ; ++i) {   
      if (gk[i].g1 !=(-5) && gk[i].g2 !=(-5) &&   
	  gm[i].g1 !=(-5) && gm[i].g2 !=(-5) && gd[i].g1 !=(-5) && gd[i].g2 !=(-5))                 
	{  
	  gset[1]=gk[i].g1; gset[2]=gk[i].g2;  
	  gset[3]=gm[i].g1; gset[4]=gm[i].g2;  
	  gset[5]=gd[i].g1; gset[6]=gd[i].g2;  
	  pally[1] = pf1[i][gset[1]]; pally[2] = pf1[i][gset[2]]; 
	  pally[3] = pf1[i][gset[3]]; pally[4] = pf1[i][gset[4]];  
	  pally[5] = pf1[i][gset[5]]; pally[6] = pf1[i][gset[6]];  
	  make_segs (gm[i], gd[i], gseg);  
	  pdpp = seg_prob (gk[i], gseg);  
	  pdes = unrel (gset, pally, 1, F);  
	  ppar1 = unrel (gset, pally, 2, F);   
	  ppar2 = unrel (gset, pally, 3, F);  
	  pdp1 = parent(1,2,gset,pally);  
	  pdp2 = parent(1,3,gset,pally);    
	  p  =  ((1-E)*(1-E)*(1-E)*pdpp*ppar1*ppar2 +   
		 E*(1-E)*(1-E)*( ppar1*ppar2 + pdp1*ppar1 + pdp2*ppar2) +   
		 E*E*(1-E)*(pdes + ppar1 + ppar2) + E*E*E);     
	  q  = ((1-E)*(1-E)*(1-E)*pdp1*ppar1*ppar2 +    
		E*(1-E)*(1-E)*(pdp1*ppar1 + pdes*ppar2 + ppar1*ppar2) +    
		E*E*(1-E)*(pdes + ppar1 + ppar2) + E*E*E);   
	  qp += log(p)-log(q);    
	  if (qp > 0) locl+=1;
	} 
    } 
    return(locl); 
  }
} 


double loc_lod_1par (nloc, gk, gp, pf, E, F, na, miss)
     int nloc, *na, miss; 
     Geno *gk, *gp;
     double **pf, E, F;
{ 
  int i, j, k, l, m, gset[5], gset2[5], nmanq, j2, *a, posmanq[5], ntot, locl; 
  double pally[5], qp, ppar, pdes, pdp, p, q, mult; 
  qp=0; ppar=0; pdes=0; pdp=0; p=0; q=0; locl=0;
  m=missing(gk, nloc);
  
  if (miss==1) {  
    for (i=1; i<=nloc ; ++i) 
      { 
	if (m<=1 || (m>1 && gp[i].g1!=-5 && gp[i].g2!=-5)) 
	  /* The likelihood is impossible to calculate if there are no data at the locus*/
	  {
	    qp=0;
	    gset[1] = gk[i].g1; gset[2] = gk[i].g2; 
	    gset[3] = gp[i].g1; gset[4] = gp[i].g2; 
	    /*       for (j=1; j< 5; ++j) pally[j]= pf[i][gset[j]]; */
	    nmanq=0;                                      
	    
	    for (j=1;j<=4;j++) 
	      {  
		gset2[j]=gset[j];  
		if (gset[j]==(-5))
		  {  
		    nmanq+=1;   
		    posmanq[nmanq]=j;   
		  }  
	      }  
	    a=(int *)malloc((nmanq+1)*sizeof(int));  
	    pdp=0; 
	    pdes=0;  
	    ppar=0;  
	    ntot=pow((double) na[i],(double) nmanq); 
	    for (j=0; j<ntot; j++)
	      {  
		j2=j;  
		for (k=nmanq-1;k>=0;k--)
		  {  
		    a[k+1]=j2/pow((double)(na[i]),(double)k)+1; 
		    j2-=(a[k+1]-1)*pow((double)(na[i]),(double)k);  
		  }  
		mult=1;  
		for (l=1;l<=nmanq;l++) 
		  {  
		    mult*=pf[i][a[l]];  
		    gset2[posmanq[l]]=a[l];  
		  }  
		pally[1] = pf[i][gset2[1]]; pally[2] = pf[i][gset2[2]]; 
		pally[3] = pf[i][gset2[3]]; pally[4] = pf[i][gset2[4]]; 
		pdp += mult* parent(1, 2, gset2, pally);         
		pdes +=  mult*unrel (gset2, pally, 1, F);  
		ppar +=  mult*unrel (gset2, pally, 2, F);  
	      } 
	    free(a); 
	    p = ((1-E)*(1-E)*(pdp*ppar) + E*(1-E)*(pdes + ppar) + E*E) ;   
	    q = ((1-E)*(1-E)*(pdes*ppar) + E*(1-E)*(pdes + ppar) + E*E) ;    
	    qp = log(p)-log(q);    
	    if (qp > 0) locl+=1;
	  }
      }  
    return(locl);  
  }  
  else if (miss==0) {
    for (i=1; i<=nloc ; ++i) {  
      if (gk[i].g1 !=(-5) && gk[i].g2 !=(-5) && gp[i].g1 !=(-5) && gp[i].g2 !=(-5))   
  	{   
  	  gset[1] = gk[i].g1; gset[2] = gk[i].g2;   
  	  gset[3] = gp[i].g1; gset[4] = gp[i].g2;   
  	  for (j=1; j< 5; ++j) pally[j]= pf[i][gset[j]];    
  	  pdp = parent(1, 2, gset, pally);                 
  	  pdes = unrel (gset, pally, 1, F);  
  	  ppar = unrel (gset, pally, 2, F);  
  	  p = ((1-E)*(1-E)*(pdp*ppar) + E*(1-E)*(pdes + ppar) + E*E) ;   
  	  q = ((1-E)*(1-E)*(pdes*ppar) + E*(1-E)*(pdes + ppar) + E*E) ;    
  	  qp += log(p)-log(q) ;   
	  if (qp > 0) locl+=1;
  	}  
      }  
    return(locl);  
  }
}  


double loc_lod_2par (nloc, gk, gm, gd, pf, E, F, na, miss) 
     int nloc, *na, miss;
     Geno *gk, *gm, *gd;
     double **pf, E, F;
{ 
  int i,j, k, l, gset[7], gset2[7], nmanq, j2, *a, posmanq[7], ntot, locl; 
  Geno gseg[5], gk2, gm2, gd2;  
  double pally[7],qp, ppar1, ppar2, pdes, pdp1, pdp2, pdpp, p, q, mult, m, n;
  qp=0; ppar1=0; ppar2=0; pdes=0; pdp1=0; pdp2=0 ;pdpp=0; p=0; q=0; locl=0;
  m=missing(gm, nloc);
  n=missing(gd, nloc);

  if (miss==1) {      
    for (i=1; i<=nloc ; ++i) { 
      if (m<=1 || (m>1 && gm[i].g1!=-5 && gm[i].g2!=-5))
	if (n<=1 || (n>1 && gd[i].g1!=-5 && gd[i].g2!=-5))
	  {
	    qp=0;
	    gset[1]=gk[i].g1; gset[2]=gk[i].g2; 
	    gset[3]=gm[i].g1; gset[4]=gm[i].g2; 
	    gset[5]=gd[i].g1; gset[6]=gd[i].g2; 
	    /*       pally[1] = pf[i][gset[1]]; pally[2] = pf[i][gset[2]]; */
	    /*       pally[3] = pf[i][gset[3]]; pally[4] = pf[i][gset[4]]; */
	    /*       pally[5] = pf[i][gset[5]]; pally[6] = pf[i][gset[6]]; */
	    nmanq=0;  
	    for (j=1;j<=6;j++) 
	      {  
		gset2[j]=gset[j];  
		if (gset[j]==(-5))
		  {  
		    nmanq+=1;   
		    posmanq[nmanq]=j;   
		  }  
	      }  
	    a=(int *)malloc((nmanq+1)*sizeof(int));  
	    pdpp=0; 
	    pdes=0;  
	    ppar1=0;  
	    ppar2=0;  
	    pdp1=0;  
	    pdp2=0;  
	    ntot=pow((double) na[i],(double) nmanq); 
	    
	    for (j=0; j<ntot; j++)
	      {  
		j2=j;  
		for (k=nmanq-1;k>=0;k--)
		  {  
		    a[k+1]=j2/pow((double)(na[i]),(double)k)+1; 
		    j2-=(a[k+1]-1)*pow((double)(na[i]),(double)k);  
		  }  
		mult=1;  
		for (l=1;l<=nmanq;l++)
		  {  
		    mult*=pf[i][a[l]];  
		    gset2[posmanq[l]]=a[l];  
		  }  
		pally[1] = pf[i][gset2[1]]; pally[2] = pf[i][gset2[2]]; 
		pally[3] = pf[i][gset2[3]]; pally[4] = pf[i][gset2[4]]; 
		pally[5] = pf[i][gset2[5]]; pally[6] = pf[i][gset2[6]]; 
		gk2.g1=gset2[1]; gk2.g2=gset2[2];  
		gm2.g1=gset2[3]; gm2.g2=gset2[4];  
		gd2.g1=gset2[5]; gd2.g2=gset2[6];  
		make_segs (gm2, gd2, gseg); 
		pdpp += mult*seg_prob (gk2, gseg); 
		pdes += mult*unrel (gset2, pally, 1, F); 
		ppar1 += mult*unrel (gset2, pally, 2, F);  
		ppar2 += mult*unrel (gset2, pally, 3, F); 
		pdp1 += mult*parent(1,2,gset2,pally); 
		pdp2 += mult*parent(1,3,gset2,pally); 
	      } 
	    free(a); 
	    p  =  ((1-E)*(1-E)*(1-E)*pdpp*ppar1*ppar2 +  
		   E*(1-E)*(1-E)*(ppar1*ppar2 + pdp1*ppar1 + pdp2*ppar2) +  
		   E*E*(1-E)*(pdes + ppar1 + ppar2) + E*E*E);    
	    q  = ((1-E)*(1-E)*(1-E)*pdes*ppar1*ppar2 +   
		  E*(1-E)*(1-E)*(pdes*ppar1 + pdes*ppar2 + ppar1*ppar2) +   
		  E*E*(1-E)*(pdes + ppar1 + ppar2) + E*E*E);   
	    qp = log(p)-log(q); 
	    if (qp > 0) locl+=1;
	  } 
    }
    return(locl); 
  } 
  
  else if (miss==0) { 
    for (i=1; i<=nloc ; ++i)  {  
      if (gk[i].g1 !=(-5) && gk[i].g2 !=(-5)   
  	  && gm[i].g1 !=(-5) && gm[i].g2 !=(-5) && gd[i].g1 !=(-5) && gd[i].g2 !=(-5))    
  	{  
  	  gset[1]=gk[i].g1; gset[2]=gk[i].g2;  
  	  gset[3]=gm[i].g1; gset[4]=gm[i].g2;  
  	  gset[5]=gd[i].g1; gset[6]=gd[i].g2;  
  	  pally[1] = pf[i][gset[1]]; pally[2] = pf[i][gset[2]];  
  	  pally[3] = pf[i][gset[3]]; pally[4] = pf[i][gset[4]];  
  	  pally[5] = pf[i][gset[5]]; pally[6] = pf[i][gset[6]];  
  	  make_segs (gm[i], gd[i], gseg);  
  	  pdpp = seg_prob (gk[i], gseg);  
  	  pdes = unrel (gset, pally, 1, F);  
  	  ppar1 = unrel (gset, pally, 2, F);   
  	  ppar2 = unrel (gset, pally, 3, F);  
  	  pdp1 = parent(1,2,gset,pally);  
  	  pdp2 = parent(1,3,gset,pally);  
  	  p  =  ((1-E)*(1-E)*(1-E)*pdpp*ppar1*ppar2 +   
  		 E*(1-E)*(1-E)*(ppar1*ppar2 + pdp1*ppar1 + pdp2*ppar2) +   
  		 E*E*(1-E)*(pdes + ppar1 + ppar2) + E*E*E);     
  	  q  = ((1-E)*(1-E)*(1-E)*pdes*ppar1*ppar2 +    
  		E*(1-E)*(1-E)*(pdes*ppar1 + pdes*ppar2 + ppar1*ppar2) +    
  		E*E*(1-E)*(pdes + ppar1 + ppar2) + E*E*E);    
  	  qp += log(p)-log(q);  
	  if (qp > 0) locl+=1;
	} 
    } 
    return(locl);  
  }  
}

 
/********** Paternity: dominant markers ***************/

double seg_prob_dom (p, F, g) double p, F; int g; 
/* calcule la proba que les deux parents aient engendr� le descendant 
   modif du 4/4/02 to put a F value into the calculation
   if offspring o, parent p1 parent p2 (genotypes g)  L=T(go/gp1,gp2)*P(gp1)*P(gp2)/P(gp1)*P(gp2)*P(go)
   T : transition probability */
{
  double dom, hmz, htz; 
  /* Frequencies of dominant and recessive phenotypes, of homozygous or heterozygous (dom or rec) genotypes */
  dom = p*p + F*p*(1-p) + 2*p*(1-p)*(1-F); /* [+]  */   
  hmz =  p*p + F*p*(1-p);                  /* ++ */
  htz = 2*p*(1-p)*(1-F);                     /* +- */

  /*if (g == 1) return((p*p + 3*(1-p)*(1-p) + 4*p*(1-p))/(2-p)*(2-p)); */
  /*else if (g == 2) return(1/(2-p)); */
  /*else if (g == 3) return((1-p)*(1-p)/(2-p)*(2-p)); */
  /*else if (g == 4) return((1-p)/(2-p)); */

  /*printf("\n htz %f hmz %f dom %f htz/dom %f hmz/dom %f 0.5*(htz/dom)  */
  /*%f 0.25*(htz/dom) %f", htz, hmz, dom, htz/dom, hmz/dom, 0.5*(htz/dom), 0.25*(htz/dom)); */
  if (g == 1) return((hmz/dom)*(hmz/dom) + 0.75*(htz/dom)*(htz/dom) + 2*(htz/dom)*(hmz/dom)); /* mum + dad + offs + */
  else if (g == 2) return(0.5*(htz/dom)+ hmz/dom);  /* mum + dad - offs + ou mum - dad + offs +*/
  else if (g == 3) return(0.25*(htz/dom)*(htz/dom)); /* mum + dad + offs - */
  else if (g == 4) return(0.5*(htz/dom));  /* mum + dad - offs - ou mum - dad + offs - */
  else if (g == 5) return(1); /* mum - dad - offs - */
  else if (g == 0) return(0);
}

int make_segs_dom (gmum, gdad, gdes) 
     int gmum,gdad, gdes;
     /*tous les cas possibles du desc et des deux parents pour l'�tat de leur bande 1 : pr�sence, 0 : absence */
 {   
   if  (gdes==1 && gmum==1 && gdad==1) return (1); 
   else if ((gdes==1 && gmum==1 && gdad==0)||(gdes==1 && gmum==0 && gdad==1)) return (2);        
   else if  (gdes==0 && gmum==1 && gdad==1) return (3);                 
   else if ((gdes==0 && gmum==1 && gdad==0)||(gdes==0 && gmum==0 && gdad==1)) return (4);       
   else if  (gdes==0 && gmum==0 && gdad==0) return (5);
   else return (0);
 }            

double parent_dom (i, j, gset, pally, F) 
     int *gset, i,j; 
     double pally, F;
     /* Conditional probability for single parent likelihood 
	modif du 4/4/02 to put a F value into the calculation
	if offspring o, parent p1 (genotypes g)  L=T(go/gp1)*P(gp1)/P(gp1)*P(go)
	T : transition probability ici, seulement T � exprimer !!!*/     
  { 
    double p;
    int g1,g2,ic;
    double dom, hmz, htz; 
    g1=gset[i]; g2=gset[j]; /*�tat de la bande desc / parent*/ 
    p=pally; /* fr�quences de la bande */
    /* Frequencies of dominant phenotypes, of homozygous or heterozygous (dom or rec) genotypes */
    dom = p*p + F*p*(1-p) + 2*p*(1-p)*(1-F); /* [+]  */   
    htz = 2*p*(1-p)*(1-F);                     /* +- */
    hmz =  p*p + F*p*(1-p);                  /* ++ */
    ic = genopair_dom (g1,g2); /* ic est la relation entre l'�tat de la bande desc/parent */
    /*printf("\n dom %f htz %f hmz %f",dom, htz, hmz); */
    
    /*if (ic==1) return((p + (1-p)*(1+p))/(2-p)); */
    /*else if (ic==2) return (p); */
    /*else if (ic==3) return((1-p)*(1-p)/(2-p)); */
    /*else if (ic==4) return(1-p);        */
    /*printf("\n hmz/dom %f 0.5*(1+p)*htz/dom %f ",hmz/dom, (0.5*(1+p)*htz/dom)); */

    if (ic==1) return(hmz/dom + 0.5*(1+p)*(htz/dom)); /* parent + desc + */
    else if (ic==2) return p;                         /* parent - desc + */
    else if (ic==3) return(0.5*(htz/dom)*(1-p));      /* parent + desc - */
    else if (ic==4) return(1-p);                      /* parent - desc - */   
  }

int genopair_dom (g1, g2) 
     int g1,g2;
     /* comparaison de l'�tat de la bande (pr�sence 1 /absence 0) desc / parent */
{ 
  if (g1==1 && g2==1)   return(1);  
  else if (g1==1 && g2==0) return(2); 
  else if (g1==0 && g2==1)  return(3); 
  else if (g1==0 && g2==0) return(4);
}

double unrel_dom(gset, p, i, F) 
     double p, F; 
     int i, *gset;
     /*fr�quence des ph�notypes pr�sence/absence de bande */
{ 
   double cc; 
   if (gset[i]==1)  cc = p*p + F*p*(1-p) + 2*p*(1-p)*(1-F);      /* cas pr�sence de la bande*/ 
   else if (gset[i]==0)  cc = (1-p)*(1-p) + F*p*(1-p);  /* cas absence de la bande*/
   return(cc); 
}


double pater_dom (nloc, gk, gm, gd, pf, E, F)
     int nloc;
     double *pf, E, F;     
     int *gk, *gm, *gd;
{ 
  int i, gset[4], eb; 
  int j, k, l, gset2[4], nmanq, j2, *a, posmanq[4], ntot; double mult;
  double pally, qp, ppar1, ppar2, pdes, pdp1, pdp2, pdpp, p, q;         
  qp=0; ppar1=0; ppar2=0; pdes=0; pdp1=0; pdp2=0 ;pdpp=0; p=0; q=0;
  /* ppar1, ppar2, pdes : proba des g�notypes des parents 1 et 2, desc,  */
  /* pdp1, pdp2, pdpp : proba que le desc soit issu du parent 1, 2, de la paire  */
  for (i=1; i<=nloc ; ++i)
    { 
      gset[1]=gk[i]  ; /*�tat de la bande desc */
      gset[2]=gm[i]; /*                 parent 1*/
      gset[3]=gd[i]; /*                 parent 2*/
      pally = pf[i]; /*fr�quence de la bande i */
      /*       if (gset[1]!=-5 && gset[2]!=-5 && gset[3]!=-5)    */
      /* 	{   */
      nmanq=0;  

      for (j=1;j<=3;j++) 
	{  
	  gset2[j]=gset[j];  
	  if (gset[j]==(-5)) 
	    {  
	      nmanq+=1;   
	      posmanq[nmanq]=j;   
	    }  
	} 	 
      a=(int *)malloc((nmanq+1)*sizeof(int));  
      pdpp=0;  
      pdes=0;  
      ppar1=0;   
      ppar2=0;   
      pdp1=0;   
      pdp2=0;  
      ntot=pow((double) 2,(double) nmanq); 
      for (j=0; j<ntot; j++)  
	{  
	  j2=j;  
	  for (k=nmanq-1;k>=0;k--)  
	    {  
	      a[k+1]=j2/pow((double)(2),(double)k)+1; 
	      j2-=(a[k+1]-1)*pow((double)(2),(double)k);  
	    }  
	  mult=1;  
	  for (l=1;l<=nmanq;l++)  
	    {  
	      gset2[posmanq[l]]=a[l]-1;  
	      if (a[l]-1==1) mult*=pally;  /* Frequency of the "present" band*/
	      else if (a[l]-1==0) mult*=(1-pally);  /* Frequency of the "absent" band */
	    } 
	  eb = make_segs_dom (gset2[2], gset2[3], gset2[1]);  
	  pdpp += mult*seg_prob_dom (pally, F, eb); 
	  pdes += mult*unrel_dom (gset2, pally, 1, F); 
	  ppar1 += mult*unrel_dom (gset2, pally, 2, F);  
	  ppar2 += mult*unrel_dom (gset2, pally, 3, F); 
	  pdp1 += mult*parent_dom(1,2,gset2,pally, F); 
	  pdp2 += mult*parent_dom(1,3,gset2,pally, F); 
	  
	  /* 	  eb = make_segs_dom (gset[2], gset[3], gset[1]);  comparaison de l'�tat des bandes des parents et desc*/ 
	  /* 	  pdpp = seg_prob_dom (pally, F, eb); */
	  /* 	  pdes = unrel_dom (gset, pally, 1, F); */
	  /* 	  ppar1 =unrel_dom (gset, pally, 2, F);  */
	  /* 	  ppar2 =unrel_dom (gset, pally, 3, F); */
	  /* 	  pdp1 = parent_dom(1,2,gset,pally, F); */
	  /* 	  pdp2 = parent_dom(1,3,gset,pally, F); */
	} 
      free(a); 
      
      p  =  ((1-E)*(1-E)*(1-E)*pdpp*ppar1*ppar2 +
	     E*(1-E)*(1-E)*(ppar1*ppar2 + pdp1*ppar1 + pdp2*ppar2) +
	     E*E*(1-E)*(pdes + ppar1 + ppar2) + E*E*E);  
      q  = ((1-E)*(1-E)*(1-E)*pdp1*ppar1*ppar2 + 
	    E*(1-E)*(1-E)*(pdp1*ppar1 + pdes*ppar2 + ppar1*ppar2) + 
	    E*E*(1-E)*(pdes + ppar1 + ppar2) + E*E*E); 
      qp += log(p/q);
    } 
  /* } */
  return(qp);      
}


/********** Single parent and parent pair: dominant markers ***************/


double uparchk_dom (nloc, gk, gp, pf, E, F)
     int nloc, *gk, *gp;
     double *pf, E, F;
     /* single-parent likelihood  */                          
     
{ 
  int i, gset[3];
  int j, k, l, gset2[3], nmanq, j2, *a, posmanq[3], ntot; double mult;  
  double pally, qp, ppar, pdes, pdp, p, q; 
  qp=0; ppar=0; pdes=0; pdp=0; p=0; q=0;
  /* ppar/pdes : proba g�notype parent/des, pdp : proba desc est celui du parent */
  
  for (i=1; i<=nloc ; ++i)
    {
      gset[1] = gk[i]; /*pr�sence ou absence de la bande chez le desc   au locus i*/
      gset[2] = gp[i];  /*                                    le parent           */
      pally= pf[i]; /*pally est la fr�quences de la bandes i*/ 
      /*       printf("\n desc, parent, freq %d, %d, %f",gk[i],gp[i],pf[i]);      */
      nmanq=0; 

      /*if (gset[1]!=(-5) && gset[2]!=(-5))    */
      /*{  */
      for (j=1;j<=2;j++) 
	{   
	  gset2[j]=gset[j];   
	  if (gset[j]==(-5)) 
	    {   
	      nmanq+=1;    
	      posmanq[nmanq]=j;    
	    }   
	}   
      a=(int *)malloc((nmanq+1)*sizeof(int));   
      pdp=0;  
      pdes=0;   
      ppar=0;   
      ntot=pow((double) 2,(double) nmanq);  
      for (j=0; j<ntot; j++)  
	{ 
	  j2=j;   
	  for (k=nmanq-1;k>=0;k--) 
	    {   
	      a[k+1]=j2/pow((double)(2),(double)k)+1; 
	      j2-=(a[k+1]-1)*pow((double)(2),(double)k);   
	    }   
	  mult=1;   
	  for (l=1;l<=nmanq;l++)  
	    {   
	      gset2[posmanq[l]]=a[l]-1;  
	      if (a[l]-1==1) mult*=pally;  
	      else if (a[l]-1==0) mult*=(1-pally); 
	      /*printf("a[l] %d mult %f",a[l] , mult); */
	    }   
	  pdp +=  mult* parent_dom(1,2, gset2, pally, F);
	  /*printf("\n kid %d par %d transition %f", gset2[1], gset2[2], parent_dom(1,2, gset2, pally, F)); */
	  pdes +=  mult* unrel_dom (gset2, pally, 1, F); 
	  ppar +=  mult* unrel_dom (gset2, pally, 2, F); 
	  /*pdp = parent_dom(1,2, gset, pally, F);      */
	  /*pdes = unrel_dom (gset, pally, 1, F); */
	  /*ppar = unrel_dom (gset, pally, 2, F); */
	  /*printf("\n mult, pdp, pdes, ppar , %f, %f, %f, %f \n", mult, pdp,pdes,ppar);   */
	}  
      free(a);  
      /*printf("\n pdp, pdes, ppar , %f, %f, %f \n", pdp,pdes,ppar);    */
      /*qp *= ((1-E)*(1-E)*(pdp*ppar) + E*(1-E)*(pdes + ppar) + E*E) ;  */
      p = ((1-E)*(1-E)*(pdp*ppar) + E*(1-E)*(pdes + ppar) + E*E) ;
      q = ((1-E)*(1-E)*(pdes*ppar) + E*(1-E)*(pdes + ppar) + E*E) ; 
      qp += log(p/q) ;
      /*printf("\n p %f q %f qp %f", p, q, qp);    */
      /* 	           qp /= ((1-E)*(1-E)*(pdes*ppar) + E*(1-E)*(pdes + ppar) + E*E) ; */
      /*qp calcule la proba desc de la m�re/proba desc m�re quelc*/
      /*} */
      /*}  */
    }
  return(qp);
}

double pparchk_dom (nloc, gk, gm, gd, pf, E, F) 
     int nloc;
     double *pf, E, F;     
     int *gk, *gm, *gd;
     /* parent pair likelihood ratio */
{ 
  int i, gset[4], eb; 
  int j, k, l, gset2[4], nmanq, j2, *a, posmanq[4], ntot ; double mult;
  double pally, qp, ppar1, ppar2, pdes, pdp1, pdp2, pdpp, p, q;         
  qp=0; ppar1=0; ppar2=0; pdes=0; pdp1=0; pdp2=0 ;pdpp=0; p=0; q=0;
  /* ppar1, ppar2, pdes : proba des g�notypes des parents 1 et 2, desc,  */
  /* pdp1, pdp2, pdpp : proba que le desc soit issu du parent 1, 2, de la paire  */
  for (i=1; i<=nloc ; ++i)
    { 
      gset[1]=gk[i]  ; /*�tat de la bande desc */
      gset[2]=gm[i]; /*                 parent 1*/
      gset[3]=gd[i]; /*                 parent 2*/
      pally = pf[i]; /*fr�quence de la bande i */
      /*if (gset[1]!=-5 && gset[2]!=-5 && gset[3]!=-5)    */
      /* 	{   */
      nmanq=0;   
      for (j=1;j<=3;j++)  
	{   
	  gset2[j]=gset[j];   
	  if (gset[j]==(-5)) 
	    {   
	      nmanq+=1;    
	      posmanq[nmanq]=j;    
	    }   
	}   
      a=(int *)malloc((nmanq+1)*sizeof(int));   
      pdpp=0;  
      pdes=0;   
      ppar1=0;   
      ppar2=0;   
      pdp1=0;   
      pdp2=0;   
      ntot=pow((double) 2,(double) nmanq);  
      
      for (j=0; j<ntot; j++)  
	{   
	  j2=j;   
	  for (k=nmanq-1;k>=0;k--)  
	    {   
	      a[k+1]=j2/pow((double)(2),(double)k)+1;  
	      j2-=(a[k+1]-1)*pow((double)(2),(double)k);   
	    }   
	  mult=1;   
	  for (l=1;l<=nmanq;l++)  
	    {   
	      gset2[posmanq[l]]=a[l]-1;  
	      if (a[l]-1==1) mult*=pally;  
	      else if (a[l]-1==0) mult*=(1-pally);  
	    }   
	  
	  eb = make_segs_dom (gset2[2], gset2[3], gset2[1]);  /*comparaison de l'�tat des bandes des parents et desc*/ 
	  pdpp += mult*seg_prob_dom (pally, F, eb); 
	  pdes += mult*unrel_dom (gset2, pally, 1, F); 
	  ppar1 += mult*unrel_dom (gset2, pally, 2, F);  
	  ppar2 += mult*unrel_dom (gset2, pally, 3, F); 
	  pdp1 += mult*parent_dom(1,2,gset2,pally, F); 
	  pdp2 += mult*parent_dom(1,3,gset2,pally, F); 
	} 
      /* 	  qp *= ((1-E)*(1-E)*(1-E)*pdpp*ppar1*ppar2 + */
      /*                   E*(1-E)*(1-E)*(ppar1*ppar2 + pdp1*ppar1 + pdp2*ppar2) + */
      /*                   E*E*(1-E)*(pdes + ppar1 + ppar2) + E*E*E);   */
      /* eb = make_segs_dom (gset[2], gset[3], gset[1]);  *//* comparaison de l'�tat des bandes des parents et desc*/ 
      /*printf("\ngset[2] %d, gset[3] %d, gset[1] %d eb %d", gset[2], gset[3], gset[1], eb); */
      /* 	  pdpp = seg_prob_dom (pally, F, eb);  */
      /* 	  pdes = unrel_dom (gset, pally, 1, F);  */
      /* 	  ppar1 = unrel_dom (gset, pally, 2, F);   */
      /* 	  ppar2 = unrel_dom (gset, pally, 3, F); */
      /* 	  pdp1 = parent_dom(1,2,gset,pally, F);  */
      /* 	  pdp2 = parent_dom(1,3,gset,pally, F);  */

      free(a); 
      
      p  =  ((1-E)*(1-E)*(1-E)*pdpp*ppar1*ppar2 +
	     E*(1-E)*(1-E)*(ppar1*ppar2 + pdp1*ppar1 + pdp2*ppar2) +
	     E*E*(1-E)*(pdes + ppar1 + ppar2) + E*E*E);  
      q  = ((1-E)*(1-E)*(1-E)*pdes*ppar1*ppar2 + 
	    E*(1-E)*(1-E)*(pdes*ppar1 + pdes*ppar2 + ppar1*ppar2) + 
	    E*E*(1-E)*(pdes + ppar1 + ppar2) + E*E*E); 
      qp += log(p/q);
      /*qp /= ((1-E)*(1-E)*(1-E)*pdes*ppar1*ppar2 + */
      /*E*(1-E)*(1-E)*(pdes*ppar1 + pdes*ppar2 + ppar1*ppar2) + */
      /*E*E*(1-E)*(pdes + ppar1 + ppar2) + E*E*E); */ 
      /*printf("\n pdpp %f, pdes %f, ppar1 %f, ppar2 %f, pdp1 %f, pdp2 %f p %f q %f qp %f \n",
	pdpp,pdes,ppar1,ppar2,pdp1,pdp2,p,q,qp);  */
      /*}  */
    } 
  return(qp);  
}

/* Number of loci contributing to lod-scores For dominant markers */

double loc_lod_pater_dom (nloc, gk, gm, gd, pf, E, F)
     int nloc;
     double *pf, E, F;     
     int *gk, *gm, *gd;
{ 
  double locl;
  int i, gset[4], eb; 
  int j, k, l, gset2[4], nmanq, j2, *a, posmanq[4], ntot; double mult;
  double pally, qp, ppar1, ppar2, pdes, pdp1, pdp2, pdpp, p, q;         
  locl=0;
  qp=0; ppar1=0; ppar2=0; pdes=0; pdp1=0; pdp2=0 ;pdpp=0; p=0; q=0;
  for (i=1; i<=nloc ; ++i)
    { 
      gset[1]=gk[i]  ; /*�tat de la bande desc */
      gset[2]=gm[i]; /*                 parent 1*/
      gset[3]=gd[i]; /*                 parent 2*/
      pally = pf[i]; /*fr�quence de la bande i */
      nmanq=0;  
      
      for (j=1;j<=3;j++) 
	{  
	  gset2[j]=gset[j];  
	  if (gset[j]==(-5)) 
	    {  
	      nmanq+=1;   
	      posmanq[nmanq]=j;   
	    }  
	} 	 
      a=(int *)malloc((nmanq+1)*sizeof(int));  
      pdpp=0;  
      pdes=0;  
      ppar1=0;   
      ppar2=0;   
      pdp1=0;   
      pdp2=0;  
      ntot=pow((double) 2,(double) nmanq); 
      for (j=0; j<ntot; j++)  
	{  
	  j2=j;  
	  for (k=nmanq-1;k>=0;k--)  
	    {  
	      a[k+1]=j2/pow((double)(2),(double)k)+1; 
	      j2-=(a[k+1]-1)*pow((double)(2),(double)k);  
	    }  
	  mult=1;  
	  for (l=1;l<=nmanq;l++)  
	    {  
	      gset2[posmanq[l]]=a[l]-1;  
	      if (a[l]-1==1) mult*=pally;  
	      else if (a[l]-1==0) mult*=(1-pally);  
	    } 
	  eb = make_segs_dom (gset2[2], gset2[3], gset2[1]);  
	  pdpp += mult*seg_prob_dom (pally, F, eb); 
	  pdes += mult*unrel_dom (gset2, pally, 1, F); 
	  ppar1 += mult*unrel_dom (gset2, pally, 2, F);  
	  ppar2 += mult*unrel_dom (gset2, pally, 3, F); 
	  pdp1 += mult*parent_dom(1,2,gset2,pally, F); 
	  pdp2 += mult*parent_dom(1,3,gset2,pally, F); 	  
	} 
      free(a); 
      
      p  =  ((1-E)*(1-E)*(1-E)*pdpp*ppar1*ppar2 +
	     E*(1-E)*(1-E)*(ppar1*ppar2 + pdp1*ppar1 + pdp2*ppar2) +
	     E*E*(1-E)*(pdes + ppar1 + ppar2) + E*E*E);  
      q  = ((1-E)*(1-E)*(1-E)*pdp1*ppar1*ppar2 + 
	    E*(1-E)*(1-E)*(pdp1*ppar1 + pdes*ppar2 + ppar1*ppar2) + 
	    E*E*(1-E)*(pdes + ppar1 + ppar2) + E*E*E); 
      qp += log(p/q);
      if (qp > 0) locl+=1;
    } 
  return (locl);
}

double loc_lod_1par_dom (nloc, gk, gp, pf, E, F)
     int nloc, *gk, *gp;
     double *pf, E, F;
{ 
  double locl;
  int i, gset[3];
  int j, k, l, gset2[3], nmanq, j2, *a, posmanq[3], ntot; double mult;  
  double pally, qp, ppar, pdes, pdp, p, q; 
  locl=0;
  qp=0; ppar=0; pdes=0; pdp=0; p=0; q=0;  
  for (i=1; i<=nloc ; ++i)
    {
      gset[1] = gk[i]; /*pr�sence ou absence de la bande chez le desc   au locus i*/
      gset[2] = gp[i];  /*                                    le parent           */
      pally= pf[i]; /*pally est la fr�quences de la bandes i*/ 
      nmanq=0; 
      for (j=1;j<=2;j++) 
	{   
	  gset2[j]=gset[j];   
	  if (gset[j]==(-5)) 
	    {   
	      nmanq+=1;    
	      posmanq[nmanq]=j;    
	    }   
	}   
      a=(int *)malloc((nmanq+1)*sizeof(int));   
      pdp=0;  
      pdes=0;   
      ppar=0;   
      ntot=pow((double) 2,(double) nmanq);  
      for (j=0; j<ntot; j++)  
	{ 
	  j2=j;   
	  for (k=nmanq-1;k>=0;k--) 
	    {   
	      a[k+1]=j2/pow((double)(2),(double)k)+1; 
	      j2-=(a[k+1]-1)*pow((double)(2),(double)k);   
	    }   
	  mult=1;   
	  for (l=1;l<=nmanq;l++)  
	    {   
	      gset2[posmanq[l]]=a[l]-1;  
	      if (a[l]-1==1) mult*=pally;  
	      else if (a[l]-1==0) mult*=(1-pally);  
	    }   
	  pdp +=  mult* parent_dom(1,2, gset2, pally, F);      
	  pdes +=  mult* unrel_dom (gset2, pally, 1, F); 
	  ppar +=  mult* unrel_dom (gset2, pally, 2, F); 
	}  
      free(a);  
      p = ((1-E)*(1-E)*(pdp*ppar) + E*(1-E)*(pdes + ppar) + E*E) ;
      q = ((1-E)*(1-E)*(pdes*ppar) + E*(1-E)*(pdes + ppar) + E*E) ; 
      qp += log(p/q) ;
      if (qp > 0) locl+=1;
    }
  return (locl);
}

double loc_lod_2par_dom (nloc, gk, gm, gd, pf, E, F) 
     int nloc;
     double *pf, E, F;     
     int *gk, *gm, *gd;     
{ 
  double locl;
  int i, gset[4], eb; 
  int j, k, l, gset2[4], nmanq, j2, *a, posmanq[4], ntot ; double mult;
  double pally, qp, ppar1, ppar2, pdes, pdp1, pdp2, pdpp, p, q;         
  locl=0;
  qp=0; ppar1=0; ppar2=0; pdes=0; pdp1=0; pdp2=0 ;pdpp=0; p=0; q=0;
  for (i=1; i<=nloc ; ++i)
    { 
      gset[1]=gk[i]  ; /*�tat de la bande desc */
      gset[2]=gm[i]; /*                 parent 1*/
      gset[3]=gd[i]; /*                 parent 2*/
      pally = pf[i]; /*fr�quence de la bande i */
      nmanq=0;   
      for (j=1;j<=3;j++)  
	{   
	  gset2[j]=gset[j];   
	  if (gset[j]==(-5)) 
	    {   
	      nmanq+=1;    
	      posmanq[nmanq]=j;    
	    }   
	}   
      a=(int *)malloc((nmanq+1)*sizeof(int));   
      pdpp=0;  
      pdes=0;   
      ppar1=0;   
      ppar2=0;   
      pdp1=0;   
      pdp2=0;   
      ntot=pow((double) 2,(double) nmanq);  
      
      for (j=0; j<ntot; j++)  
	{   
	  j2=j;   
	  for (k=nmanq-1;k>=0;k--)  
	    {   
	      a[k+1]=j2/pow((double)(2),(double)k)+1;  
	      j2-=(a[k+1]-1)*pow((double)(2),(double)k);   
	    }   
	  mult=1;   
	  for (l=1;l<=nmanq;l++)  
	    {   
	      gset2[posmanq[l]]=a[l]-1;  
	      if (a[l]-1==1) mult*=pally;  
	      else if (a[l]-1==0) mult*=(1-pally);  
	    }   
	  
	  eb = make_segs_dom (gset2[2], gset2[3], gset2[1]);  /*comparaison de l'�tat des bandes des parents et desc*/ 
	  pdpp += mult*seg_prob_dom (pally, F, eb); 
	  pdes += mult*unrel_dom (gset2, pally, 1, F); 
	  ppar1 += mult*unrel_dom (gset2, pally, 2, F);  
	  ppar2 += mult*unrel_dom (gset2, pally, 3, F); 
	  pdp1 += mult*parent_dom(1,2,gset2,pally, F); 
	  pdp2 += mult*parent_dom(1,3,gset2,pally, F); 
	} 
      
      free(a); 
      
      p  =  ((1-E)*(1-E)*(1-E)*pdpp*ppar1*ppar2 +
	     E*(1-E)*(1-E)*(ppar1*ppar2 + pdp1*ppar1 + pdp2*ppar2) +
	     E*E*(1-E)*(pdes + ppar1 + ppar2) + E*E*E);  
      q  = ((1-E)*(1-E)*(1-E)*pdes*ppar1*ppar2 + 
	    E*(1-E)*(1-E)*(pdes*ppar1 + pdes*ppar2 + ppar1*ppar2) + 
	    E*E*(1-E)*(pdes + ppar1 + ppar2) + E*E*E); 
      qp += log(p/q);
      if (qp > 0) locl+=1;
    }
  return (locl);
}

/********** Likelihood ratio for cytoplasmic markers ***************/

double likr_pat_cyt (nc, gk, gp, pf, E, na)
     int nc, *gk, *gp, *na;
     double **pf, E;
     /* paternity likelihood  */                          
     
{ 
  int i, gset[3];
  double pally[3], qp, ppar, pdes, pdp, p, q; 
  int j, k, l, gset2[3], nmanq, j2, *a, posmanq[3], ntot; double mult;
  qp=0; ppar=0; pdes=0; pdp=0; p=0; q=0;
  /* ppar/pdes : proba g�notype parent/des, pdp : proba desc est celui du parent */
  for (i=1; i<=nc ; ++i)
    {
      gset[1] = gk[i]; /*haplotype du desc   au locus i*/
      gset[2] = gp[i];  /*            p�re           */
      nmanq=0; 
      
      for (j=1;j<=2;j++)
	{ 
	  gset2[j]=gset[j]; 
	  if (gset[j]==(-5))
	    { 
	      nmanq+=1;  
	      posmanq[nmanq]=j;  
	    } 
	} 
      a=(int *)malloc((nmanq+1)*sizeof(int)); 
      pdp=0;
      pdes=0; 
      ppar=0; 
      ntot=pow((double) na[i],(double) nmanq);
      for (j=0; j<ntot; j++) 
	/* ntot = (number of allele)^(number of missing data); no missing data= one loop only (j=0)*/
	{ 
	  j2=j; 
	  for (k=nmanq-1;k>=0;k--) 
	    { 
	      a[k+1]=j2/pow((double)(na[i]),(double)k)+1;
	      j2-=(a[k+1]-1)*pow((double)(na[i]),(double)k); 
	      /* all possible allelic states at the missing data are found here */
	    } 
	  mult=1; 
	  for (l=1;l<=nmanq;l++) 
	    { 
	      mult*=pf[i][a[l]]; 
	      gset2[posmanq[l]]=a[l]; 
	    }
	  
	  pally[1]= pf[i][gset2[1]]; /*pally est la fr�quence de l'haplotype du descendant gk */
	  pally[2]= pf[i][gset2[2]]; /*pally est la fr�quence de l'haplotype du p�re gp */
	  /*  if (gset[1]!=(-5) && gset[2]!=(-5)) */  /*?? You don't calculate the lod score if there is no data at the cyto marker*/
	  /* 	{ */
	  if (gset2[1]==gset2[2]) pdp += mult ;
	  if (gset2[1]!=gset2[2]) pdp += 0 ;
	  pdes += mult*pally[1];
	  ppar += mult*pally[2];
	}
      free(a);
      p = ((1-E)*(1-E)*(pdp*ppar) + E*(1-E)*(ppar + pdes) + E*E) ;
      q = ((1-E)*(1-E)*(pdes*ppar) + E*(1-E)*(pdes + ppar) + E*E) ; 
      qp += log(p/q) ;
      /* 	} */
    } 
  return(qp);    
}


double likr_cyt (nc, gk, gp, pf, E, na)
     int nc, *gk, *gp, *na;
     double **pf, E;
     /* single-parent likelihood  */                          
     
{ 
  int i, gset[3];
  double pally[3], qp, ppar, pdes, pdp, p, q; 
  int j, k, l, gset2[3], nmanq, j2, *a, posmanq[3], ntot; double mult;
  qp=0; ppar=0; pdes=0; pdp=0; p=0; q=0;
  /* ppar/pdes : proba g�notype parent/des, pdp : proba desc est celui du parent */
  for (i=1; i<=nc ; ++i)
    {
      gset[1] = gk[i]; /*haplotype du desc   au locus i*/
      gset[2] = gp[i];  /*            parent           */
      nmanq=0; 
      
      for (j=1;j<=2;j++)
	{ 
	  gset2[j]=gset[j]; 
	  if (gset[j]==(-5))
	    { 
	      nmanq+=1;  
	      posmanq[nmanq]=j;  
	    } 
	} 
      a=(int *)malloc((nmanq+1)*sizeof(int)); 
      pdp=0;
      pdes=0; 
      ppar=0; 
      ntot=pow((double) na[i],(double) nmanq);
      for (j=0; j<ntot; j++) 
	/* ntot = (number of allele)^(number of missing data); no missing data= one loop only (j=0)*/
	{ 
	  j2=j; 
	  for (k=nmanq-1;k>=0;k--) 
	    { 
	      a[k+1]=j2/pow((double)(na[i]),(double)k)+1;
	      j2-=(a[k+1]-1)*pow((double)(na[i]),(double)k); 
	      /* all possible allelic states at the missing data are found here */
	    } 
	  mult=1; 
	  for (l=1;l<=nmanq;l++) 
	    { 
	      mult*=pf[i][a[l]]; 
	      gset2[posmanq[l]]=a[l]; 
	    }
	  
	  pally[1]= pf[i][gset2[1]]; /*pally est la fr�quence de l'haplotype du descendant gk */
	  pally[2]= pf[i][gset2[2]]; /*pally est la fr�quence de l'haplotype du parent gp */
	  /*  if (gset[1]!=(-5) && gset[2]!=(-5)) */  /*?? You don't calculate the lod score if there is no data at the cyto marker*/
	  /* 	{ */
	  if (gset2[1]==gset2[2]) pdp += mult*(0.5*(1+pally[1])) ;
	  if (gset2[1]!=gset2[2]) pdp += mult*(0.5*pally[1]) ;
	  pdes += mult*pally[1];
	  ppar += mult*pally[2];
	}
      free(a);
      p = ((1-E)*(1-E)*(pdp*ppar) + E*(1-E)*(ppar + pdes) + E*E) ;
      q = ((1-E)*(1-E)*(pdes*ppar) + E*(1-E)*(pdes + ppar) + E*E) ; 
      qp += log(p/q) ;
      /* 	} */
    } 
  return(qp);    
}

double likr_pair_cyt (nc, gk, gp1, gp2, pf, E, na)
     int nc, *gk, *gp1, *gp2, *na;
     double **pf, E;
     /* parent_pair likelihood  */                              
{ 
  int i, gset[4];
  double pally[4], qp, ppar1, ppar2, pdes, pdpp, pdp1, pdp2, p, q; 
  int j, k, l, gset2[4], nmanq, j2, *a, posmanq[4], ntot; double mult;
  qp=0; ppar1=0; ppar2=0;  pdes=0; p=0; q=0; pdpp=0; pdp1=0; pdp2=0;
  /* ppar/pdes : proba g�notype parent/des, pdp : proba desc est celui du parent */
  
  for (i=1; i<=nc ; ++i)
    {
      gset[1] = gk[i]; /*haplotype du desc   au locus i*/
      gset[2] = gp1[i];  /*            parent           */
      gset[3] = gp2[i];  /*            parent           */
      nmanq=0; 
      
      for (j=1;j<=3;j++)
	{ 
	  gset2[j]=gset[j]; 
	  if (gset[j]==(-5))
	    { 
	      nmanq+=1;  
	      posmanq[nmanq]=j;  
	    } 
	} 
      a=(int *)malloc((nmanq+1)*sizeof(int)); 
      pdpp=0;
      pdp1=0;
      pdp2=0;      
      pdes=0; 
      ppar1=0; 
      ppar2=0; 
      ntot=pow((double) na[i],(double) nmanq);
      for (j=0; j<ntot; j++) 
	/* ntot = (number of allele)^(number of missing data); no missing data= one loop only (j=0)*/
	{ 
	  j2=j; 
	  for (k=nmanq-1;k>=0;k--) 
	    { 
	      a[k+1]=j2/pow((double)(na[i]),(double)k)+1;
	      j2-=(a[k+1]-1)*pow((double)(na[i]),(double)k); 
	      /* all possible allelic states at the missing data are found here */
	    } 
	  mult=1; 
	  for (l=1;l<=nmanq;l++) 
	    { 
	      mult*=pf[i][a[l]]; 
	      gset2[posmanq[l]]=a[l]; 
	    }
	  
	  pally[1]= pf[i][gset2[1]]; /*pally est la fr�quence de l'haplotype du descendant  gk */
	  pally[2]= pf[i][gset2[2]]; /*pally est la fr�quence de l'haplotype du parent gp1 */
	  pally[3]= pf[i][gset2[3]]; 
	  
	  if (gset[1]!=(-5) && gset[2]!=(-5) && gset[3]!=(-5))  /* do not calculate anything if only missing data*/
	    {
	      if (gset2[1]==gset2[2] && gset2[1]==gset2[3]) pdpp += mult*1; 
	      if (gset2[1]==gset2[2] && gset2[1]!=gset2[3]) pdpp += mult*0.5;
	      if (gset2[1]==gset2[3] && gset2[1]!=gset2[2]) pdpp += mult*0.5;
	      if (gset2[1]==gset2[2]) pdp1 +=mult*(0.5*(1+pally[1])) ;
	      if (gset2[1]==gset2[3]) pdp2 +=mult*(0.5*(1+pally[1])) ;
	      if (gset2[1]!=gset2[2]) pdp1 += mult*(0.5*pally[1]) ;
	      if (gset2[1]!=gset2[3]) pdp2 += mult*(0.5*pally[1]) ;

	      /*if ((gset[1]==gset[2] && gset[3]==(-5)) || (gset[1]==gset[3] && gset[2]==(-5)) ) pdp0 = 1; */
	      /*else pdp0 = 0; */
	      /*if ((gset[1]!=gset[2] && gset[3]==(-5)) || (gset[1]!=gset[3] && gset[2]==(-5)) ) pdp1 = 1; */
	      /*else pdp1 = 0; */
	      pdes += mult*pally[1];
	      ppar1 += mult*pally[2];
	      ppar2 += mult*pally[3];
	    }
	  free(a);
	  /*  p = ((1-E)*(1-E)*(1-E)*(pdpp*ppar1*ppar2 + 0.5*pdp*ppar1*ppar2 + */
	  /*          0.5*pdp0*ppar1*ppar2*(1+pdes) + 0.5*pdp1*ppar1*ppar2*pdes) +  */
	  /*  E*(1-E)*(1-E)*0.5*( pdp0*(ppar1*(1+pdes) + ppar2*(1+pdes) + ppar1*ppar2)  */
	  /*            + pdp1*(ppar2*pdes+ ppar1*pdes+ ppar1*ppar2)) + */
	  /*  E*E*(1-E)*(pdes + ppar1 + ppar2) + E*E*E); */
	  p = ((1-E)*(1-E)*(1-E)*(pdpp*ppar1*ppar2) + 
	       E*(1-E)*(1-E)*(ppar1*ppar2 + pdp1*ppar1 + pdp2*ppar2)  +
	       E*E*(1-E)*(pdes + ppar1 + ppar2) + E*E*E);
	  q  = ((1-E)*(1-E)*(1-E)*pdes*ppar1*ppar2 +  
		E*(1-E)*(1-E)*(pdes*ppar1 + pdes*ppar2 + ppar1*ppar2) +  
		E*E*(1-E)*(pdes + ppar1 + ppar2) + E*E*E);  
	  qp += log(p/q) ;
	}
    } 
  return(qp);
}

/************* Half- and full-sib likelihood ratio ******************/


double vsb_hs (gset, pally)  
     int *gset; 
     double *pally;
     /* vraisemblance demi-fr�re */     
{
  double p1,p2, p3;
  int g1,g2,g3,g4, ic; 
  ic=0;
  g1=gset[1]; g2=gset[2]; g3=gset[3]; g4=gset[4]; /*all�les ind 1 /ind 2 */
  p1=pally[1]; p2=pally[2];
  p3=pally[3]; /* fr�quences all�liques */
  ic = genopair_hsfs (g1,g2,g3,g4); /* ic est la relation entre les all�les individu 1/ind 2 id ou dif*/
  if (ic==1)  return(2*p1*(1+p1));
  else if (ic==2)  return (1+2*p1);
  else if (ic==3)  return (1+2*p3);
  else if (ic==4)  return(p1+p2+4*p1*p2);
  else if (ic ==5) return(1+4*p1);
  else if (ic ==6) return(1+4*p2);
  else if (ic ==7) return(2);
}

double vsb_fs (gset, pally)
     int *gset; 
     double *pally;
     /* vraisemblance plein-fr�re */
     
{
  double p1,p2,p3; 
  int g1,g2,g3,g4, ic;
  ic=0;
  g1=gset[1]; g2=gset[2]; g3=gset[3]; g4=gset[4]; /*all�les ind 1 /ind 2 */
  p1=pally[1]; p2=pally[2];
  p3=pally[3]; /* fr�quences all�liques */
  ic = genopair_hsfs (g1,g2,g3,g4); /* ic est la relation entre les all�les individu 1/ind 2 id ou dif*/
  if (ic==1)  return((1+p1)*(1+p1));
  else if (ic==2)  return (1+p1);
  else if (ic==3)  return (1+p3);
  else if (ic==4)  return(1+p1+p2+2*p1*p2);
  else if (ic ==5) return(1+2*p1);
  else if (ic ==6) return(1+2*p2);
  else if (ic ==7) return(1);
}


int genopair_hsfs (g1, g2, g3, g4)  
     int g1,g2,g3,g4;
     /* les 4 all�les des deux individus � comparer : 7 cas de figure 15 configurations*/
{    
  if (g1==g2 && g3==g4 && g1==g3)            return(1);  /*1) cas des deux individus PP et PP*/

  else if (g1==g2 && g3==g1 && g3!=g4)            return(2);  /*2) cas PP et PQ */
  else if (g1==g2 && g4==g1 && g3!=g4)            return(2);  /*3) cas PP et QP*/
  else if (g3==g4 && g3==g1 && g1!=g2)            return(3);  /*4) cas PQ et PP*/                       
  else if (g3==g4 && g3==g2 && g1!=g2)            return(3);  /*5) cas QP et PP*/                       

  else if (g1==g3 && g2==g4 && g1!=g2 && g3!=g4)  return(4);  /*6) cas PQ et PQ*/
  else if (g1==g4 && g2==g3 && g1!=g2 && g3!=g4)  return(4);  /*7) cas PQ et QP*/

  else if (g1==g3 && g2!=g4 && g1!=g2)            return(5);  /*8) cas PQ et PR*/
  else if (g1==g4 && g1!=g3 && g1!=g2)            return(5);  /*9) cas PQ et RP*/    
  else if (g2==g3 && g2!=g4 && g1!=g2)            return(6);  /*10) cas QP et PR*/
  else if (g2==g4 && g1!=g3 && g1!=g2)            return(6);  /*11) cas QP et RP*/    

  else if (g1!=g2 && g3!=g4 && g1!=g3)            return(7);  /*12) cas PQ et RS*/
  else if (g1==g2 && g3!=g4 && g1!=g3)            return(7);  /*13) cas PP et RS*/
  else if (g1!=g2 && g3==g4 && g1!=g3)            return(7);  /*14) cas RS et PP*/
  else if (g1==g2 && g3==g4 && g1!=g3)            return(7);  /*15) cas RR et PP*/       
}


void verif_loc(gk, gp, nloc, pf1) 
     Geno *gk, *gp; 
     int nloc;
     double **pf1;
     /* v�rification de la relation entre les g�notypes  */      
{
  int i,j,p, gset[5]; 
  double pally[5];
  p=0; 
  for (i=1; i<=nloc ; ++i) 
    {
      gset[1] = gk[i].g1; gset[2] = gk[i].g2; /*nom des all du parent gk au locus i*/ 
      gset[3] = gp[i].g1; gset[4] = gp[i].g2; /*nom des all du parent gp locus i*/ 
      for (j=1; j< 5; ++j) if (gset[j]!=-5) pally[j]= pf1[i][gset[j]]; /*range dans le tableau pally...*/  
                                                      /*...les fr�q des 4 all�les*/ 
      p = genopair_hsfs( gset[1], gset[2], gset[3],gset[4]);             
      printf("locus n�%d, relation :%d\n",i,p);                     
    } 
}  

double unrel_hsfs(gset, pally)
     double *pally; 
     int *gset;
     /*vraisemblance de deux individus non apparent�s */
     
{
  double p1,p2, p3; 
  int g1,g2,g3,g4, ic;
  ic=0;
  g1=gset[1]; g2=gset[2]; g3=gset[3]; g4=gset[4]; /*all�les ind 1 /ind 2 */
  p1=pally[1]; p2=pally[2];
  p3=pally[3]; /* fr�quences all�liques */
  ic = genopair_hsfs (g1,g2,g3,g4); /* ic est la relation entre les all�les individu 1/ind 2 id ou dif*/
  if (ic==1)  return(2*p1*2*p1);
  else if (ic==2)  return (4*p1);
  else if (ic==3)  return (4*p3);
  else if (ic==4)  return(8*p1*p2);
  else if (ic ==5) return(8*p1);
  else if (ic ==6) return(8*p2);
  else if (ic ==7) return(4);
}


double half_sib (gk, gp, nl, pf1)  
     Geno *gk, *gp;
     int nl;
     double **pf1;
     /* lod score demi-fr�re  */
{ 
  int i, j, gset[5]; 
  double pally[5], qp, pu, phs; 
  qp=0; pu=0; phs=0;
  for (i=1; i<=nl ; ++i)
    {  
      if (gk[i].g1 !=(-5) && gk[i].g2 !=(-5) && gp[i].g1 !=(-5) && gp[i].g2 !=(-5))
	{ 
	  gset[1] = gk[i].g1; gset[2] = gk[i].g2; /*nom des all du parent gk au locus i*/
	  gset[3] = gp[i].g1; gset[4] = gp[i].g2; /*nom des all du parent gp locus i*/
	  for (j=1; j< 5; ++j) pally[j]= pf1[i][gset[j]]; /*range dans le tableau pally...*/ 
	                                                  /*...les fr�q des 4 all�les*/
	  phs = vsb_hs(gset, pally);                 
	  pu = unrel_hsfs (gset, pally);
	  qp += log(phs)-log(pu) ; 
	}	
    }
  return(qp);
}


double full_sib (gk, gp, nl, pf1)
     Geno *gk, *gp;
     int nl;
     double **pf1;
     /* lod score plein-fr�re  */ 
{
  int i, j, gset[5]; 
  double pally[5], qp, pu, pfs;
  qp=0; pu=0; pfs=0;
  for (i=1; i<=nl ; ++i)
    {
      if (gk[i].g1 !=(-5) && gk[i].g2 !=(-5) && gp[i].g1 !=(-5) && gp[i].g2 !=(-5)) 
	{
	  gset[1] = gk[i].g1; gset[2] = gk[i].g2; /*nom des all du parent gk au locus i*/
	  gset[3] = gp[i].g1; gset[4] = gp[i].g2; /*nom des all du parent gp locus i*/
	  for (j=1; j< 5; ++j) pally[j]= pf1[i][gset[j]]; /*range dans le tableau pally...*/ 
	                                                  /*...les fr�q des 4 all�les*/
	  pfs = vsb_fs(gset, pally);
	  pu = unrel_hsfs (gset, pally);
	  qp += log(pfs)-log(pu) ; 
	}
    }
  return(qp);
}


/* Likelihoods with two species, and rates of hybridization */

double vsb_hs_sp (gset, pallys, pallyp, S, s, p)  
     int *gset; 
     double *pallys, *pallyp, S, s, p ; /* S: percentage of the first species, s hybridization rate s->p, p, the opposite*/
     /* vraisemblance demi-fr�re dans le cas deux esp�ces et hybridations */     
{
  double pS, pP, pS1, pP1, pS2, pP2, pS3, pP3, ss, pp, sp, ps;
  double f1, f2, f3, f4, f5, f6, f7, f8, f9, f10, f11, f12; /* formules */ 
  double f13, f14, f15, f16, f17, f18, f19, f20, f21, f22, f23, f24, f25, f26, f27, f28, f29, f30;  
  int g1, g2, g3, g4, ic, t; 
  s=(1-s)*(1-s)*1/S;
  p=(1-p)*(1-p)*1/(1-S);
  ss=s*s*1/S;
  pp=p*p*1/(1-S);
  ps=s*(1-p)/S;
  sp=p*(1-s)/(1-S);

  ic=0; t=0;
  g1=gset[1]; g2=gset[2]; g3=gset[3]; g4=gset[4]; /*all�les ind 1 /ind 2 */

  ic = genopair_hsfs_sp (g1,g2,g3,g4); /* ic est la relation entre les all�les individu 1/ind 2 id ou dif*/
  pS = pallys[1];
  pP = pallyp[1];

  if (ic==1)  
    { 
      f1 = s*pS*pS*pS*pS; 
      /* pick a PP sessile mother, pick one p allele randomly, pick the same mother again (1),*/
      /* size of the reproduccing population, and pick another P allele */
      f2 = p*pP*pP*pP*pP*2;
      f3 = ss*pS*pS*pP*pP*2;
      f4 = pp*pP*pP*pS*pS*2;
      f5 = sp*pS*pS*2*pS*pP; /* fist pick a sessile then a ped, or the opposite =2 */
      f6 = ps*pP*pP*2*pP*pS;
      f7 = s*pS*(1-pS)*pS*pS; /* 2p.*0.5*p*0.5*p*2 */
      f8 = p*pP*(1-pP)*pP*pP;
      f9 = ss*pS*(1-pS)*pP*pP;
      f10 = pp*pP*(1-pP)*pS*pS;
      f11 = sp*pS*(1-pS)*2*pS*pP;
      f12 = ps*pP*(1-pP)*2*pP*pS;

      return(f1 + f2 + f3 + f4 + f5 + f6 + f7 + f8 + f9 + f10 + f11 + f12);
    }
  else if (ic==2) 
    {
      pS1 = pallys[4];
      pP1 = pallyp[4];
      t=1;
    }
  else if (ic==3)
    {  
      pS1 = pallys[3];
      pP1 = pallyp[3];
      t=1;
    }

  else if (ic==4)
    {  
      pS1 = pallys[2];
      pP1 = pallyp[2];
      t=1;
    }
  
  else if (ic==5)
    {  
      pS = pallys[2];
      pP = pallyp[2];
      pS1 = pallys[1];
      pP1 = pallyp[1];
      t=1;
    }
  
  if (t==1) 
    {
      f1 = s*pS*pS*pS*pS1*2 ;
      f2 = p*pP*pP*pP*pP1*2 ;
      f3 = ss*pS*pS*pP*pP1*2 ;
      f4 = pp*pP*pP*pS*pS1*2 ;
      f5 = sp*pS*pS*2*(pS*pP1 + pS1*pP); 
      /* cas m�re sess PP, pollen sess P et ped Q, ou le contraire */
      f6 = ps*pP*pP*2*(pP*pS1 + pP1*pS);
      f7 = s*pS*(1-pS)*pS*pS1 ; /* 2p.*0.5*p*0.5*q*2 */
      f8 = s*pS*pS1*pS*pS ; /* 2pq*0.5*p*0.5*q*2 */
      f9 = p*pP*(1-pP)*pP*pP1 ;
      f10 = p*pP*pP1*pP*pP ;
      f11 = ss*pS*(1-pS)*pP*pP1 ;
      f12 = pp*pP*(1-pP)*pS*pS1 ;
      f13 = ss*pS*pS1*pP*pP ;
      f14 = pp*pP*pP1*pS*pS ;
      f15 = sp*pS*(1-pS)*(pS*pP1 + pS1*pP) ;
      f16 = sp*pS*pS1*2*pS*pP ;
      f17 = ps*pP*(1-pP)*(pP*pS1 + pP1*pS) ;
      f18 = ps*pP*pP1*2*pP*pS ;

      return (f1 + f2 + f3 + f4 + f5 + f6 + f7 + f8 + f9 + 
	      f10 + f11 + f12 + f13 + f14 + f15 + f16 + f17 + f18);
    }
  
  else if (ic==6)
    {  
      pS = pallys[2];
      pP = pallyp[2];

      f1 = 2*s*pS*pS*pS1*pS1 ;       /**** common parent PP or QQ */
      f2 = s*0.5*pS*pS1*2*pS*pS1 ;     /* common parent PQ */
      f3 = s*0.5*pS1*(1-pS1)*pS*pS ; /* common parent Q. */
      f4 = s*0.5*pS*(1-pS)*pS1*pS1 ; /* common parent P. */
      f5 = ss*pS*pS*pP1*pP1 ;       /**** common parent PP */
      f6 = ss*pS1*pS1*pP*pP ;       /* common parent QQ */
      f7 = ss*0.5*pS*(1-pS)*pP1*pP1 ; /* common parent P. */
      f8 = ss*0.5*pS*pS1*2*pP*pP1 ;     /* common parent PQ */
      f9 = ss*0.5*pS1*(1-pS1)*pP*pP ; /* common parent Q. */
      f10 = sp*pS*pS*2*pS1*pP1 ;       /**** common parent PP */
      f11 = sp*pS1*pS1*2*pS*pP ;       /* common parent QQ */
      f12 = sp*0.5*pS*pS1*(2*pS*pP1 + 2*pS1*pP) ;     /* common parent PQ */
      f13 = sp*0.5*pS1*(1-pS1)*2*pS*pP ; /* common parent Q. */
      f14 = sp*0.5*pS*(1-pS)*2*pS1*pP1 ; /* common parent P. */
      f15 = 2*p*pP*pP*pP1*pP1 ; 
      f16 = p*0.5*pP*(1-pP)*pP1*pP1;
      f17 = p*0.5*pP*pP1*2*pP*pP1 ;
      f18 = p*0.5*pP1*(1-pP1)*pP*pP ;
      f19 = pp*pP*pP*pS1*pS1 ; 
      f20 = pp*pP1*pP1*pS*pS ; 
      f21 = pp*0.5*pP*(1-pP)*pS1*pS1;
      f22 = pp*0.5*pP*pP1*2*pS*pS1 ;
      f23 = pp*0.5*pP1*(1-pP1)*pS*pS ;
      f24 = ps*pP*pP*2*pP1*pS1 ; 
      f25 = ps*pP1*pP1*2*pP*pS ; 
      f26 = ps*0.5*pP*pP1*(2*pP*pS1 + 2*pP1*pS) ;
      f27 = ps*0.5*pP1*(1-pP1)*2*pP*pS ;
      f28 = ps*0.5*pP*(1-pP)*pP1*pS1;
      return (f1 + f2 + f3 + f4 + f5 + f6 + f7 + f8 + f9 + f10 + f11 + f12 + f13 + f14 + 
	      f15 + f16 + f17 + f18 + f19 + f20 + f21 + f22 + f23 + f24 + f25 + f26 + f27 + f28);
    }
  else if (ic == 7) 
    {
      pS1 = pallys[2];
      pP1 = pallyp[2];
      pS2 = pallys[4];
      pP2 = pallyp[4];
      t=2;
    }
  else if (ic == 71) 
    {
      pS1 = pallys[2];
      pP1 = pallyp[2];
      pS2 = pallys[3];
      pP2 = pallyp[3];
      t=2;
    }  
  else if (ic == 8) 
    {
      pS = pallys[2];
      pP = pallyp[2];
      pS1 = pallys[1];
      pP1 = pallyp[1];
      pS2 = pallys[4];
      pP2 = pallyp[4];
      t=2;
    }
  else if (ic == 81) 
    {
      pS = pallys[2];
      pP = pallyp[2];
      pS1 = pallys[1];
      pP1 = pallyp[1];
      pS2 = pallys[3];
      pP2 = pallyp[3];
      t=2;
    }
  if (t==2) 
    {
      f1 = s*pS*pS*2*pS1*pS2 ; /* common parent PP */
      f2 = s*pS*(1-pS-pS1-pS2)*0.5*2*pS1*pS2 ; /* common parent P. */
      f3 = s*pS*pS1*0.5*2*pS*pS2 ; /* common parent PQ */
      f4 = s*pS*pS2*0.5*2*pS1*pS ; /* common parent PR */
      f5 = s*pS1*pS2*0.5*pS*pS ; /* common parent QR */
      f6 = ss*pS*pS*2*pP1*pP2 ;
      f7 = ss*pS*(1-pS-pS1-pS2)*0.5*2*pP1*pP2 ;
      f8 = ss*pS*pS1*0.5*2*pP*pP2 ;
      f9 = ss*pS*pS2*0.5*2*pP1*pP ;
      f10 = ss*pS1*pS2*0.5*pP*pP ;
      f11 = sp*pS*pS*(2*pS1*pP2 + 2*pS2+pP1);
      f12 = sp*pS*(1-pS-pS1-pS2)*0.5*(2*pS1*pP2 + 2*pS2*pP1) ;
      f13 = sp*pS*pS1*0.5*(2*pS*pP2 + 2*pS2*pP) ;
      f14 = sp*pS*pS2*0.5*(2*pS1*pP + 2*pS*pP1) ;
      f15 = sp*pS1*pS2*0.5*2*pS*pP ;
      f16 = p*pP*pP*2*pP1*pP2 ;
      f17 = p*pP*(1-pP-pP1-pP2)*0.5*2*pP1*pP2 ;
      f18 = p*pP*pP1*0.5*2*pP*pP2 ;
      f19 = p*pP*pP2*0.5*2*pP1*pP ;
      f20 = p*pP1*pP2*0.5*pP*pP ;
      f21 = pp*pP*pP*2*pS1*pS2 ;
      f22 = pp*pP*(1-pP-pP1-pP2)*0.5*2*pS1*pS2 ;
      f23 = pp*pP*pP1*0.5*2*pS*pS2 ;
      f24 = pp*pP*pP2*0.5*2*pS1*pS ;
      f25 = pp*pP1*pP2*0.5*pS*pS ;
      f26 = ps*pP*pP*(2*pP1*pS2 + 2*pP2*pS1) ;
      f27 = ps*pP*(1-pP-pP1-pP2)*0.5*2*pS1*pS2 ;
      f28 = ps*pP*pP1*0.5*(2*pP*pS2 + 2*pP2*pS) ;
      f29 = ps*pP*pP2*0.5*2*(pP1*pS + pP*pS1) ;
      f30 = ps*pP1*pP2*0.5*2*pP*pS ;

      return (f1 + f2 + f3 + f4 + f5 + f6 + f7 + f8 + f9 + f10 + 
	      f11 + f12 + f13 + f14 + f15 + f16 + f17 + f18 + f19 + f20 + 
	      f21 + f22 + f23 + f24 + f25 + f26 + f27 + f28 + f29 + f30);
    }
  else if (ic == 9)  /* no common allele */
    {
      pS1 = pallys[2];
      pS2 = pallys[3];
      pS3 = pallys[4];
      pP1 = pallys[2];
      pP2 = pallys[3];
      pP3 = pallys[4];

      f1 = s*6*pS1*pS2*pS3*pS ; 
      /* parent commun pq, pr, ps, qr, qs ou rs et 2*0.5*0.5*2 � chaque fois = 6*/
      f2 = ss*pS*pS1*pP2*pP3 ;
      f3 = ss*pS*pS2*pP1*pP3 ;
      f4 = ss*pS*pS3*pP1*pP2 ;
      f5 = ss*pS1*pS2*pP*pP3 ;
      f6 = ss*pS1*pS3*pP*pP2 ;
      f7 = ss*pS2*pS3*pP*pP1 ;
      f8 = sp*pS*pS1*(pS2*pP3 + pS3*pP2) ;
      f9 = sp*pS*pS2*(pS1*pP3 + pS3*pP1) ;
      f10 = sp*pS*pS3*(pS1*pP2 + pS2*pP1) ;
      f11 = sp*pS1*pS2*(pS*pP3 + pS3*pP) ;
      f12 = sp*pS1*pS3*(pS*pP2 + pS2*pP) ;
      f13 = sp*pS2*pS3*(pS*pP1 + pS1*pP) ;
      f14 = p*6*pP1*pP2*pP3*pP ;
      f15 = pp*pP*pP1*pS2*pS3 ;
      f16 = pp*pP*pP2*pS1*pS3 ;
      f17 = pp*pP*pP3*pS1*pS2 ;
      f18 = pp*pP1*pP2*pS*pS3 ;
      f19 = pp*pP1*pP3*pS*pS2 ;
      f20 = pp*pP2*pP3*pS*pS1 ;
      f21 = ps*pP*pP1*(pP2*pS3 + pP3*pS2) ;
      f22 = ps*pP*pP2*(pP1*pS3 + pP3*pS1) ;
      f23 = ps*pP*pP3*(pP1*pS2 + pP2*pS1) ;
      f24 = ps*pP1*pP2*(pP*pS3 + pP3*pS) ;
      f25 = ps*pP1*pP3*(pP*pS2 + pP2*pS) ;
      f26 = ps*pP2*pP3*(pP*pS1 + pP1*pS) ;

      return (f1 + f2 + f3 + f4 + f5 + f6 + f7 + f8 + f9 + f10 + f11 + f12 + f13 + 
	      f14 + f15 + f16 + f17 + f18 + f19 + f20 + f21 + f22 + f23 + f24 + f25 + f26) ;
    }
  else if (ic == 10)  /* no common allele */
    {
      pS1 = pallys[3];
      pS2 = pallys[4];
      pP1 = pallyp[3];
      pP2 = pallyp[4];
      t=3;
    }
   else if (ic == 11)  /* no common allele */
    {
      pS = pallys[3];
      pS1 = pallys[1];
      pS2 = pallys[2];
      pP = pallyp[3];
      pP1 = pallyp[1];
      pP2 = pallyp[2];
      t=3;
    }
 
  if(t==3) 
    {
      f1 = s*2*pS*pS1*pS*pS2 ; /* Common parent PR or PS 2pr*0.5*p*0.5*s*2 ou 2*ps*0.5*p*0.5*r*2*/
      f2 = ss*pS*pS1*pP*pP2 ;
      f3 = ss*pS*pS2*pP*pP1 ;
      f4 = sp*pS*pS1*(pS*pP2 + pS2*pP) ;
      f5 = sp*pS*pS2*(pS*pP1 + pS1*pP) ;
      f6 = p*2*pP*pP1*pP*pP2 ; 
      f7 = pp*pP*pP1*pS*pS2 ;
      f8 = pp*pP*pP2*pS*pS1 ;
      f9 = ps*pP*pP1*(pP*pS2 + pP2*pS) ;
      f10 = ps*pP*pP2*(pP*pS1 + pP1*pS) ;

      return (f1 + f2 + f3 + f4 + f5 + f6 + f7 + f8 + f9 + f10);
    }
  else if (ic==12)
    {
      pS = pallys[1];
      pS1 = pallys[3];
      pP = pallyp[1];
      pP1 = pallyp[3];

      f1 = s*pS*pS1*pS*pS1 ; /*2pr*0.5*p*0.5*r*2 */
      f2 = ss*pS*pS1*pP*pP1 ;
      f3 = sp*pS*pS1*(pS*pP1 + pS1*pP) ;
      f4 = p*pP*pP1*pP*pP1 ;
      f5 = pp*pP*pP1*pS*pS1 ;
      f6 = ps*pP*pP1*(pP*pS1 + pP1*pS) ;

      return (f1 + f2 + f3 + f4 + f5 + f6) ;
    }
}

double vsb_fs_sp (gset, pallys, pallyp, S, s, p)
     int *gset; 
     double *pallys, *pallyp, S, s, p ;
     /* vraisemblance plein-fr�re */
     
{
  double pS, pP, pS1, pP1, pS2, pP2, pS3, pP3, ss, pp, sp, ps; 
  int g1, g2, g3, g4, ic, t;
  double f1, f2, f3, f4, f5, f6, f7, f8, f9, f10, f11, f12, f13, f14; /* formules */ 
  ss=(1-s)/(S*S);
  pp=(1-p)/((1-S)*(1-S));
  sp=s/(S*(1-S));
  ps=p/(S*(1-S));
  ic=0; t=0;
  g1=gset[1]; g2=gset[2]; g3=gset[3]; g4=gset[4]; /*all�les ind 1 /ind 2 */

  ic = genopair_hsfs_sp (g1,g2,g3,g4); /* ic est la relation entre les all�les individu 1/ind 2 id ou dif*/
  pS = pallys[1];
  pP = pallyp[1];
  pS1 = pallys[2];
  pP1 = pallyp[2];

  if (ic==1)
    {  
      f1 = ss*pS*pS*pS*pS ; /*parents PP and PP*/
      f2 = ss*pS*pS*pS*(1-pS) ;  /*parents PP and 2P. * 0.5 *0.5*2 */
      /* PP can be the mother and P. the father and vice-versa, hence an additionnal factor 2*/
      f3 = ss*0.25*pS*(1-pS)*pS*(1-pS) ; /*parents 2*P. and 2*P.*0.25*0.25* */
      f4 = pp*pP*pP*pP*pP ;
      f5 = pp*pP*pP*pP*(1-pP) ;/* 2*0.5 */
      f6 = pp*0.25*pP*pP*(1-pP)*(1-pP) ; 
      f7 = (sp+ps)*2*pS*pS*pP*pP ;
      f8 = (sp+ps)*(pS*pS*pP*(1-pP) + pS*(1-pS)*pP*pP) ;
      f9 = (sp+ps)*2*0.25*pS*(1-pS)*pP*(1-pP);
      return (f1 + f2 + f3 + f4 + f5 + f6 + f7 + f8 + f9);
    }
  
  else if (ic==2) 
    {
      pS1 = pallys[4];
      pP1 = pallyp[4];
      t=1;
    }
  else if (ic==3)
    {  
      pS1 = pallys[3];
      pP1 = pallyp[3];
      t=1;
    }
  else if (ic==4) t=1;
  
  else if (ic==5)
    {  
      pS = pallys[2];
      pP = pallyp[2];
      pS1 = pallys[1];
      pP1 = pallyp[1];
      t=1;
    }
  
  if (t==1) 
    {
      f1 = ss*pS*pS*pS*pS1; /* PP mother & 2*PQ father *0.5*0.5 or the opposite : *2 */
      f2 = ss*0.5*pS*pS1*pS*pS1 ; /* 2PQ*2PQ*0.5*0.25 */
      f3 = ss*0.5*pS*pS1*pS*(1-pS-pS1) ;/* 2PQ*2P.*0.25*0.25*2 pour p�re*m�re et le contraire*/
      f4 = pp*pP*pP*pP*pP1; 
      f5 = pp*0.5*pP*pP1*pP*pP1 ;
      f6 = pp*0.5*pP*pP1*pP*(1-pP-pP1) ;
      f7 = (sp+ps)*(pS*pS*pP*pP1 + pS*pS1*pP*pP) ; 
      f8 = (sp+ps)*pP*pP1*pS*pS1 ;
      f9 = (sp+ps)*0.5*(pS*pS1*pP*(1-pP-pP1) + pP*pP1*pS*(1-pS-pS1));
      return (f1 + f2 + f3 + f4 + f5 + f6 + f7 + f8 + f9) ;
    }

  else if (ic == 6)  
    {
      f1 = ss*2*pS*pS*pS1*pS1; /* PP*QQ *2 : p�re/m�re */
      f2 = ss*pS*pS*pS1*(1-pS1); /* PP*2Q.*0.5*0.5*2  */
      f3 = ss*pS1*pS1*pS*(1-pS); /* QQ*2P.*0.5*0.5*2 */
      f4 = ss*pS*pS1*pS*pS1; /* 2PQ *2PQ *0.5*0.5 */
      f5 = ss*0.5*pS*(1-pS)*pS1*(1-pS1); /* 2P.*2Q.*0.25*0.25*2 */
      f6 = pp*2*pP*pP*pP1*pP1;
      f7 = pp*pP*pP*pP1*(1-pP1);
      f8 = pp*pP1*pP1*pP*(1-pP);
      f9 = pp*pP*pP1*pP*pP1;
      f10 = pp*0.5*pP*(1-pP)*pP1*(1-pP1);
      f11 = (sp+ps)*2*(pS*pS*pP1*pP1 + pS1*pS1*pP*pP);
      f12 = (sp+ps)*(pS*pS*pP1*(1-pP1) + pS1*pS1*pP*(1-pP)); 
      f13 = (sp+ps)*(pS*pS1*pP*pP1);
      f14 = (sp+ps)*0.5*(pS*(1-pS)*pP1*(1-pP1) + pS1*(1-pS1)*pP*(1-pP));

      return (f1 + f2 + f3 + f4 + f5 + f6 + f7 + f8 + f9 + f10 + f11 + f12 + f13 + f14);
    }
  
  else if (ic == 7)      
    {
      pS = pallys[2];
      pS2 = pallys[4];
      pP2 = pallyp[4];
      t=2;
    }
  else if (ic == 71) 
    {
      pS2 = pallys[3];
      pP2 = pallyp[3];
      t=2;
   }
 else if ( ic == 8) 
   {
     pS = pallys[2];
     pP = pallyp[2];
     pS1 = pallys[1];
     pP1 = pallyp[1];
     pS2 = pallys[3];
     pP2 = pallyp[3];
     t=2;
   }
  else if (ic == 81) 
    {
      pS = pallys[2];
      pP = pallyp[2];
      pS1 = pallys[1];
      pP1 = pallyp[1];
      pS2 = pallys[4];
      pP2 = pallyp[4];
      t=2;
    }
  
  if (t==2) 
    {
      f1 = ss*pS*pS*pS1*pS2 ; /* pp*2qr*0.5*0.5*2 */
      f2 = ss*0.5*pS1*pS*pS2*pS ; /*2pq*2pr*0.25*0.25*2 */
      f3 = ss*0.5*pS*(1-pS)*pS1*pS2 ; /*2p.*2qr*0.25*0.25*2 */
      f4 = pp*pP*pP*pP1*pP2 ;
      f5 = pp*0.5*pP1*pP*pP2*pP ; 
      f6 = pp*0.5*pP*(1-pP)*pP1*pP2 ; 
      f7 = (sp + ps)*(pS*pS*pP1*pP2 + pS1*pS2*pP*pP) ; 
      f8 = (sp+ ps)*0.5*(pS1*pS*pP2*pP + pS2*pS*pP1*pP) ;
      f9 = (sp + ps)*0.5*(pS*(1-pS)*pP1*pP2 + pS1*pS2*pP*(1-pP)) ; 

      return (f1 + f2 + f3 + f4 + f5 + f6 + f7 + f8 + f9);
    }

  else if (ic ==9) /* no common allele, Only PQ/RS or PR/QS (hence factor 2) cases */
    {
      pS2 = pallys[3];
      pP2 = pallyp[3];
      pS3 = pallys[4];
      pP3 = pallyp[4];
      f1  = ss*pS1*pS2*pS3*pS ; /* 2pq*2rs*0.25*0.25*2 + 2pr*2qs*0.25*0.25*2 */
      f2  = pp*pP1*pP2*pP3*pP ;
      f3  = sp*0.5*pS*pS1*pP2*pP3 ; /* 2pq*2rs*0.25*0.25*2 */
      f4  = sp*0.5*pS*pS2*pP1*pP3 ;
      f5  = sp*0.5*pS*pS3*pP1*pP2 ;
      f6  = sp*0.5*pS1*pS2*pP*pP3 ;
      f7  = sp*0.5*pS1*pS3*pP*pP2 ;
      f8  = sp*0.5*pS2*pS3*pP*pP1 ;
      f9  = ps*0.5*pS*pS1*pP2*pP3 ;
      f10 = ps*0.5*pS*pS2*pP1*pP3 ;
      f11 = ps*0.5*pS*pS3*pP1*pP2 ;
      f12 = ps*0.5*pS1*pS2*pP*pP3 ;
      f13 = ps*0.5*pS1*pS3*pP*pP2 ;
      f14 = ps*0.5*pS2*pS3*pP*pP1 ;
      return (f1 + f2 + f3 + f4 + f5 + f6 + f7 + f8 + f9 + f10 + f11 + f12 + f13 + f14);
    }

  else if (ic == 10)  /* no common allele */
    {
      pS1 = pallys[3];
      pS2 = pallys[4];
      pP1 = pallyp[3];
      pP2 = pallyp[4];
      t=3;
    }
   else if (ic == 11)  /* no common allele */
    {
      pS = pallys[3];
      pS1 = pallys[1];
      pS2 = pallys[2];
      pP = pallyp[3];
      pP1 = pallyp[1];
      pP2 = pallyp[2];
      t=3;
    }
 
  if(t==3) 
    {
      f1 = ss*0.5*pS*pS1*pS*pS2 ; /* Common parent PR & PS 2*pr*2*ps*0.25*0.25*2 */
      f2 = pp*0.5*pP*pP1*pP*pP2 ; 
      f3 = sp*0.5*pS*pS1*pP*pP2 ;
      f4 = sp*0.5*pS*pS2*pP*pP1 ;
      f5 = ps*0.5*pS*pS1*pP*pP2 ;
      f6 = ps*0.5*pS*pS2*pP*pP1 ;
      return (f1 + f2 + f3 + f4 + f5 + f6);
    }
  else if (ic==12)
    {
      pS1 = pallys[3];
      pP1 = pallyp[3];

      f1 = ss*0.25*pS*pS1*pS*pS1 ; /* 2pr*2pr*0.25*0.25 */
      f2 = pp*0.25*pP*pP*pP1*pP1 ;
      f3 = sp*0.25*pS*pS1*pP*pP1 ;
      f4 = ps*0.25*pS*pS1*pP*pP1 ;
      return (f1 + f2 + f3 + f4) ;
    }
}


int genopair_hsfs_sp (g1, g2, g3, g4)  
     int g1,g2,g3,g4;
     /* les 4 all�les des deux individus � comparer : 7 cas de figure 15 configurations*/
{    
  if (g1==g2 && g3==g4 && g1==g3)            return(1);  /*1) cas des deux individus PP et PP*/

  else if (g1==g2 && g3==g1 && g3!=g4)            return(2);  /*2) cas PP et PQ */
  else if (g1==g2 && g4==g1 && g3!=g4)            return(3);  /*3) cas PP et QP*/
  else if (g3==g4 && g3==g1 && g1!=g2)            return(4);  /*4) cas PQ et PP*/                       
  else if (g3==g4 && g3==g2 && g1!=g2)            return(5);  /*5) cas QP et PP*/                       

  else if (g1==g3 && g2==g4 && g1!=g2 && g3!=g4)  return(6);  /*6) cas PQ et PQ*/
  else if (g1==g4 && g2==g3 && g1!=g2 && g3!=g4)  return(6);  /*7) cas PQ et QP*/

  else if (g1==g3 && g2!=g4 && g1!=g2)            return(7);  /*8) cas PQ et PR*/
  else if (g1==g4 && g1!=g3 && g1!=g2)            return(71);  /*9) cas PQ et RP*/    
  else if (g2==g3 && g2!=g4 && g1!=g2)            return(8);  /*10) cas QP et PR*/
  else if (g2==g4 && g1!=g3 && g1!=g2)            return(81);  /*11) cas QP et RP*/    

  else if (g1!=g2 && g3!=g4 && g1!=g3)            return(9);  /*12) cas PQ et RS*/

  else if (g1==g2 && g3!=g4 && g1!=g3)            return(10);  /*13) cas PP et RS*/
  else if (g1!=g2 && g3==g4 && g1!=g3)            return(11);  /*14) cas RS et PP*/

  else if (g1==g2 && g3==g4 && g1!=g3)            return(12);  /*15) cas RR et PP*/       
}


double unrel_hsfs_sp(gset, pallys, pallyp, sp1, sp2)
     double *pallys, *pallyp; 
     int *gset, sp1, sp2;
     /*vraisemblance de deux individus non apparent�s, selon esp�ce*/
     
{
  double pS, pS1, pS2, pS3, pP, pP1, pP2, pP3; 
  int g1, g2, g3, g4, ic;
  ic=0;
  g1=gset[1]; g2=gset[2]; g3=gset[3]; g4=gset[4]; /*all�les ind 1 /ind 2 */
  pS=pallys[1]; pS1=pallys[2]; pS2=pallys[3]; pS3=pallys[4]; /* fr�quences all�liques species 1 (sessile) */
  pP=pallyp[1]; pP1=pallyp[2]; pP2=pallyp[3]; pP3=pallyp[4]; /* fr�quences all�liques species 2 (p�doncul�s) */
  ic = genopair_hsfs_sp (g1, g2, g3, g4); /* ic est la relation entre les all�les individu 1/ind 2 id ou dif*/

  if (ic==1 && sp1==1 && sp2==1)  return(pS*pS*pS*pS);
  if (ic==1 && sp1==2 && sp2==2)  return(pP*pP*pP*pP);
  if (ic==1 && ((sp1==1 && sp2==2) || (sp1==2 && sp2==1)))  return(pS*pS*pP*pP);

  else if (ic==2 && sp1==1 && sp2==1 )  return (pS*pS*2*pS*pS3);
  else if (ic==2 && sp1==2 && sp2==2 )  return (pP*pP*2*pP*pP3);
  else if (ic==2 && sp1==1 && sp2==2 )  return (pS*pS*2*pP*pP3);
  else if (ic==2 && sp1==2 && sp2==1 )  return (pP*pP*2*pS*pS3);

  else if (ic==3 && sp1==1 && sp2==1 )  return (pS*pS*2*pS*pS2);
  else if (ic==3 && sp1==2 && sp2==2 )  return (pP*pP*2*pP*pP2);
  else if (ic==3 && sp1==1 && sp2==2 )  return (pS*pS*2*pP*pP2);
  else if (ic==3 && sp1==2 && sp2==1 )  return (pP*pP*2*pS*pS2);

  else if (ic==4 && sp1==1 && sp2==1 )  return (pS*pS*2*pS*pS1);
  else if (ic==4 && sp1==2 && sp2==2 )  return (pP*pP*2*pP*pP1);
  else if (ic==4 && sp1==1 && sp2==2 )  return (2*pS*pS1*pP*pP);
  else if (ic==4 && sp1==2 && sp2==1 )  return (2*pP*pP1*pS*pS);

  else if (ic==5 && sp1==1 && sp2==1 )  return (pS1*pS1*2*pS*pS1);
  else if (ic==5 && sp1==2 && sp2==2 )  return (pP1*pP1*2*pP*pP1);
  else if (ic==5 && sp1==1 && sp2==2 )  return (2*pS*pS1*pP1*pP1);
  else if (ic==5 && sp1==2 && sp2==1 )  return (2*pP*pP1*pS1*pS1);

  else if (ic==6 && sp1==1 && sp2==1 )  return (2*pS*pS1*2*pS*pS1);
  else if (ic==6 && sp1==2 && sp2==2 )  return (2*pP*pP1*2*pP*pP1);
  else if (ic==6 && sp1==1 && sp2==2 )  return (2*pS*pS1*2*pP*pP1);
  else if (ic==6 && sp1==2 && sp2==1 )  return (2*pP*pP1*2*pS*pS1);

  else if (ic==7 && sp1==1 && sp2==1 )  return (2*pS*pS1*2*pS*pS3);
  else if (ic==7 && sp1==2 && sp2==2 )  return (2*pP*pP1*2*pP*pP3);
  else if (ic==7 && sp1==1 && sp2==2 )  return (2*pS*pS1*2*pP*pP3);
  else if (ic==7 && sp1==2 && sp2==1 )  return (2*pP*pP1*2*pS*pS3);

  else if (ic==71 && sp1==1 && sp2==1 )  return (2*pS*pS1*2*pS*pS2);
  else if (ic==71 && sp1==2 && sp2==2 )  return (2*pP*pP1*2*pP*pP2);
  else if (ic==71 && sp1==1 && sp2==2 )  return (2*pS*pS1*2*pP*pP2);
  else if (ic==71 && sp1==2 && sp2==1 )  return (2*pP*pP1*2*pS*pS2);

  else if (ic==8 && sp1==1 && sp2==1 )  return (2*pS*pS1*2*pS1*pS3);
  else if (ic==8 && sp1==2 && sp2==2 )  return (2*pP*pP1*2*pP1*pP3);
  else if (ic==8 && sp1==1 && sp2==2 )  return (2*pS*pS1*2*pP1*pP3);
  else if (ic==8 && sp1==2 && sp2==1 )  return (2*pP*pP1*2*pS1*pS3);

  else if (ic==81 && sp1==1 && sp2==1 )  return (2*pS*pS1*2*pS1*pS2);
  else if (ic==81 && sp1==2 && sp2==2 )  return (2*pP*pP1*2*pP1*pP2);
  else if (ic==81 && sp1==1 && sp2==2 )  return (2*pS*pS1*2*pP1*pP2);
  else if (ic==81 && sp1==2 && sp2==1 )  return (2*pP*pP1*2*pS1*pS2);

  else if (ic==9 && sp1==1 && sp2==1 )  return (2*pS*pS1*2*pS2*pS3);
  else if (ic==9 && sp1==2 && sp2==2 )  return (2*pP*pP1*2*pP2*pP3);
  else if (ic==9 && sp1==1 && sp2==2 )  return (2*pS*pS1*2*pP2*pP3);
  else if (ic==9 && sp1==2 && sp2==1 )  return (2*pP*pP1*2*pS2*pS3);

  else if (ic==10 && sp1==1 && sp2==1 )  return (pS*pS*2*pS2*pS3);
  else if (ic==10 && sp1==2 && sp2==2 )  return (pP*pP*2*pP2*pP3);
  else if (ic==10 && sp1==1 && sp2==2 )  return (pS*pS*2*pP2*pP3);
  else if (ic==10 && sp1==2 && sp2==1 )  return (pP*pP*2*pS2*pS3);

  else if (ic==11 && sp1==1 && sp2==1 )  return (2*pS*pS1*pS2*pS2);
  else if (ic==11 && sp1==2 && sp2==2 )  return (2*pP*pP1*pP2*pP2);
  else if (ic==11 && sp1==1 && sp2==2 )  return (2*pS*pS*pP2*pP2);
  else if (ic==11 && sp1==2 && sp2==1 )  return (2*pP*pP*pS2*pS2);

  else if (ic==12 && sp1==1 && sp2==1 )  return (pS*pS*pS2*pS2);
  else if (ic==12 && sp1==2 && sp2==2 )  return (pP*pP*pP2*pP2);
  else if (ic==12 && sp1==1 && sp2==2 )  return (pS*pS*pP2*pP2);
  else if (ic==12 && sp1==2 && sp2==1 )  return (pP*pP*pS2*pS2);
}

double half_sib_sp (gk, gp, nl, pfs, pfp, sp1, sp2, S, s, p)  
     Geno *gk, *gp;
     int nl, sp1, sp2;
     double **pfs, **pfp, S, s, p;
     /* lod score demi-fr�re  */
{ 
  int i, j, gset[5]; 
  double pallys[5], pallyp[5], qp, pu, phs; 
  qp=0; pu=0; phs=0;
  for (i=1; i<=nl ; ++i)
    {  
      if (gk[i].g1 !=(-5) && gk[i].g2 !=(-5) && gp[i].g1 !=(-5) && gp[i].g2 !=(-5))
	{ 
	  gset[1] = gk[i].g1; gset[2] = gk[i].g2; /*nom des all du parent gk au locus i*/
	  gset[3] = gp[i].g1; gset[4] = gp[i].g2; /*nom des all du parent gp locus i*/
	  for (j=1; j< 5; ++j) pallys[j]= pfs[i][gset[j]]; /*range dans le tableau pally...*/ 
	  for (j=1; j< 5; ++j) pallyp[j]= pfp[i][gset[j]]; /*...les fr�q des 4 all�les*/
	  
	  phs = vsb_hs_sp(gset, pallys, pallyp, S, s, p);                 
	  pu = unrel_hsfs_sp (gset, pallys, pallyp, sp1, sp2);
	  qp += log(phs)-log(pu) ; 
	}	
    }
  return(qp);
}

double full_sib_sp (gk, gp, nl, pfs, pfp, sp1, sp2, S, s, p)  
     Geno *gk, *gp;
     int nl, sp1, sp2;
     double **pfs, **pfp, S, s, p;
     /* lod score plein-fr�re  */
{ 
  int i, j, gset[5]; 
  double pallys[5], pallyp[5], qp, pu, phs; 
  qp=0; pu=0; phs=0;
  for (i=1; i<=nl ; ++i)
    {  
      if (gk[i].g1 !=(-5) && gk[i].g2 !=(-5) && gp[i].g1 !=(-5) && gp[i].g2 !=(-5))
	{ 
	  gset[1] = gk[i].g1; gset[2] = gk[i].g2; /*nom des all du parent gk au locus i*/
	  gset[3] = gp[i].g1; gset[4] = gp[i].g2; /*nom des all du parent gp locus i*/
	  for (j=1; j< 5; ++j) pallys[j]= pfs[i][gset[j]]; /*range dans le tableau pally...*/ 
	  for (j=1; j< 5; ++j) pallyp[j]= pfp[i][gset[j]]; /*...les fr�q des 4 all�les*/
	  
	  phs = vsb_fs_sp(gset, pallys, pallyp, S, s, p);                 
	  pu = unrel_hsfs_sp (gset, pallys, pallyp, sp1, sp2);
	  qp += log(phs)-log(pu) ; 
	}	
    }
  return(qp);
}

     

