#include <math.h>
#include <stdio.h>
/* #include <time.h> */  /* pour initialiser le g�n�rateur de nombres al�atoires*/
#include <sys/time.h>
#include <unistd.h>
#include <stdlib.h>     
#include "nrutil.h"
#include "read.h"
#include "sort.h"
#include "alea.h"
#include "genetic.h"
#include "likely.h"

/**************************************************************************

Program to tabulate possible parent pairs, and log-likelihoods, for given
sets of juveniles, potential fathers, and potential mothers.
Ordered to find best 4 mums, best 4 dads, best 4 pairs.
Includes possibility of X-linked loci.

Modified from earlier programs; July 1996

Programme modifi� pour consid�rer des hermaphrodites, et int�grer possibles 
autof�condations 25/11/98

*** Pourcentage d'erreur ajout� dans les calculs 26/11/98
(inspir� de Marshall et al 1998)
utilis� en lan�ant le programme suivi de < fichier
le fichier contient 
nb_loc nb_all_loc1  freq_all1_loc1 freq_all2_loc2.... nb_all_loc2  etc...
nb_parents nb_desc-�-simuler
num�ro_parent1 all1_loc1 all2_loc1 etc... 
le fichier likh est un fichier d'exemple pour ce programme
Donne les 8 meilleurs parents et couples dans l'ordre.
Modifi� le 18/12/98 pour prendre les log 
de la vraisemblance

Fait des simulations :
cr�e des descendants intra parcelle, stocke en m�moire les vrais parents :
- meilleurs 2 parents d'apr�s les vraisemblances
- meilleur couple
Stocke les vraisemblance : 
Vraisemblances des parents choisis avec une bonne d�cision : fichier Parbd
                                            mauvaise                 Parmd
Vraisemblances des couples choisis avec une bonne d�cision : fichier Coupbd
                                            mauvaise                 Coupmd
Fr�quences de bonnes d�cisions.

28/7/99
Ajout de l'�limination des calculs des donn�es manquantes

25/11/99
A single file for both bad and good decisions (parent and couples). 
Good or bad decisions are just counted and gven at the end

8/2000 adapt� pour le programme g�n�ral tcltk : malloc partout
10/2001 associer le inside et outside stand in the same prog !
***************************************************************************/


extern double rans();
extern double log();


main (int argc, char *argv[])
{  
  char *name1, *name2, *name3, *name4, *name5, *name6 ;
  int nloc,*nall, cyt, *nallc, cytmater, miss;          /* number of alleles*/
  double **pf, **pfc, **fcum, **fcumc;	         /* loci details; prior freqs; fr�quences cumul�es */
  int nkid,nkid1,npar;			 /*number of kids, parents */
  int  *name_kid, *name_par, **parcyt, **kidcyt;            /* individual names etc. */
  Geno **kidgen, **pargen; 	/* genotypic data */
  Geno *kidpar;                        /* nom des vrais parents du descendant*/
  int **dadgam, **mumgam;      /* Gam�tes paternel et paternel*/
  int i,j,k,ii,jj, kk,iii, jjj, tp1,tp2, mum, dad, io; 
  int npop, *listp, npopp, bdc, mdc, bdp, mdp, bp, bc1, bc2;
  double  best_dads[10],  best_pars[10], best_pairs[2][10];
  double score[10], pcore[10], cc, bc, pc, E, Es, F, f, bdcf, bdpf;
  double *bestp1, *bestp2, *bestp, *bestc, x, y;
  double *deltatrue, *deltawrong, *deltawrongi, *deltawrongo1,*deltawrongo2 , deltamax, delta1, delta2;
  double *deltatrueC, *deltawrongC, *deltawrongiC, *deltawrongo1C,*deltawrongo2C;


  FILE *n, *n1, *g, *g1, *nn, *nn1, *mm, *mm1; 


  /* the previous  two lines are for creating an histogram of best parents and couple of simulated offspring */
  
  /* initialisation du g�n�rateur de nombres al�atoires :*/
  long m;
  float rand;
  struct timeval temps; 
  struct timezone  zone;
  gettimeofday(&temps,&zone);
  m=-temps.tv_usec; 
  rand=ran3(&m);
  
  /* Reading arguments */
  nkid=atoi(argv[1]);
  E=atof(argv[2]); 
  Es=atof(argv[3]);
  cyt=atoi(argv[4]);
  cytmater=atoi(argv[5]);
  io=atoi(argv[6]);
  /* if io==1 pick gametes among genotyped individuals, if io==2, pick gametes randomly according to allele frequencies */
  F=atof(argv[7]); 
  miss=atoi(argv[8]);

  name1 = "Single parent";
  name2 = "Parent pair";
  name3 = "Delta, true parents";
  name4 = "Delta, true parent pairs";
  name5 = "Delta, wrong parents";
  name6 = "Delta, wrong parent pairs";
 
  /* Lecture des donn�es locus */
  scanf ("%d", &nloc);
  nall=(int *)malloc((nloc-cyt+1)*sizeof(int));
  if (cyt > 0) nallc=(int *)malloc((cyt+1)*sizeof(int));
  read_loci_cum (nloc, nall, &pf, &fcum, cyt, nallc, &pfc, &fcumc);
  printf("\n Number of loci: %d",nloc);
  printf("\n Of which %d cytoplasmic markers",cyt);
  scanf ("%d %d", &npar, &nkid1);
  printf ("\n Number of parents: %d number of simulated offspring: %d\n", npar, nkid);

  if (io==1) printf("\n***** Simulating offpring with genotyped parents *****\n");
  if (io==2) printf("\n***** Simulating offpring according to allele frequencies *****\n");

  if (io==1) printf("\n Simulation error %f", Es);    
  printf("\n Lod calculation error %f, Heterozygote deficit %f\n", E, F);    
/*   printf("\n (The simulated delta values (2nd_most_likely_lod - 1st_most_likely_lod) are in files delta.parent/couple.in/out)");  */
  listp=(int *)malloc((npar+1)*sizeof(int));
  name_kid=(int *)malloc((nkid+1)*sizeof(int));
  name_par=(int *)malloc((npar+1)*sizeof(int));
  kidgen=(Geno **)malloc((nkid+1) * sizeof(Geno *));
  kidpar=(Geno *)malloc((nkid+1) * sizeof(Geno));
  pargen=(Geno **)malloc((npar+1) * sizeof(Geno *));
  kidcyt=(int **)malloc((nkid+1) * sizeof(int *));
  parcyt=(int **)malloc((npar+1) * sizeof(int *));
  if (io==1)  
    {
      mumgam=(int **)malloc((npar+1) * sizeof(int *));
      dadgam=(int **)malloc((npar+1) * sizeof(int *));
      for (i=1; i<=npar; i++) 
	{
	  mumgam[i]=(int *)malloc((nloc+1) * sizeof(int));
	  dadgam[i]=(int *)malloc((nloc+1) * sizeof(int));
	}
    }
  else if (io==2)  
    {
      mumgam=(int **)malloc((nkid+1) * sizeof(int *));
      dadgam=(int **)malloc((nkid+1) * sizeof(int *));
      for (i=1; i<=nkid; i++) 
	{
	  mumgam[i]=(int *)malloc((nloc+1) * sizeof(int));
	  dadgam[i]=(int *)malloc((nloc+1) * sizeof(int));
	}
    }
  
  for (i=1; i<=nkid; i++) 
    {
      kidgen[i]=(Geno *)malloc((nloc-cyt+1) * sizeof(Geno));
      kidcyt[i]=(int *)malloc((cyt+1) * sizeof(int));
    }
  for (i=1; i<=npar; i++)  
    {
      pargen[i]=(Geno *)malloc((nloc-cyt+1) * sizeof(Geno)); 
      parcyt[i]=(int *)malloc((cyt+1) * sizeof(int));
    }
  read_gen_dat_par(npar, name_par, pargen, parcyt, nloc, cyt);
  
  
  /*initialisations*/
  bdc=0; mdc=0;   bdp=0; mdp=0; iii=1; jjj=1; 
  
  /* Cr�ation de descendants*/
  printf("\n Simulation step");
  if(io==1)
    {
      for (ii=1;ii<=nkid;++ii)
	{
	  name_kid[ii]=ii;
	  mum = 1+(int)(npar*alea()) ;         /* Tirage al�atoire des deux parents : */
	  f=alea();
	  if (f<=2*F/(1+F)) dad=mum;         /*selfing at equilibrium = [2*F/(1+F)] */
	  else dad = 1+(int)(npar*alea()) ;         /* nombre entier al�atoire dans [1,npar] */ 
	  gamete(pargen[mum],mumgam[mum], nloc, nall, Es, cyt, nallc, parcyt[mum]); /* Simulation des gam�tes parentaux : */ 
	  gamete(pargen[dad],dadgam[dad], nloc, nall, Es, cyt, nallc, parcyt[dad]);
	  kidpar[ii].g1=name_par[mum]; 
	  kidpar[ii].g2=name_par[dad];  
	  for (jj=1;jj<=nloc-cyt;++jj)
	    {
	      kidgen[ii][jj].g1=mumgam[mum][jj];  /* ii :enfant, jj locus*/
	      kidgen[ii][jj].g2=dadgam[dad][jj];   
	    }  
	  if  (cyt > 0)	    
	    {
	      if (cytmater==1) for (jj=nloc-cyt+1;jj<=nloc;++jj)  kidcyt[ii][jj-nloc+cyt] = mumgam[mum][jj];  
	      else if (cytmater==0) for (jj=nloc-cyt+1;jj<=nloc;++jj)  kidcyt[ii][jj-nloc+cyt] = dadgam[dad][jj];  
	    } 
	  /* printf("\nkid %d", ii); */
	  /* print_geno_cyt (kidgen[ii], kidcyt[ii], nloc, cyt); */
	  /* printf("\nmum %d", mum); */
	  /* print_geno_cyt (pargen[mum], parcyt[mum], nloc, cyt); */
	  /* printf("\ndad %d", dad); */
	  /* print_geno_cyt (pargen[dad], parcyt[dad], nloc, cyt); */
	}
    }
  
  else if (io==2)
    {
      for (ii=1;ii<=nkid;++ii)
	{
	  name_kid[ii]=ii; 
	  gamete_hp(mumgam[ii], nloc, nall, fcum, cyt, nallc, fcumc); /* Simulation des gam�tes parentaux : */ 
	  gamete_hp(dadgam[ii], nloc, nall, fcum, cyt, nallc, fcumc);   
	  for (jj=1;jj<=nloc-cyt;++jj)
	    {
	      kidgen[ii][jj].g1=mumgam[ii][jj];  /* ii :enfant, jj locus*/
	      f=alea();
	      if(f<=F) kidgen[ii][jj].g2=mumgam[ii][jj];
	      else kidgen[ii][jj].g2=dadgam[ii][jj];     
	    }
	  if  (cyt > 0)        
	    {
	      if (cytmater==1) for (jj=nloc-cyt+1;jj<=nloc;++jj)  kidcyt[ii][jj-nloc+cyt] = mumgam[ii][jj];             
	      else if (cytmater==0) for (jj=nloc-cyt+1;jj<=nloc;++jj)  kidcyt[ii][jj-nloc+cyt] = dadgam[ii][jj];  
	    }
	}
    }
  printf("\n End of simulation step \n");

  if (io==1)  
    { 
      n = fopen ("deltaparent.gd.in", "w");  g = fopen ("deltapair.gd.in", "w");  
      n1 = fopen ("deltaparent.bd.in", "w");  g1 = fopen ("deltapair.bd.in", "w");  
      nn = fopen ("parent.gd.in", "w");  nn1 = fopen ("parent.bd.in", "w"); 
      mm = fopen ("pair.gd.in", "w");  mm1 = fopen ("pair.bd.in", "w"); 
    } 
  else if (io==2)  
    { 
      n = fopen ("deltaparent.gd.out", "w");    g = fopen ("deltapair.gd.out", "w");  
      n1 = fopen ("deltaparent.bd.out", "w");    g1 = fopen ("deltapair.bd.out", "w");  
      nn = fopen ("parent.gd.out", "w");  nn1 = fopen ("parent.bd.out", "w"); 
      mm = fopen ("pair.gd.out", "w");  mm1 = fopen ("pair.bd.out", "w"); 
    } 
  
  printf("\n Calculation step");	
  
  /* 	First allocate memory to store data: draw a histogram later thanks to them */
  
  bestp1=(double *)malloc((nkid+1)*sizeof(double));
  bestp2=(double *)malloc((nkid+1)*sizeof(double));
  bestp=(double *)malloc((2*nkid+1)*sizeof(double));
  bestc=(double *)malloc((nkid+1)*sizeof(double));	
  deltatrue=(double *)malloc((2*nkid+1)*sizeof(double));
  deltawrongi=(double *)malloc((2*nkid+1)*sizeof(double));
  deltawrongo1=(double *)malloc((nkid+1)*sizeof(double));
  deltawrongo2=(double *)malloc((nkid+1)*sizeof(double));
  deltawrong=(double *)malloc((4*nkid+1)*sizeof(double));
  deltatrueC=(double *)malloc((2*nkid+1)*sizeof(double));
  deltawrongiC=(double *)malloc((2*nkid+1)*sizeof(double));
  deltawrongo1C=(double *)malloc((nkid+1)*sizeof(double));
  deltawrongo2C=(double *)malloc((nkid+1)*sizeof(double));
  deltawrongC=(double *)malloc((4*nkid+1)*sizeof(double));
  
  for (i=1; i<=(nkid); i++)       {bestp1[i]=0.0; bestp2[i]=0.0; bestc[i]=0.0;}
  for (i=1; i<=(2*nkid); i++)	    bestp[i]=0.0;
  
  for (i=1; i<=nkid; ++i)
    {
      /*       printf ("\t%5d\t", name_kid[i]); printf ("\b\b\b\b\b\b\b\b\b\b");     */
      
      npopp=0; npop=0;  bc=1.0E6; pc = 1.0E6; /* Number Possible Parent / Pairs */
      
      /* Calcul des vraisemblances des parents pour chaque descendant */
      
      for (k=1; k< 11; ++k) 
	{
	  score[k]=0.0; 
	  best_dads[k] =0; best_pars[k] =0; pcore[k]=0.0;
	  best_pairs[0][k]=0; best_pairs[1][k]=0;
	}
      for (j=1; j<=npar; ++j)
	{
	  cc = uparchk(nloc-cyt,*(kidgen+i),pargen[j],pf, E, F, nall, miss);  /* proba maternit�:non maternit�*/
	  if (cyt > 0) cc+=likr_cyt(cyt, kidcyt[i], parcyt[j], pfc, E, nallc);
	  if (cc > 0.0 && finite(cc)==1)
	    {
	      ++npop; listp[npop]=j; /*rang de tous les parents � proba > 0,npop observations*/
	      if (npop < 9) 
		{
		  best_pars[npop] = name_par[j]; 
		  score[npop]=cc; 
		  if (cc < bc)  bc = cc;
		} /* bc sera le score min parmi les 8 premiers >0 */
	      else
		{
		  if (cc > bc) /*score sup�rieur au min pr�c�dent*/
		    {
		      k = dexmin(score, 8); /* rang du score minimum parmi les 8*/
		      best_pars[k] = name_par[j];  /*on remplace la m�re k  ...  */
		      score[k] = cc;               /* par la j, qui est meilleure */ 
		      bc = valmin(score, 8);
		    }
		}  /*nouveau score min*/
	    } 
	}                                  /* � la fin on a les 8 meilleures des nmum*/
      
      /* Ins�rer un tri sur best_pars[k] et score[k], 1<=k<=8 */
      sort2(8,score,best_pars);
      
      /* Stocker les vraisemblances de bonne d�cision (bd) et mauvaise d�cision (md) pour les deux meilleurs parents*/

      /*printf("\nkid %d mum %d dad %d", i, kidpar[i].g1, kidpar[i].g2); */
      /*printf("\n"); */
      /*print_geno(kidgen[i], nloc); */
      deltamax=score[8];
      delta1=deltamax;
      if (score[7]>0) delta2=score[7]-deltamax; else delta2=0;
      if(io==1) { 
	if (best_pars[8]==kidpar[i].g1 || best_pars[8]==kidpar[i].g2) {deltatrue[iii]=delta1; iii+=1;} 
	else { deltawrongi[jjj]=delta1; jjj+=1;}
	if (best_pars[7]==kidpar[i].g1 || best_pars[7]==kidpar[i].g2) {deltatrue[iii]=delta2; iii+=1;}
	else deltawrongi[jjj]=delta2; jjj+=1;}
      if (io==2) { deltawrongo1[i]=delta1; deltawrongo2[i]=delta2; } 
      for (k=8;k>=7;--k) {	  
	  /*printf("\nk %d best_par %.0f score %.2f", k, best_pars[k], score[k]); */
	  bp=best_pars[k];
	  if (bp==kidpar[i].g1 || bp==kidpar[i].g2)   
	    {
	      if (score[k]>0.000000) ++bdp; /*the two best parents are the true one*/
 	      fprintf (n, " %f", score[8]-score[7]); 
 	      fprintf (nn, " %f", score[8]); 
	      
	    }  
	  else 
	    {
	      if (score[k]>0.000000) ++mdp; /*the two best parents are not the true one*/
 	      fprintf (n1, " %f", score[8]-score[7]); 
 	      fprintf (nn1, " %f", score[8]); 
	    }
	}
      k=8; bestp1[i]=score[k]  ; /* kid n�i has bestp1 and 2 as most likely parents */
      k=7; bestp2[i]=score[k]  ;

      /* 	    printf("\nscores des meilleurs parents\n"); */
      /*printf("%f\t%f\n", bestp1[i], bestp2[i]);    */
      
      
      /* Calcul des vraisemblances pour les meilleurs couples*/
      pc=1.0E6;
      for (k=1; k< 11; ++k)  score[k]=0.0; 
      for (j=1; j<=npop; ++j)
	{ 
	  tp1 = listp[j];
	  if (npop > 0)
	    {
	      for (kk=1; kk<=npop; ++kk)
		{
		  tp2 = listp[kk];
		  if (tp2>=tp1)
		    {
		      cc = pparchk(nloc-cyt, kidgen[i], pargen[tp1], pargen[tp2], pf, E, F, nall, miss);  /*dans boucle en j*/
		      if (cyt > 0) cc+=likr_pair_cyt(cyt, kidcyt[i],parcyt[tp1],parcyt[tp2], pfc, E, nallc);
		      if (cc > 0.0 && finite(cc)==1) 
			{
			  ++npopp; 
			  if (npopp < 9) 
			    {
			      best_pairs[0][npopp] = name_par[tp1]; 
			      best_pairs[1][npopp] = name_par[tp2]; 
			      pcore[npopp]=cc; 
			      if (cc < pc)  pc = cc; 
			      } 
			  else
			    {
			      if (cc > pc) 
				{
				  k = dexmin(pcore, 8);
				  best_pairs[0][k] = *(name_par+tp1); 
				  best_pairs[1][k] = *(name_par+tp2); 
				  pcore[k] = cc;
				  pc = valmin(pcore, 8); 
				}
			    }
			  
			}/* printf ("\n pc: %f \t",pc); */ 
		    }
		  }
	    }
	} 
      /* Tri*/
      
      sort3(8,pcore,best_pairs[0],best_pairs[1]);			
      
      /* Stocker les vraisemblances de bonne d�cision (bd) et mauvaise d�cision (md) pour le meilleur couple*/
	
      k=8;  
      deltamax=pcore[8];
      delta1= deltamax; /*delta of the first most likely parent pair*/
      if (pcore[7]>0) delta2= pcore[7]-deltamax; else delta2=0;/*delta of the second most likely parent pair*/
      if(io==1) { 
	if ((bc1==kidpar[i].g2 && bc2==kidpar[i].g2) || (bc2==kidpar[i].g1 && bc2==kidpar[i].g2)) deltatrueC[i]=delta1;
	else deltawrongiC[i]=delta1;
      }
      if (io==2) { deltawrongo1C[i]=delta1; deltawrongo2C[i]=delta2; } 

      bc1=best_pairs[0][k]; bc2=best_pairs[1][k];  
      if ((bc1==kidpar[i].g1 && bc2==kidpar[i].g2) || (bc1==kidpar[i].g2 && bc2==kidpar[i].g1)){
	if (pcore[k]>0.000000) ++bdc;
	fprintf (mm, " %f", pcore[8]);
	fprintf (g, " %f", pcore[8]-pcore[7]); 
      }  
      else {
	if (pcore[k]>0.000000) ++mdc; 
	fprintf (mm1, " %f", pcore[8]);	   
	fprintf (g1, " %f", pcore[8]-pcore[7]);	   
      }
      bestc[i]=pcore[k];
      

    }      /*  end loop in i (nkid) */
  
  printf("\n End of calculation step \n");
  if (io==1)
    {
      x=bdp;
      y=2*nkid;
      bdpf=100*x/y;
      x=bdc;
      y=nkid;
      bdcf=100*x/y;
      printf("\n The two most likely parents are the right parents %d times over 2*%d simulated offspring (%.2f %%)",bdp,nkid,bdpf); 
      printf("\n");
      printf("\n The most likely parent pair is the right parent pair in %d simulations (%.2f %%)",bdc,bdcf); 
    }      
  
  /* store in bestp the two most likely parents for each offspring   */
  
  for (i=1; i<=nkid; i++) *(bestp+i)=*(bestp1+i);
  for (i=nkid+1; i<=2*nkid; i++) *(bestp+i)=*(bestp2+(i-nkid)) ;
  hist1(bestp, 2*nkid, name1);
  hist1(bestc, nkid, name2);
  if (io==1) {
    hist1(deltatrue, (iii-1), name3);
    hist1(deltatrueC, 2*nkid, name4);
  }
  
  for (i=1; i<=2*nkid; ++i) deltawrong[i]=deltawrongi[i];
  for (i=1; i<=2*nkid; ++i) deltawrongC[i]=deltawrongiC[i];
  for (i=2*nkid+1; i<=3*nkid; ++i)  deltawrong[i]=deltawrongo1[i-2*nkid];
  for (i=3*nkid+1; i<=4*nkid; ++i)  deltawrong[i]=deltawrongo2[i-3*nkid];
  for (i=2*nkid+1; i<=3*nkid; ++i)  deltawrongC[i]=deltawrongo1C[i-2*nkid];
  for (i=3*nkid+1; i<=4*nkid; ++i)  deltawrongC[i]=deltawrongo2C[i-3*nkid];
  
  if (io==2) {
    hist1(deltawrong, 4*nkid, name5);
    hist1(deltawrongC, 4*nkid, name6);
  }
 
  printf("\n");
  
   fclose(n); 
   fclose(nn); 
   fclose(g); 
   fclose(n1); 
   fclose(nn1); 
   fclose(g1);
   fclose(mm);
   fclose(mm1); 

  return(0);
  
}     /*   end of main() */



