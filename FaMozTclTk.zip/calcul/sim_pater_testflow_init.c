/**************** Programme sim_pater_testflow.c ********************/


#include <math.h>
#include <stdio.h>
/* #include <time.h> */  /* pour initialiser le g�n�rateur de nombres al�atoires*/
#include <sys/time.h>
#include <unistd.h>
#include <stdlib.h>     
#include "nrutil.h"
#include "read.h"
#include "sort.h"
#include "alea.h"
#include "genetic.h"
#include "likely.h"

/***************************************************************************
24/2/99
Fait des simulations :
Cr�e des descendants avec zero un ou deux parents dans la parcelle, selon un tirage aleatoire
parmi les POP individus de la population de reproduction totale.
Fait un test pour decider si on a zero un ou deux parents dans la parcelle
montre le resultat

19/6/01
Simulation of a population
- applying a test
- recording correct decision
- recording different types of gene flow events
***************************************************************************/

extern double rans();


main (int argc, char *argv[])
{  
  int nloc, *nall, cyt, *nallc, cytmater, miss, test_type;         /* number of alleles */
  double **pf, **pfc, **fcum, **fcumc, E, Es, SEUIL_F, F, f, SEUIL_delta;	 /* loci details; prior freqs; fr�quences cumul�es */
  int nkid, nkid1, npar, nmo, simo;			 /* individual names etc. */
  int *name_kid, *name_par, *mo, mere, **parcyt, **kidcyt;
  Geno **kidgen, **pargen; 	/* genotypic data */
  Geno  *kidpar;                /* nom des vrais parents du descendant*/
  int **dadgam, **mumgam;       /* Gam�tes paternel et maternel tir�s au hasard dans la pop/hors parcelle*/
  int i,j,k,l,ii,jj, kk, mum, dad, pp, gf, agf, cgf; 
  int pop, npod, fazchoi;
  double  best_dads[10];
  double score[10], cc, bc, bch, total, pcbc;
  double agff, cgff, gff, popf, nparf, att;


  /* initialisation du g�n�rateur de nombres al�atoires :*/
  long m;
  float rand;
  struct timeval temps; 
  struct timezone  zone;
  gettimeofday(&temps,&zone);
  m=-temps.tv_usec; 
  rand=ran3(&m);
  
  /* Reading arguments */
  nmo=atoi(argv[1]);   /*  Number of mother */
  nkid=atoi(argv[2]);  /*  Number of kid per mother */
  pop=atoi(argv[3]); 
  SEUIL_F=atof(argv[4]);  /* Threshold to choose a father as the true one */
  Es=atof(argv[5]);      /* Simulation error */
  E=atof(argv[6]);     /* Lod calculation error */
  simo=atoi(argv[7]);   /* Pick mother in a random manner (simo=0) or determine mothers in a list */
  cyt=atoi(argv[8]);
  cytmater=atoi(argv[9]); /* Maternal heredity of cytoplasme : yes=1 */
  F=atof(argv[10]);
  miss=atoi(argv[11]); 
  test_type=atoi(argv[12]) /* test type 1: test on lod scores 2: test on delta 3: test on both values*/

  mo=(int *)malloc((nmo+1)*sizeof(int));
  
  if (simo > 0)
    {
      for (i=1; i<=nmo; i++) mo[i]=atoi(argv[11+i]);
      printf("\n The %d mothers are the following: \n", nmo);
      for (i=1; i<=nmo; i++) 	printf("\t %d ", mo[i]);
    }
  
  
  else printf("\n The %d mothers will be selected at random", nmo);
  
  /*Initialisations*/ 
  bch=0.0; total=0.0; pcbc=0.0; pp=0.0;
  gf=0; cgf=0; agf=0;
  
  /* Lecture des donn�es locus */
  scanf ("%d", &nloc);
  nall=(int *)malloc((nloc-cyt+1)*sizeof(int));
  if (cyt > 0) nallc=(int *)malloc((cyt+1)*sizeof(int));

  read_loci_cum (nloc, nall, &pf, &fcum, cyt, nallc, &pfc, &fcumc);

  printf("\n Number of loci: %d",nloc);
  scanf ("%d %d", &npar, &nkid1);
  printf ("\n Number of genotyped parents: %d \n Size of the total reproducing population: %d", npar, pop);
  printf ("\n Number of mother: %d, number of simulated offspring per mother: %d", nmo, nkid);
  printf("\n Simulation error %f, Lod calculation error %f, Heterozygote deficit %f", Es, E, F);    
  printf("\n Test threshold to choose a father as the true one= %.2f ", SEUIL_F);
  
  l=nmo*nkid;

  name_kid=(int *)malloc((l+1)*sizeof(int));
  kidgen=(Geno **)malloc((l+1) * sizeof(Geno *));
  pargen=(Geno **)malloc((npar+1) * sizeof(Geno *));
  kidpar=(Geno *)malloc((l+1) * sizeof(Geno));
  name_par=(int *)malloc((pop+1)*sizeof(int));
  dadgam=(int **)malloc((pop+1) * sizeof(int *));
  mumgam=(int **)malloc((npar+1) * sizeof(int *));
  parcyt=(int **)malloc((pop+1) * sizeof(int *));
  kidcyt=(int **)malloc((l+1) * sizeof(int *));
  
  for (i=1; i<=l; i++) 
    {
      kidgen[i]=(Geno *)malloc((nloc-cyt+1) * sizeof(Geno));
      kidcyt[i]=(int *)malloc((cyt+1) * sizeof(int));
    }
  for (i=1; i<=npar; i++)  
    {
      pargen[i]=(Geno *)malloc((nloc-cyt+1) * sizeof(Geno));  
      mumgam[i]=(int *)malloc((nloc+1) * sizeof(int));
    }
  for (i=1; i<=pop; i++) 
    {
      dadgam[i]=(int *)malloc((nloc+1) * sizeof(int));      
      parcyt[i]=(int *)malloc((cyt+1) * sizeof(int));
    }
    
  read_gen_dat_par(npar, name_par, pargen, parcyt, nloc, cyt); 
  for (i=npar+1; i<=pop; ++i ) name_par[i]=-5;    
  
  /* Cr�ation de descendants*/
  for (ii=1;ii<=nmo;++ii)
    { 
      k=0;
      if (simo > 0) /* Choose mothers in a list given by user */
	{
	  for (i=1;i<=npar;++i)	      
	    {
	      if ( mo[ii]==name_par[i]) 
		{
		  mum=i; 
		  k+=1;
		}
	    }
	  if (k==0) printf("\n Mother %d is not part of your genotyped individuals\n", mo[ii]);
	}
      else 
	{
	  mum = 1+(int)(npar*alea()) ;   /* Determine mother at random  */
	  mo[ii]=name_par[mum];
	}
      for (jj=(1+(ii-1)*nkid);jj<=(nkid+(ii-1)*nkid);++jj)
	{ 
	  name_kid[jj]=jj;
	  gamete(pargen[mum], mumgam[mum], nloc, nall, Es, cyt, nallc, parcyt[mum]);
	  f=alea();
	  if (f<=2*F/(1+F)) dad=mum;         /*selfing at equilibrium = [2*F/(1+F)] */
	  else dad = 1+(int)(pop*alea()) ; 
	  if (dad > npar) gamete_hp(dadgam[dad], nloc, nall, fcum, cyt, nallc, fcumc);  
	  else if (dad <= npar) gamete(pargen[dad],dadgam[dad],nloc, nall, Es, cyt, nallc, parcyt[dad]);
	  kidpar[jj].g1=mo[ii];
	  kidpar[jj].g2=name_par[dad];   /* Nom du p�re (=-5 si hors parcelle) */ 
	  for (kk=1;kk<=nloc-cyt;++kk)
	    {
	      kidgen[jj][kk].g1=mumgam[mum][kk];  /* jj :enfant, kk locus*/
	      kidgen[jj][kk].g2=dadgam[dad][kk];   
	    }  
	  if  (cyt > 0) 
	    {
	      if (cytmater==1) for (kk=nloc-cyt+1;kk<=nloc;++kk)  kidcyt[jj][kk-nloc+cyt] = mumgam[mum][kk];  
	      else if (cytmater==0) for (kk=nloc-cyt+1;kk<=nloc;++kk)  kidcyt[jj][kk-nloc+cyt] = dadgam[dad][kk];  
	    } 
	}
    }	  
  
  
  /* Looking for most likely fathers */
  for (i=1; i<=nkid*nmo; ++i)
    {	   
      /* 	printf ("\t%5d\t", name_kid[i]); printf ("\b\b\b\b\b\b\b\b\b\b");   */
      /*   printf ("\n Descendant %d : parent 1 = %d  parent 2 = %d \n", name_kid[i], kidpar[i].g1, kidpar[i].g2)*/
      /*          printf (" g�notype du descendant\n"); */
      /*          print_geno(kidgen[i]);      */
      /*          printf (" g�notypes of parents\n"); */
      /*          for (k=1;k<=npar;++k) {if (name_par[k]==kidpar[i].g1)  print_geno(pargen[k]);}      */
      /*          for (k=1;k<=npar;++k) {if (name_par[k]==kidpar[i].g2)  print_geno(pargen[k]);}    */
      /*        printf ("\n kid %d :", name_kid[i] ); */
      npod=0; bc=1.0E6;
      for (k=0; k< 10; ++k)
	{
	  best_dads[k] =0; 
	  score[k]=0.0;
	}
      
      for (j=1; j<=npar; ++j)
	{  
	  for (ii=1;ii<=npar;++ii) 
	    {
	      if (kidpar[i].g1==name_par[ii]) 
		mere=ii;
	    }
	  cc = pater(kidgen[i], pargen[mere], pargen[j], nloc-cyt, pf, E, F, nall, miss);
	  if (cyt > 0 && cytmater==0) cc+=likr_cyt(cyt, kidcyt[i], parcyt[j], pfc, E, nallc);
	  /* 	     printf("\n nom p�re : %d",name_par[j]);   */
	  /* 	     printf("\n enfant : %d et g�notype\n", name_kid[i]);    */
	  /* 	     print_geno(kidgen[i], nloc-cyt);   */
	  /* 	     printf("\nmere %d m�re : %d\n",mere, name_par[mere]);    */
	  /* 	     print_geno(pargen[mere], nloc-cyt); */
	  /* 	     printf("\n p�re possible : %d\n",name_par[j]);    */
	  /* 	     print_geno(pargen[j], nloc-cyt);   */
	  if (cc > 0.0) 
	    { 
	      ++npod;
	      if (npod < 9) 
		{
		  best_dads[npod] = name_par[j]; 
		  score[npod]=cc; 
		  if (cc < bc)  bc = cc; 
		} 
	      else
		{
		  if (cc > bc) 
		    {
		      k = dexmin(score, 8);
		      best_dads[k] = name_par[j];
		      score[k] = cc;
		      bc = valmin(score, 8); 
		    }
		}
	    }
	}
      sort2(8,score,best_dads);			
      
      /* Stocker les vraisemblances de bonne d�cision (bd) et mauvaise d�cision (md) pour les deux meilleurs parents*/
      
      /*                   for (k=8;k>=7;--k) */
      /*                   {if (best_pars[k]==kidpar[i].g1)  */
      /*                          {if ( f != NULL && score[k]>0.000000) fprintf (f, " %f ",score[k]);} */
      /* 		   else  {if (fp != NULL && score[k]>0.000000) fprintf (fp, " %f ",score[k]);} */
      /* 		  } */
      
      
      /* Affichage avec le test*/
      k=8;
      if (test_type==1)
	{
	  if (score[k] > SEUIL_F) fazchoi = best_dads[k];
	  else fazchoi = -5;
	  if (fazchoi == kidpar[i].g2) ++pp;
	}
       else if (test_type==2)
	{
	  if (score[k]-score[k-1] > SEUIL_delta) fazchoi = best_dads[k];
	  else fazchoi = -5;
	  if (fazchoi == kidpar[i].g2) ++pp;
	}
       else if (test_type==3)
	{
	  if (score[k] > SEUIL_F && score[k]-score[k-1] > SEUIL_delta) fazchoi = best_dads[k];
	  else fazchoi = -5;
	  if (fazchoi == kidpar[i].g2) ++pp;
	}

      
      /* Calcul des flux de g�nes (gf) apparents (agf), cach� (cgf)*/
      
      if (kidpar[i].g2 ==-5) ++gf;
      if (fazchoi == -5) ++agf;
      if (fazchoi != -5 && kidpar[i].g2 == (-5)) ++cgf;
    }    
  
  fflush(stdout);
  printf ("\n");
  bch=pp;
  total=nkid*nmo;
  pcbc=(bch/total)*100;
  printf("\n\n*** Results ***\n\n");
  printf("\n Percentage of correct father choice = \t%8.2f \n",pcbc);
  
  printf("\n");
  agff=agf;
  cgff=cgf;
  nparf=npar;
  popf=pop;
  att=((popf-nparf)/popf)*total;
  gff=gf;

  printf(" Number of paternity correctly assigned \t%8.0f \n",(bch-gff+cgf));  
  printf(" Percentage of paternity correctly assigned \n");
  printf("         among the assigned paternity = \t%8.2f \n\n",100*(bch-gff+cgf)/(total-agff));  

  printf(" On a total of %.0f gametes produced: \n",2*total);
  printf(" - expected* gene flow =  \t%10.0f\n", att);
  printf(" - true** gene flow =    \t%10d \n", gf);
  printf(" - apparent� gene flow =  \t%10d \n", agf);
  printf(" - cryptic�� gene flow =  \t%10d \n", cgf);
  printf("\n Percentages: \n - true/apparent = \t%10.2f \n - cryptic/apparent = \t%10.2f", (gff/agff)*100,(cgff/agff*100));
  
  printf("\n\n* [(Total reproducing population size - number of genotyped parent)/ Total reproducing population size]");
  printf("\n\t\t  * number of simulated gametes");
  printf("\n** Actual number of times a parent different from the genotyped parents produced one of the offspring.");
  printf("\n� Number of times no genotyped parent was detected for the simulated offspring,\n  according to the statistical tests.");
  printf("\n�� Number of times a parent had been detected among the genotyped parent\n ");
  printf("according to the statistical tests whereas the true parent was not part of them.");
  printf("\n");
  
  return(0);
  
}

