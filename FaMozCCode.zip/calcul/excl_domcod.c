
#include <math.h>
#include <stdio.h>
#include "nrutil.h"
#include "sort.h"
#include "read.h"

/**************************************************************************

  09/01
  Exclusion probabilities for codominant && dominant markers (and cyto too)

***************************************************************************/

main (int argc, char *argv[])
{   
  int i,j, nloc, nlocd, cyt, *nall, *nallc; 
  double pair, pater, *paircum, *patcum, *paircumd, *patcumd;
  double p, **pf, *pfd, **pfc, patcu, paircu, procyt, cumcyt, pairprocyt, paircumcyt;
  double *probex[4],*probexd[3], pp, a2, a3, a4, a5, a6, unseulpar, couple, pcum, uncum, coucum;               
  /*this array will contain the locus n� in [0] and the 2 or 3 exclusion probabilities */
  
  cyt=atoi(argv[1]);

  scanf ("%d", &nloc);
  nall=(int *)malloc((nloc+1)*sizeof(int));
  if (cyt > 0) nallc=(int *)malloc((cyt+1)*sizeof(int));
  read_loci (nloc, nall, &pf, cyt, nallc, &pfc); 
  scanf ("%d", &nlocd);
  pfd=(double *)malloc((nlocd+1) * sizeof(double));
  read_loci_dom (nlocd, 0, nallc, pfd, &pfc);


  paircum=(double *)malloc((nloc-cyt+1) * sizeof(double));
  patcum=(double *)malloc((nloc-cyt+1) * sizeof(double));
  paircumd=(double *)malloc((nlocd+1) * sizeof(double));
  patcumd=(double *)malloc((nlocd+1) * sizeof(double));
  for  (j=0; j<=3; ++j) probex[j] =(double *)malloc((nloc-cyt+1)*sizeof(double));
  for  (j=0; j<=2; ++j) probexd[j] =(double *)malloc((nlocd+1)*sizeof(double));

  printf("\n Number of codominant %d, dominant %d loci", nloc, nlocd);
  printf("\n Among codominant, cytoplasmic markers: %d \n",cyt);
  paircum[0] = 1.0; patcum[0] =1.0; paircumd[0] = 1.0; patcumd[0] =1.0; cumcyt=1; paircumcyt=1;
  pater = 0.0; unseulpar=0.0; couple=0.0;
  pcum=1; uncum=1; coucum=1; cumcyt=1;

  printf("\n***** CODOMINANT MARKERS *****\n");

  for (j=1; j<=nloc-cyt; ++j) {
    a2 = 0.0; a3 = 0.0; a4 = 0.0; a5 = 0.0; a6 = 0.0;
    for (i=1; i<=nall[j]; ++i)
      {
	pp = pf[j][i];
	a2 += pow(pp,2);       a3 += pow(pp,3);
	a4 += pow(pp,4);       a5 += pow(pp,5);
	a6 += pow(pp,6);
      }
    pater = 1 - 2*a2 + a3 +2*a4 -3*a5 -2*a2*a2 + 3*a2*a3; 
    pcum*=(1-pater);
    unseulpar = 1 - 4*a2 + 2*a2*a2 + 4*a3 - 3*a4; 
    uncum*=(1-unseulpar);
    couple = 1 + 4*a4 - 4*a5 - 3*a6 - 8*a2*a2 + 8*a2*a3 + 2*a3*a3; 
    coucum*=(1-couple);

    printf("\nExclusion at locus %d:\n", j);
    printf("Exclusion probabilities: \n");
    printf("\tsingle parent: \tpaternity: \tpair parents:\n \t%f \t%f \t%f", unseulpar, pater, couple);
    /* Store locus number */
    probex[0][j]=j;  
    /* Store probabilities */
    probex[1][j]=unseulpar;   
    probex[2][j]=pater;
    probex[3][j]=couple;
    printf("\nCumulative probabilities: \n");
    printf("\tsingle parent: \tpaternity: \tpair parents: \n \t%f \t%f \t%f",(1-uncum),(1-pcum),(1-coucum));
    printf("\n");
  }
  printf("\n\nCumulated probabilities over all loci: \n");
  printf("\tsingle parent: \tpaternity: \tpair parents: \n \t%f \t%f \t%f", (1-uncum),(1-pcum),(1-coucum)); 

  /* Sort probabilities by single parent exclusion (probex[1])*/
  sort4(nloc-cyt, probex[1], probex[0], probex[2], probex[3]);

  printf("\n\nLoci sorted by decreasing exclusion probabilities: \n");
  printf("Locus n�: \tsingle parent: \tpaternity: \tparent pair:\n");
  for (i=nloc-cyt;i>=1;--i)
    printf("\n\t %.0f \t%f \t%f \t%f", probex[0][i], probex[1][i], probex[2][i], probex[3][i]);

  printf("\n\nCumulated exclusions: \n");
  printf("Locus n�: \tsingle parent: \tpaternity: \tparent pair:\n");
  pcum=1; uncum=1; coucum=1;
  for (i=nloc-cyt;i>=1;--i)
    {    
      uncum*=(1- probex[1][i]);
      pcum*=(1-probex[2][i]);
      coucum*=(1-probex[3][i]);
      printf("\n\t %.0f \t%f \t%f \t%f", probex[0][i], (1-uncum), (1-pcum), (1-coucum));
    }


  /* 	for (k=0; k<=4; ++k) */
  /* 		{  txu[k] = 1.0; txuu[k] = 1.0; txqu[k] =1.0; } */

  printf("\n\n***** DOMINANT MARKERS *****\n");
  
  for (j=1; j<=nlocd; ++j)
    {
      /*  printf("\n locus j : %d \n", j); */        
      p = pfd[j];
      pair = p*(1-p)*(1-p)*(1-p)*(1-p)*(2-p); /* exclusion d'une paire de parents pour le locus */  
      paircumd[j] = paircumd[j-1]*(1.0 - pair); /* exclusion cumul�e d'une paire de parents*/  
      /*   printf("cuu : %f\n",cuu); */
      pater = p*(1-p)*(1-p)*(1-p)*(1-p) ;  /*exclusion de paternit� pour le locus*/
      patcumd[j]= patcumd[j-1]*(1.0 - pater);      /*exclusion cumul�e de paternit�*/

      /* Store locus number */
      probexd[0][j]=j;  
      /* Store probabilities: first paternity, second pair exclusion*/
      probexd[1][j]=pater;   
      probexd[2][j]=pair;

      /*  printf("cqu : %f\n",cqu); */
      /*  printf("\n exclusion at autosomal locus %d : */
      /*\n exclusion d'une paire de parents possible : \t %f */
      /*\n exclusion d'un parent, l'autre �tant connu : \t %f", j, cuu, cqu );  */      
      /*    printf(" %d ", j); */   /*  locus */      
      /*   printf(" %f ", cuu );  */    /*  paire  */      
      /*  printf(" %f ", cqu ); */    /*  paternit� */
      
    }
  printf("\n Single locus exclusion probabilities:\n");
  printf(" Locus n�: \n");    
  for (j=1; j<=nlocd; ++j) printf("\t%8d",j);
  printf("\n");    
  printf(" Paternity: \n");    
  for (j=1; j<=nlocd; ++j) printf("\t%8.5f",(probexd[1][j]));
  printf("\n");   
  printf(" Pair: \n");    
  for (j=1; j<=nlocd; ++j) printf("\t%8.5f",(probexd[2][j]));
  printf("\n");   
  
  printf("\n Single locus exclusion cumulated probabilities:\n");
  printf(" Locus n�: \n");    
  for (j=1; j<=nlocd; ++j) printf("\t%8d",j);
  printf("\n");    
  printf(" Paternity: \n");    
  for (j=1; j<=nlocd; ++j) printf("\t%8.5f",(1-patcumd[j]));
  printf("\n");   
  printf(" Pair: \n");    
  for (j=1; j<=nlocd; ++j) printf("\t%8.5f",(1-paircumd[j]));
  printf("\n");   
  
  printf("\n Overall exclusion probabilities:\n paternity:\t\t%8.5f \n pair of parents:\t%8.5f\n", (1.0-patcumd[nlocd]), (1.0- paircumd[nlocd]) ); 
  
  printf("\n"); 
 
  /* Sort probabilities by paternity exclusion (probexd[1])*/
  sort3(nlocd, probexd[1], probexd[0], probexd[2]);

  printf("Loci sorted by decreasing exclusion probabilities: \n");
  printf("Locus n�: \tpaternity: \tparent pair:\n");
  for (i=nlocd;i>=1;--i)
    printf("\n\t %.0f \t%8.5f \t%8.5f", probexd[0][i], probexd[1][i], probexd[2][i]);

  printf("\n\nCumulated exclusions: \n");
  printf("Locus n�: \tpaternity: \tparent pair:\n");
  patcu=1; paircu=1;
  for (i=nlocd;i>=1;--i)
    {    
      patcu*=(1-probexd[1][i]);
      paircu*=(1-probexd[2][i]);
      printf("\n\t %.0f \t%8.5f \t%8.5f", probexd[0][i], (1-patcu), (1-paircu));
    }

  printf("\n\n***** CODOMINANT AND DOMINANT MARKERS *****\n\n");
  printf("Exclusion probabilities: \n");
  printf("\tsingle parent: \tpaternity: \tpair parents:\n \t%f \t%f \t%f",  
	 (1-patcumd[nlocd]*uncum),(1-pcum),(1-paircumd[nlocd]*coucum));

  printf("\n\n***** CYTOPLASMIC MARKERS *****\n");

  /* Exclusion probabilities for cytoplasmic markers */
  if (cyt > 0)
    {
      for (i=1; i<=cyt; ++i) 
	{
	  procyt=0;
	  pairprocyt=0;
	  for (j=1; j<=nallc[i]; ++j)
	    {
	      pp = pfc[i][j];
	      procyt+=pp*(1-pp);
	      pairprocyt+=pp*(1-pp)*(1-pp);
	    }
	  
	  cumcyt*=(1-procyt);
	  paircumcyt*=(1-pairprocyt);
	}
      printf("\n\n Exclusion probabilities at cytoplasmic marker: ");

      printf("\n Single parent: \t%f\n", 1-cumcyt);
      printf(" Pair of parents: \t%f\n", 1-paircumcyt);



    }
  printf("\n\n***** CODOMINANT, DOMINANT AND CYTOPLASMIC MARKERS *****\n");
  printf("\n Exclusion probabilities for codominant and dominant markers: \n");
  printf("\tsingle parent: \tpaternity: \tpair parents:\n \t%f \t%f \t%f",  
	 (1-patcumd[nlocd]*uncum),(1-pcum),(1-paircumd[nlocd]*coucum));
  printf("\n\n Exclusion probabilities for codominant and cytoplasmic markers: \n");
  printf("\tsingle parent: \tpaternity: \tpair parents:\n \t%f \t%f \t%f",  
	 (1-uncum*cumcyt),(1-pcum),(1-coucum*paircumcyt));
  printf("\n\n Exclusion probabilities for dominant and cytoplasmic markers: \n");
  printf("\tsingle parent: \tpaternity: \tpair parents:\n \t%f \t%f \t%f",  
	 (1-patcumd[nlocd]*cumcyt),(1-pcum),(1-paircumd[nlocd]*paircumcyt));
  printf("\n\n Exclusion probabilities for the three types of markers: \n");
  printf("\tsingle parent: \tpaternity: \tpair parents:\n \t%f \t%f \t%f",  
	 (1-patcumd[nlocd]*uncum*cumcyt),(1-pcum),(1-paircumd[nlocd]*coucum*paircumcyt));
  printf("\n");
  return(0);

}
