#include <math.h>
#include <stdio.h>
/* #include <time.h> */  /* pour initialiser le g�n�rateur de nombres al�atoires*/
#include <sys/time.h>
#include <unistd.h>
#include <stdlib.h>     
#include "nrutil.h"
#include "read.h"
#include "sort.h"
#include "alea.h"
#include "genetic.h"
#include "likely.h"

/**************************************************************************

Program to tabulate possible parent pairs, and log-likelihoods, for given
sets of juveniles, potential fathers, and potential mothers.
Ordered to find best 4 mums, best 4 dads, best 4 pairs.
Includes possibility of X-linked loci.

Modified from earlier programs; July 1996

Programme modifi� pour consid�rer des hermaphrodites, et int�grer possibles 
autof�condations 25/11/98

*** Pourcentage d'erreur ajout� dans les calculs 26/11/98
(inspir� de Marshall et al 1998)
utilis� en lan�ant le programme suivi de < fichier
le fichier contient 
nb_loc nb_all_loc1  freq_all1_loc1 freq_all2_loc2.... nb_all_loc2  etc...
nb_parents nb_desc-�-simuler
num�ro_parent1 all1_loc1 all2_loc1 etc... 
le fichier likh est un fichier d'exemple pour ce programme
Donne les 8 meilleurs parents et couples dans l'ordre.
Modifi� le 18/12/98 pour prendre les log 
de la vraisemblance

Fait des simulations :
cr�e des descendants intra parcelle, stocke en m�moire les vrais parents :
- meilleurs 2 parents d'apr�s les vraisemblances
- meilleur couple
Stocke les vraisemblance : 
Vraisemblances des parents choisis avec une bonne d�cision : fichier Parbd
                                            mauvaise                 Parmd
Vraisemblances des couples choisis avec une bonne d�cision : fichier Coupbd
                                            mauvaise                 Coupmd
Fr�quences de bonnes d�cisions.

28/7/99
Ajout de l'�limination des calculs des donn�es manquantes
10/01
Combining autside/inside into the same program
***************************************************************************/

extern double rans();
extern double log();


main (int argc, char *argv[])
{   
  char *name1, *name2, *name3;  
  int nloc, *nall, cyt, *nallc, cytmater, miss;
  double **pf, **pfc, **fcum, **fcumc, E, Es, F, f;	         /* loci details; prior freqs; fr�quences cumul�es*/
  /* E pourcentage d'erreurs de g�notypage dans le calcul de vrsb*/
  /* Es pourcentage d'erreurs de g�notypage dans les simulations */ 
  int nkid, nkid1, npar;			 /*number of kids, parents */
  int  *name_kid, *name_par, **parcyt, **kidcyt;            /* individual names etc. */
  Geno **kidgen, **pargen; 	/* genotypic data */
  Geno *kidpar;                        /* nom des vrais parents du descendant*/
  int **dadgam, **mumgam;      /* Gam�tes paternel et paternel*/
  int i,j,k,ii,jj, iii, dad, mum, mere, bdp, mdp; 
  int npod, io;
  double  best_dads[10], bp, bdpf;
  double score[10], cc, bc;
  double *bestf, x, y, *deltatrue, *deltawrong, *deltawrongi, *deltawrongo1,*deltawrongo2 , deltamax, delta1, delta2;
  FILE *nn, *n1, *nn1;  

  /* Initialisation du g�n�rateur de nombres al�atoires :*/
  long m;
  float rand;
  struct timeval temps; 
  struct timezone  zone;
  gettimeofday(&temps,&zone);
  m=-temps.tv_usec; 
  rand=ran3(&m);
  
  name1="Best fathers";
  name2="Delta, true fathers";
  name3="Delta, wrong fathers";

  /* Reading arguments */
  nkid=atoi(argv[1]);
  E=atof(argv[2]); 
  Es=atof(argv[3]);
  cyt=atoi(argv[4]);
  cytmater=atoi(argv[5]); /* Maternal heredity of cytoplasme : yes=1 */
  io=atoi(argv[6]); /*=1 : sample fathers among genotyped, =2 sample according to allele freq */
  F=atof(argv[7]); 
  miss=atoi(argv[8]); 

  
  /* Lecture des donn�es locus */
  scanf ("%d", &nloc);
  nall=(int *)malloc((nloc-cyt+1)*sizeof(int));
  if (cyt > 0) nallc=(int *)malloc((cyt+1)*sizeof(int));
  read_loci_cum (nloc, nall, &pf, &fcum, cyt, nallc, &pfc, &fcumc);
  printf("\n Number of loci %d",nloc);
  printf("\n Of which %d cytoplasmic markers",cyt);
  
  scanf ("%d %d", &npar, &nkid1);
  printf ("\n Number of parents: %d Number of simulated offspring: %d\n", npar,nkid);

  if (io==1) printf("\n***** Simulating offpring with father from genotyped parents *****\n");
  if (io==2) printf("\n***** Simulating offpring with father according to allele frequencies *****\n");

  printf("\n Simulation error %f, Lod calculation error %f, Heterozygote deficit %f\n", Es, E, F);    
/*   printf("\n (The simulated delta values (2nd_most_likely_lod - 1st_most_likely_lod) are in files delta.father.in/out)");  */
 
  name_kid=(int *)malloc((nkid+1)*sizeof(int));
  name_par=(int *)malloc((npar+1)*sizeof(int));
  kidgen=(Geno **)malloc((nkid+1) * sizeof(Geno *));
  kidpar=(Geno *)malloc((nkid+1) * sizeof(Geno));
  pargen=(Geno **)malloc((npar+1) * sizeof(Geno *));
  mumgam=(int **)malloc((npar+1) * sizeof(int *));
  kidcyt=(int **)malloc((nkid+1) * sizeof(int *));
  parcyt=(int **)malloc((npar+1) * sizeof(int *));
  
  if (io==1) j=npar;
  else if (io==2) j=nkid;
  dadgam=(int **)malloc((j+1) * sizeof(int *));

  for (i=1; i<=j; i++) dadgam[i]=(int *)malloc((nloc+1) * sizeof(int));

  for (i=1; i<=nkid; i++)  
    {
      kidgen[i]=(Geno *)malloc((nloc-cyt+1) * sizeof(Geno));
      kidcyt[i]=(int *)malloc((cyt+1) * sizeof(int));
    }
  for (i=1; i<=npar; i++)  
    {
      parcyt[i]=(int *)malloc((cyt+1) * sizeof(int));
      pargen[i]=(Geno *)malloc((nloc-cyt+1) * sizeof(Geno));
      mumgam[i]=(int *)malloc((nloc+1) * sizeof(int));
    }
  
  read_gen_dat_par (npar, name_par, pargen, parcyt, nloc, cyt);
  
  /*Initialisations*/
  bdp=0; mdp=0; iii=0;
  
  
  /* Cr�ation de descendants*/
  printf("\n Simulation step");

  if(io==1)
    {
      for (ii=1;ii<=nkid;++ii)
	{
	  name_kid[ii]=ii;
	  mum = 1+(int)(npar*alea()) ;         /* Tirage al�atoire des deux parents : */
	  f=alea();
	  if (f<=2*F/(1+F)) dad=mum;         /*selfing at equilibrium = [2*F/(1+F)] */
	  else dad = 1+(int)(npar*alea()) ;         /* nombre entier al�atoire dans [1,npar] */ 
	  gamete(pargen[mum],mumgam[mum],nloc,nall,Es, cyt, nallc, parcyt[mum]); /* Simulation des gam�tes parentaux : */ 
	  gamete(pargen[dad],dadgam[dad],nloc,nall,Es, cyt, nallc, parcyt[dad]);
	  kidpar[ii].g1=name_par[mum]; 
	  kidpar[ii].g2=name_par[dad];  
	  for (jj=1;jj<=nloc-cyt;++jj)
	    {
	      kidgen[ii][jj].g1=mumgam[mum][jj];  /* ii :enfant, jj locus*/
	      kidgen[ii][jj].g2=dadgam[dad][jj];  
	    }  
	  if  (cyt > 0)
	    { 
	      if(cytmater==0) for (jj=nloc-cyt+1;jj<=nloc;++jj)  kidcyt[ii][jj-nloc+cyt] = mumgam[mum][jj];    
	      else if  (cytmater==1) for (jj=nloc-cyt+1;jj<=nloc;++jj)  kidcyt[ii][jj-nloc+cyt] = dadgam[dad][jj]; 
	    }
	}
    }
  else if (io==2)
    {
      for (ii=1;ii<=nkid;++ii)
	{
	  name_kid[ii]=ii;
	  mum = 1+(int)(npar*alea()) ;      
	  /* Tirage al�atoire d'un parent parmi ceux de la parcelle */
	  
	  gamete(pargen[mum], mumgam[mum], nloc, nall, Es, cyt, nallc, parcyt[mum]);   
	  /* Simulation des gam�tes parentaux : dans la parcelle*/    
	  gamete_hp(dadgam[ii], nloc, nall, fcum, cyt, nallc, fcumc);  /* hors parcelle*/
	  kidpar[ii].g1=name_par[mum];            /* Nom du parent de la parcelle*/
	  
	  for (jj=1;jj<=nloc-cyt;++jj)
	    {
	      kidgen[ii][jj].g1=mumgam[mum][jj];  /* ii :enfant, jj locus*/
	      f=alea();
	      if(f<=F) kidgen[ii][jj].g2=mumgam[mum][jj];
	      else kidgen[ii][jj].g2=dadgam[ii][jj];
	    }
	  if  (cyt > 0 && cytmater==0)
	    {
	      if (cytmater==1) for (jj=nloc-cyt+1;jj<=nloc;++jj)  kidcyt[ii][jj-nloc+cyt] = mumgam[mum][jj];             
	      else if (cytmater==0) for (jj=nloc-cyt+1;jj<=nloc;++jj)  kidcyt[ii][jj-nloc+cyt] = dadgam[ii][jj];  
	    }
	  /* Paternal cytoplasmic heredity, if maternal, */
	  /* not interesting to use the information, except for checking right known mother*/
	}
    }

  printf("\n End of simulation step \n");

    if (io==1)   
      {  
        nn = fopen ("father.gd.in", "w");   
        nn1 = fopen ("father.bd.in", "w");  
      
      }  
    else if (io==2)  
      {  
        n1 = fopen ("father.bd.out", "w");  
      }  

  printf("\n Calculation step");
   
  /* 	First allocate memory to store data: draw a histogram later thanks to them */

  bestf=(double *)malloc((nkid+1)*sizeof(double));
  deltatrue=(double *)malloc((2*nkid+1)*sizeof(double));
  deltawrongi=(double *)malloc((2*nkid+1)*sizeof(double));
  deltawrongo1=(double *)malloc((nkid+1)*sizeof(double));
  deltawrongo2=(double *)malloc((nkid+1)*sizeof(double));
  deltawrong=(double *)malloc((4*nkid+1)*sizeof(double));
  for (i=1; i<=nkid; i++) bestf[i]=0.0;

  for (i=1; i<=nkid; ++i)
    {
      /*printf ("\t%5d\t", name_kid[i]); printf ("\b\b\b\b\b\b\b\b\b\b");      */
      /*if (io==1) printf ("\n kid %d mum %d dad %d ", name_kid[i], kidpar[i].g1, kidpar[i].g2);          */
      /*else if (io==2) printf ("\n kid %d mum %d ", name_kid[i], kidpar[i].g1);    */
      /*print_geno(kidgen[i], nloc);   */
      /*for (l=1; l<=npar; ++l) if (kidpar[i].g1==name_par[l])   print_geno(pargen[l], nloc);       */
      /*for (l=1; l<=npar; ++l) if (kidpar[i].g2==name_par[l])   print_geno(pargen[l], nloc);      */
      
      /* Calcul des vraisemblances des p�res pour chaque descendant */
      
      npod=0; bc=1.0E6;
      for (k=1; k< 9; ++k) { best_dads[k] =0; score[k]=0.0;} 
      for (j=1; j<=npar; ++j)
	{
	  for (ii=1; ii<=npar; ++ii)
	    {
	      if ( kidpar[i].g1==name_par[ii]) mere=ii;
	    }

	  cc = pater(kidgen[i], pargen[mere], pargen[j], nloc-cyt, pf, E, F, nall, miss); 
	  if (cyt > 0 && cytmater==0) cc+=likr_pat_cyt(cyt, kidcyt[i], parcyt[j], pfc, E, nallc);

/* 	  printf("\ncc %f", cc);  */
/* 	  printf("\ni %d, kidgen[i]", i); print_geno(kidgen[i], nloc);     */
/* 	  printf("\npargen[mere]"); print_geno(pargen[mere], nloc);     */
/* 	  printf("\npargen[j]"); print_geno(pargen[j], nloc);     */
/* 	  printf("\nnloc-cyt %d, E %f, F %f",  nloc-cyt, E, F);     */

	  if (cc > 0.0 && finite(cc)==1) 
	    {
	      ++npod;
	      if (npod < 9) 
		{
		  best_dads[npod] = name_par[j]; 
		  score[npod]=cc; 
		  if (cc < bc)  bc = cc; 
		  /*printf("\nbest_dads[npod] %f,score[npod] %f",best_dads[npod],score[npod]);  */
		} 
	      else
		{
		  if (cc > bc) 
		    {
		      k = dexmin(score, 8);
		      best_dads[k] = name_par[j];
		      score[k] = cc;
		      bc = valmin(score, 8); 
		      /*printf("\nbest_dads[k] %f,score[k] %f",best_dads[k],score[k]);  */
		    }
		}
	    }	  
	  /* printf ("\n pc: %f \t",pc); */ 
	} 
      
      sort2(8,score,best_dads);			
      
      /* Affichage */
      /*printf ("\n Meilleurs p�res et leurs scores:\n");     */
      /*for (k=8; k>=1; --k) fprintf ("\t %.2g",score[k]); fflush(stdout);     */
            
      k=8; 
      bestf[i]= score[k];
      deltamax=score[8];
      delta1= deltamax; /*delta of the first most likely father*/
      if (score[7]>0) delta2= score[7]-deltamax; else  delta2=0; /*delta of the second most likely father*/
      if(io==1) { 
	if (best_dads[8]==kidpar[i].g2) {deltatrue[iii]=delta1; iii+=1;} else deltawrongi[i]=delta1;
	if (best_dads[7]==kidpar[i].g2) {deltatrue[iii]=delta2; iii+=1;} else deltawrongi[i]=delta2;
      }
      if (io==2) { deltawrongo1[i]=delta1; deltawrongo2[i]=delta2; } 
      /*printf("\n Best dad %f scores %f",best_dads[8], score[8]);  */

      /* Stocker les vraisemblances de bonne  (bd) et mauvaise d�cision (md) pour les meilleurs p�res*/
      if (io==1)
	{    
	  bp=best_dads[k]; 
	  if (bp==kidpar[i].g2)    
	    {		
	      if (score[k]>0.000000) ++bdp; 
	      fprintf (nn, " %f", score[8]); 
	    }
	  else
	    {	      
	      ++mdp;
  	      fprintf (nn1, " %f", score[8]); 
	    }
	  
	}
      else if (io==2)	      
	{
	  if (score[8]>0.000000) 	      
	    {
	      fprintf (n1, " %f", score[8]);    
	    }
	}
    }
  if (io==1)
    {
      x=bdp;
      y=nkid;
      bdpf=100*x/y; /* Percentage of correct classification */
      printf("\n The most likely father is the right father in %d simulations (%.2f %%)",bdp,bdpf); 
    }
  printf("\n End of calculation step\n");	
  /*     printf("\nbdp %d, mdp %d",bdp,mdp);   */
  
  hist1(bestf, nkid, name1);

  if (io==1) hist1(deltatrue, (iii-1), name2);
  for (i=1; i<=2*nkid; ++i) deltawrong[i]=deltawrongi[i];
  for (i=2*nkid+1; i<=3*nkid; ++i)  deltawrong[i]=deltawrongo1[i-2*nkid];
  for (i=3*nkid+1; i<=4*nkid; ++i)  deltawrong[i]=deltawrongo2[i-3*nkid];

  if (io==2) hist1(deltawrong, 4*nkid, name3);

  if (io==1)
    {
      fclose(nn);  
      fclose(nn1);
    }
  else if(io==2)
    {
      fclose(n1);  
    }
  
  printf("\n");
  
  return(0);
  
}
