
#include <math.h>
#include <stdio.h>
#include "nrutil.h" 
#include "sort.h"
#include "read.h"
#include "genetic.h"

/**************************************************************************
16/7/01
Program to compute probability of identity according to formulas given in
Waits et al. 2001

***************************************************************************/



extern double rans();
extern double pow();
			

main (int argc, char *argv[])
{
  int i,j,k,l, marker_type, npar, nkid, *name_par, cyt, **parcyt, **pargend; 
  double p, pp, ppp, a2, a3, a4, *pidom, *picod, *pi, *picod_bia, *pic_cum,  *pic_cum_bia, *pid_cum, *pi_cum;
  int nloc, nlocd, *nall, *nallc, nid;                       /* nb locus, number of alleles / idem cytoplasmic */
  double **pf, *pfd, **pfc, n, cp1, *locn, *locnd, *locs, x, y, pic_obs, *loc_ty;                           /* loci details */
  Geno **pargen;

  cyt=atoi(argv[1]);
  marker_type=atoi(argv[2]);

  scanf ("%d", &nloc);        

  if (cyt > 0) nallc=(int *)malloc((cyt+1)*sizeof(int));

  locn=(double *)malloc((nloc-cyt+1) * sizeof(double));

  if (marker_type==1) /* Codominant markers*/
    { 
      printf("\n Number of codominant loci: %d \n",nloc);
      if (cyt>0) printf(" Among them, cytoplasmic markers: %d \n",cyt);
      picod=(double *)malloc((nloc-cyt+1) * sizeof(double));
      picod_bia=(double *)malloc((nloc-cyt+1) * sizeof(double));
      pic_cum=(double *)malloc((nloc-cyt+1) * sizeof(double));
      pic_cum_bia=(double *)malloc((nloc-cyt+1) * sizeof(double));

      nall=(int *)malloc((nloc+1)*sizeof(int));
      read_loci (nloc, nall, &pf, cyt, nallc, &pfc); 
      scanf ("%d %d", &npar, &nkid);    
      printf("Number of genotyped parents: %d \n", npar);
      n=npar;
      name_par=(int *)malloc((npar+1)*sizeof(int));
      pargen=(Geno **)malloc((npar+1) * sizeof(Geno *));
      parcyt=(int **)malloc((npar+1) * sizeof(int *));
      for (i=1; i<=npar; i++)  
	{
	  pargen[i]=(Geno *)malloc((nloc-cyt+1) * sizeof(Geno));
	  parcyt[i]=(int *)malloc((cyt+1) * sizeof(int));
	}

      read_gen_dat_par(npar, name_par, pargen, parcyt, nloc, cyt);

      cp1 = 0.0; 
      pic_cum[0]=1;
      pic_cum_bia[0]=1;
      printf("\nProbability of identity for each locus:\n");
      printf("\n Locus n�: \tBiased  \tUnbiased \n");
      printf(" Cumulative probabilities \n \t\tBiased  \tUnbiased\n\n");
      for (j=1; j<=nloc-cyt; ++j) 
	{
	  a2 = 0.0; a3 = 0.0; a4 = 0.0;
	  locn[j]=j;
	  for (i=1; i<=nall[j]; ++i) 
	    {		
	      pp = pf[j][i];
	      for (k=i+1; k<=nall[j]; ++k) 
		{
		  ppp=pf[j][k];
		  cp1+=2*pp*ppp*2*pp*ppp;
		}
	    }
	    for (i=1; i<=nall[j]; ++i) 
	      {
		pp = pf[j][i];
		a2 += pow(pp,2);       
		a3 += pow(pp,3);
		a4 += pow(pp,4);       
	      }
	  picod_bia[j]=cp1+a4;
	  picod[j] = ( n*n*n*(2*a2*a2-a4) - 2*n*n*(a3+2*a2) + n*(9*a2+2)-6 ) / ((n-1)*(n-2)*(n-3));
	  
	  printf("\t%d\t%f\t%f\n", j, picod_bia[j], picod[j]);
	  pic_cum[j]=pic_cum[j-1]*picod[j];
	  pic_cum_bia[j]=pic_cum_bia[j-1]*picod_bia[j];
	  

	  printf("\t\t%f\t%f\n", pic_cum_bia[j], pic_cum[j]);
	}
      
      /* Sort probabilities by unbiased probability of identity*/
      sort5(nloc-cyt, picod, locn, pic_cum, picod_bia, pic_cum_bia);
      
      printf("\n\nLoci sorted by decreasing unbiased probabilities of identity: \n");
      x=1; y=1;
      printf("Locus n�: \tBiased  \tUnbiased \nCumulated: \tBiased  \tUnbiased\n");
      for (i=nloc-cyt;i>=1;--i)
	{	
	  printf("\n\t %.0f \t%f \t%f ", locn[i], picod_bia[i], picod[i]);
	  x*=picod_bia[i];
	  y*=picod[i];
	  printf("\n\t\t%f \t%f ", x, y);
	}
	 
      printf("\n");
      
 
     /*  Identity probability observed for loci sorted according to the previous step  */
	  printf("\n For each series of loci: \n");
	  printf("\tNumber of identical pairs of genotypes (ni)");
	  printf("\n\t\tObserved probability of identity\n");

      for (k=1; k<=nloc-cyt; k++)
	{
	  nid=0.0;
	  for (i=1; i<=npar; i++) for (j=i+1; j<=npar; j++) nid += comp_id(pargen[i], pargen[j], locn, k);
	  x=npar;
	  y=nid;
	  pic_obs=y/(x*(x-1)/2);
	  for (l=1;l<=k; l++) printf(" %.0f", locn[l]);
	  printf("\n");
	  printf("\t %d ", nid);
	  printf("\t %f ", pic_obs);
	  printf("\n");
	}
      printf("\n");
    }

  else if (marker_type==2) /* Dominant markers*/
    {  
      printf("\n Number of dominant loci: %d \n",nloc);
      if (cyt>0) printf(" Among them, cytoplasmic markers: %d \n",cyt);

      pfd=(double *)malloc((nloc-cyt+1) * sizeof(double));
      pidom=(double *)malloc((nloc-cyt+1) * sizeof(double));
      pid_cum=(double *)malloc((nloc-cyt+1) * sizeof(double));
 
      read_loci_dom (nloc, cyt, nallc, pfd, &pfc); 
      scanf ("%d %d", &npar, &nkid);
      printf(" Number of genotyped parents: %d \n",npar);
      name_par=(int *)malloc((npar+1)*sizeof(int));
      pargend=(int **)malloc((npar+1) * sizeof(int *));
      parcyt=(int **)malloc((npar+1) * sizeof(int *));
      for (i=1; i<=npar; i++)  
	{
	  pargend[i]=(int *)malloc((nloc-cyt+1) * sizeof(int));	  
	  parcyt[i]=(int *)malloc((cyt+1) * sizeof(int));
	}
      read_gen_dat_par_dom (npar, name_par, pargend, nloc, cyt, parcyt);

      pid_cum[0]=1;
      printf("\nFor each locus: \n\tProbability of identity \n\t\t\tCumulative probability\n");

      for (j=1; j<=nloc-cyt; ++j) 
	{
	  locn[j]=j;
	  p=pfd[j];
	  pidom[j] = p*p + 2*p*(1-p)*2*p*(1-p) + (1-p)*(1-p)*(1-p)*(1-p);
	  printf("\n %d \t %f ", j, pidom[j]);
	  pid_cum[j]=pid_cum[j-1]*pidom[j];
	  printf("\t %f", pid_cum[j]);
	  fflush(stdout);
	}

      
      /* Sort probabilities by probability of identity*/
      sort2(nloc-cyt, pidom, locn);
      
      printf("\n\nLoci sorted by decreasing probabilities of identity: \n");
      x=1;
      printf("Locus n�: \tProbability \tCumulated probabilities:\n");
      for (i=nloc-cyt;i>=1;--i)
	{
	printf("\n\t %.0f \t%f ", locn[i], pidom[i]);
	x*=pidom[i];
	printf("\t%f ", x);
	}
	printf("\n");

     /*  Identity probability observed for loci sorted according to the previous step  */
      printf("\n For each series of loci: \n");
      printf("\tNumber of identical pairs of genotypes");
      printf("\n\t\tObserved probability of identity\n");
      
      for (k=1; k<=nloc-cyt; k++)
	{
	  nid=0.0;
	  for (i=1; i<=npar; i++) for (j=i+1; j<=npar; j++) nid += comp_id_dom(pargend[i], pargend[j], locn, k);
	  x=npar;
	  y=nid;
	  pic_obs=y/(x*(x-1)/2);
	  for (l=1;l<=k; l++) printf(" %.0f", locn[l]);
	  printf("\n");
	  printf("\t %d ", nid);
	  printf("\t %f ", pic_obs);
	  printf("\n");
	}
      printf("\n");
    }

  else if (marker_type==3) /* Codominant and dominant markers*/
    { 
      nall=(int *)malloc((nloc+1)*sizeof(int));
      if (cyt > 0) nallc=(int *)malloc((cyt+1)*sizeof(int));
      read_loci (nloc, nall, &pf, cyt, nallc, &pfc); 
      /*for (i=1; i<=nloc; ++i)for (j=1; j<=nall[i]; ++j) printf("loc %d allele %d freq %f",i, j, pf[i][j]); */
      scanf ("%d", &nlocd);
      pfd=(double *)malloc((nlocd+1) * sizeof(double));
      read_loci_dom (nlocd, 0, nallc, pfd, &pfc); 

      printf("\n Number of codominant %d, dominant %d loci", nloc, nlocd);
      if(cyt>0) printf("\n Among codominant, cytoplasmic markers: %d \n",cyt);
     
      picod=(double *)malloc((nloc-cyt+1) * sizeof(double));
      picod_bia=(double *)malloc((nloc-cyt+1) * sizeof(double));
      pic_cum=(double *)malloc((nloc-cyt+1) * sizeof(double));
      pic_cum_bia=(double *)malloc((nloc-cyt+1) * sizeof(double));
      pidom=(double *)malloc((nlocd+1) * sizeof(double));
      pid_cum=(double *)malloc((nlocd+1) * sizeof(double));
      locnd=(double *)malloc((nlocd+1) * sizeof(double));

      scanf ("%d %d", &npar, &nkid);   
      printf("Number of genotyped parents: %d \n", npar);
      n=npar;

      name_par=(int *)malloc((npar+1)*sizeof(int));
      pargen=(Geno **)malloc((npar+1) * sizeof(Geno *));
      parcyt=(int **)malloc((npar+1) * sizeof(int *));
      pargend=(int **)malloc((npar+1) * sizeof(int *));

      for (i=1; i<=npar; i++)  
	{
	  pargen[i]=(Geno *)malloc((nloc-cyt+1) * sizeof(Geno));
	  parcyt[i]=(int *)malloc((cyt+1) * sizeof(int));
	  pargend[i]=(int *)malloc((nlocd+1) * sizeof(int));
	}
      read_gen_dat_par_domcod(npar, name_par, nloc, nlocd, cyt, pargen, parcyt, pargend);

      /* id prob codom */
      cp1 = 0.0; 
      pic_cum[0]=1;
      pic_cum_bia[0]=1;
      printf("\nProbability of identity for each codominant locus:\n");
      printf("\n Locus n�: \tBiased  \tUnbiased \n");
      printf(" Cumulative probabilities \n \t\tBiased  \tUnbiased\n\n");
      for (j=1; j<=nloc-cyt; ++j) 
	{
	  a2 = 0.0; a3 = 0.0; a4 = 0.0;
	  locn[j]=j;
	  for (i=1; i<=nall[j]; ++i) 
	    {		
	      pp = pf[j][i];
	      for (k=i+1; k<=nall[j]; ++k) 
		{
		  ppp=pf[j][k];
		  cp1+=2*pp*ppp*2*pp*ppp;
		}
	    }
	    for (i=1; i<=nall[j]; ++i) 
	      {
		pp = pf[j][i];
		a2 += pow(pp,2);       
		a3 += pow(pp,3);
		a4 += pow(pp,4);       
	      }
	  picod_bia[j]=cp1+a4;
	  picod[j] = ( n*n*n*(2*a2*a2-a4) - 2*n*n*(a3+2*a2) + n*(9*a2+2)-6 ) / ((n-1)*(n-2)*(n-3));
	  
	  printf("\t%d\t%f\t%f\n", j, picod_bia[j], picod[j]);
	  pic_cum[j]=pic_cum[j-1]*picod[j];
	  pic_cum_bia[j]=pic_cum_bia[j-1]*picod_bia[j];
	  

	  printf("\t\t%f\t%f\n", pic_cum_bia[j], pic_cum[j]);
	}
      
      /* Sort probabilities by unbiased probability of identity*/
      sort5(nloc-cyt, picod, locn, pic_cum, picod_bia, pic_cum_bia);
      
      printf("\n\nCodominant loci sorted by decreasing unbiased probabilities of identity: \n");
      x=1; y=1;
      printf("Locus n�: \tBiased  \tUnbiased \nCumulated: \tBiased  \tUnbiased\n");
      for (i=nloc-cyt;i>=1;--i)
	{	
	  printf("\n\t %.0f \t%f \t%f ", locn[i], picod_bia[i], picod[i]);
	  x*=picod_bia[i];
	  y*=picod[i];
	  printf("\n\t\t%f \t%f ", x, y);
	}
	 
      printf("\n");

      /* id prob dom */
      pid_cum[0]=1;
      printf("\nFor each dominant locus: \n\tProbability of identity \n\t\t\tCumulative probability\n");

      for (j=1; j<=nlocd; ++j) 
	{
	  locnd[j]=j;
	  p=pfd[j];
	  pidom[j] = p*p + 2*p*(1-p)*2*p*(1-p) + (1-p)*(1-p)*(1-p)*(1-p);
	  printf("\n %d \t %f ", j, pidom[j]);
	  pid_cum[j]=pid_cum[j-1]*pidom[j];	  
	  printf("\t %f", pid_cum[j]);
	  fflush(stdout);
	}

      
      /* Sort probabilities by probability of identity*/
      sort2(nlocd, pidom, locnd);
      
      printf("\n\nDominant loci sorted by decreasing probabilities of identity: \n");
      x=1;
      printf("Locus n�: \tProbability \tCumulated probabilities:\n");
      for (i=nlocd;i>=1;--i)
	{
	  printf("\n\t %.0f \t%f ", locnd[i], pidom[i]);
	  x*=pidom[i];
	  printf("\t%f ", x);
	}
      printf("\n");
      
      /*  Identity probability observed for all loci sorted according to the previous step  */
      locs=(double *)malloc((nloc-cyt+nlocd+1) * sizeof(double));
      loc_ty=(double *)malloc((nloc-cyt+nlocd+1) * sizeof(double));
      pi=(double *)malloc((nloc-cyt+nlocd+1) * sizeof(double));
      pi_cum=(double *)malloc((nloc-cyt+nlocd+1) * sizeof(double));
      
      for (k=1; k<=nloc-cyt; k++) locs[k]=locn[k];
      for (k=1; k<=nlocd; k++) locs[nloc-cyt+k]=locnd[k];
      for (k=1; k<=nloc-cyt; k++) pi[k]=picod[k];
      for (k=1; k<=nlocd; k++) pi[nloc-cyt+k]=pidom[k];
      for (k=1; k<=nloc-cyt; k++) loc_ty[k]=1; /* Type of locus: 1=codo, 2=dom */
      for (k=1; k<=nlocd; k++) loc_ty[nloc-cyt+k]=2;
      sort3(nloc-cyt+nlocd, pi, locs, loc_ty);
      printf("\n Sorting codominant and dominant loci by decreasing probabilities of identity: ");
      printf("\n Loci (locus type 1=codominant 2=dominant)\n");
      printf("\tIndividual identity probability");
      printf("\n\t\t\tCumulated probability of identity");
      x=1;
      for (k=nloc-cyt+nlocd;k>=1; --k) 
	{
	  printf("\n %.0f (%.0f)", locs[k], loc_ty[k]);
	  x*=pi[k];
	  printf("\t %f \t%f ", pi[k], x);
	}
      
      printf("\n\n For codominant and dominant loci: ");
      printf("\n Loci considered (locus type 1=codominant 2=dominant)\n");
      printf("\tNumber of identical pairs of genotypes");
      printf("\n\t\tObserved probability of identity\n");
  
      for (k=1; k<=nloc-cyt+nlocd; k++)
	{
	  nid=0.0;
	  for (i=1; i<=npar; i++) 
	    for (j=i+1; j<=npar; j++) 
	      nid += comp_id_domcod(pargen[i], pargen[j], pargend[i], pargend[j], locs, loc_ty, nloc-cyt+nlocd);	    
	  x=npar;
	  y=nid;
	  pic_obs=y/(x*(x-1)/2);
	  for (l=1;l<=k; l++) printf(" %.0f (%.0f)", locs[l], loc_ty[l]);
	  printf("\n");
	  printf("\t %d ", nid);
	  printf("\t %f ", pic_obs);
	  printf("\n");
	}
      printf("\n");
    }

  return(0);

}

