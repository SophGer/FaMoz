
#include <math.h>
#include <stdio.h>
#include "nrutil.h" 
#include "sort.h"
#include "read.h"
#include "genetic.h"

/**************************************************************************
nov 2004
programme to detect individuals with identical genotypes

***************************************************************************/



extern double rans();
extern double pow();
			

main (int argc, char *argv[])
{
  int i,j,k, l, marker_type, npar, nkid, *name_par, cyt, **parcyt, **pargend; 
  int nloc, nlocd, *nall, *nallc, nid;                       /* nb locus, number of alleles / idem cytoplasmic */
  double *locn, **pf, *pfd, **pfc, n;                           /* loci details */
  Geno **pargen;

  cyt=atoi(argv[1]);
  marker_type=atoi(argv[2]);

  scanf ("%d", &nloc);        

  if (cyt > 0) nallc=(int *)malloc((cyt+1)*sizeof(int));

  locn=(double *)malloc((nloc-cyt+1) * sizeof(double));

  if (marker_type==1) /* Codominant markers*/
    {      
      printf("\n Number of codominant loci: %d \n",nloc);
      if (cyt>0) printf(" Among them, cytoplasmic markers: %d \n",cyt);

      nall=(int *)malloc((nloc+1)*sizeof(int));
      read_loci (nloc, nall, &pf, cyt, nallc, &pfc); 
      scanf ("%d %d", &npar, &nkid);    
      printf(" Number of genotyped parents: %d \n", npar);
      n=npar;
      name_par=(int *)malloc((npar+1)*sizeof(int));
      pargen=(Geno **)malloc((npar+1) * sizeof(Geno *));
      parcyt=(int **)malloc((npar+1) * sizeof(int *));
      for (i=1; i<=npar; i++)  
	{
	  pargen[i]=(Geno *)malloc((nloc-cyt+1) * sizeof(Geno));
	  parcyt[i]=(int *)malloc((cyt+1) * sizeof(int));
	}

      read_gen_dat_par(npar, name_par, pargen, parcyt, nloc, cyt);
      for (j=1; j<=nloc-cyt; ++j)  locn[j]=j;
      nid=0.0;
      k=0;
      l=0;
      for (i=1; i<=npar; i++) {
	for (j=i+1; j<=npar; j++) {	      
	  nid = comp_id(pargen[i], pargen[j], locn, nloc);
	  if (nid==1){
	    l+=1;
	    if (i!=k) {
	    printf("\n  %d", name_par[i]);
	    printf(" same as %d ", name_par[j]);
	    }
	    else printf(" same as %d ", name_par[j]);
	    nid=0;
	    k=i;
	  }
	}
      }
      if (l==0) printf("\n No identical genotypes\n");
      printf("\n");
    }
  else if (marker_type==2)  /* Dominant markers*/
    {
      printf("\n Number of dominant loci: %d \n",nloc);
      if (cyt>0) printf(" Among them, cytoplasmic markers: %d \n",cyt);

      pfd=(double *)malloc((nloc-cyt+1) * sizeof(double));
      read_loci_dom (nloc, cyt, nallc, pfd, &pfc); 
      scanf ("%d %d", &npar, &nkid);
      printf(" Number of genotyped parents: %d \n",npar);
      name_par=(int *)malloc((npar+1)*sizeof(int));
      pargend=(int **)malloc((npar+1) * sizeof(int *));
      parcyt=(int **)malloc((npar+1) * sizeof(int *));
      for (i=1; i<=npar; i++)  
	{
	  pargend[i]=(int *)malloc((nloc-cyt+1) * sizeof(int));	  
	  parcyt[i]=(int *)malloc((cyt+1) * sizeof(int));
	}
      read_gen_dat_par_dom (npar, name_par, pargend, nloc, cyt, parcyt);
      for (j=1; j<=nloc-cyt; ++j) locn[j]=j;
      
      nid=0.0;
      k=0;
      l=0;
      for (i=1; i<=npar; i++) 
	for (j=i+1; j<=npar; j++) {
	  nid = comp_id_dom(pargend[i], pargend[j], locn, nloc);
  	  if (nid==1){
	    l+=1;
	    if (i!=k) {
	      printf("\n  %d", name_par[i]);
	      printf(" same as %d ", name_par[j]);
	    }
	    else printf(" same as %d ", name_par[j]);
	    nid=0;
	    k=i;
	  }    
	}
      if (l==0) printf("\n No identical genotypes\n");
    }      
  printf("\n");
  return(0);
}
