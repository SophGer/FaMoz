/**************************************************************************************
  16/5/01 
  The read library contains programs to read data from data file
 *************************************************************************************/

typedef struct _Geno { int g1; int g2; } Geno;


/******** Codominant markers ***********/


void print_geno (gg, nl) 
     Geno *gg; 
     int nl;
{
  int i;
  for (i=1; i<=nl; ++i) printf ("  %d %d  ", gg[i].g1, gg[i].g2); 
  printf("\n");
}

void print_geno_dom (gg, nl) 
     int *gg; 
     int nl;
{
  int i;
  for (i=1; i<=nl; ++i) printf (" %d ", gg[i]); 
  printf("\n");
}

void print_geno_cyt (gg, gc, nl, nc) 
     Geno *gg; 
     int nl, nc, *gc;
{
  int i;
  for (i=1; i<=nl-nc; ++i) printf ("  %d %d  ", gg[i].g1, gg[i].g2); 
  for (i=1; i<=nc; ++i) printf ("  %d", gc[i]); 
  printf("\n");
}

void read_loci (nl, na, pf1, nc, nac, pfc)
     int nl,*na, *nac; 
     double ***pf1, ***pfc;  /* *pf1[NL][NA] pointeur vers un double pointeur */
{ 
  int i,j; 
  double cc1;

  *pf1=(double **)malloc((nl+1) * sizeof(double *));
  for (i=1; i<=nl-nc; ++i)
    {
      /*printf("locus %d \n",i);   */
      cc1=0.0;
      scanf("%d",na+i); /*nb all�les*/
      /* printf (" nb all�le %d  \n",na[i]); */
      (*pf1)[i]=(double *)malloc((na[i]+1) * sizeof(double));
      for (j=1; j<= na[i]; ++j)
	{ 
	  scanf(" %lf",&((*pf1)[i][j])); 
	  cc1 += (*pf1)[i][j]; 
	}
      if ((cc1 > 1.0001) || (cc1< 0.9998))
	{
	  printf ("\n locus %d allele freqs wrong (total sum = %f) \n",i,cc1);
	  exit (99);
	}
    }
  
  if (nc > 0) /*  If cytoplasmic markers are present, read the haplotype number and frequencies */
    {
      *pfc=(double **)malloc((nc+1) * sizeof(double *));
      for (i=1; i<=nc; ++i)
	{
	  cc1=0.0;
	  scanf("%d",nac+i); /*nb all�les*/
	  (*pfc)[i]=(double *)malloc((nac[i]+1) * sizeof(double)); 
	  for (j=1; j<= nac[i]; ++j)
	    { 
	      scanf(" %lf",&((*pfc)[i][j])); 
	      cc1 += (*pfc)[i][j]; 
	      /*printf("locus %d allele %d fr�quence %f",i,j, (*pfc)[i][j]);    */
	    }
	  if ((cc1 > 1.0001) || (cc1< 0.9998))
	    {
	      printf ("\n cyto locus %d allele freqs wrong : %f \n",i,cc1);
	      exit (99);
	    }
	}
    }
}


/* Include the cumulated frequencies (for simulation programs with sampling gamete outside the stand) */
void read_loci_cum (nl,na, pf1, fcum1, nc, nac, pfc, fcum2)
     int nl,*na, nc, *nac;
     double ***pf1, ***pfc, ***fcum1, ***fcum2;
{ 
  int i,j; 
  double cc1;

  *pf1=(double **)malloc((nl-nc+1) * sizeof(double *));
  *fcum1=(double **)malloc((nl-nc+1) * sizeof(double *));
  for (i=1; i<=(nl-nc); ++i)
    {
      /*printf("locus %d ",i);   */
      cc1=0.0;
      scanf("%d",na+i);
      /*printf (" nb all�le %d  \n",na[i]); */
      (*pf1)[i]=(double *)malloc((na[i]+1) * sizeof(double));
      (*fcum1)[i]=(double *)malloc((na[i]+1) * sizeof(double));
      (*fcum1)[i][0]=0;
      for (j=1; j<= na[i]; ++j)
	{	
	  scanf(" %lf",&((*pf1)[i][j]));
	  /*printf (" freq %f \n", (*pf1)[i][j]); */
	  cc1 += (*pf1)[i][j]; (*fcum1)[i][j]=cc1; 
	}
      if ((cc1 > 1.0001) || (cc1< 0.9998))
	{
	  printf ("\n locus %d allele freqs wrong : %f \n",i,cc1);
	  exit (99); 
	}
    }
  if (nc > 0) /*  If cytoplasmic markers are present, read the haplotype number and frequencies */
    {
      *pfc=(double **)malloc((nc+1) * sizeof(double *));
      *fcum2=(double **)malloc((nc+1) * sizeof(double *));
     for (i=1; i<=nc; ++i)
	{
	  cc1=0.0;
	  scanf("%d",nac+i); /*nb all�les*/
	  (*pfc)[i]=(double *)malloc((nac[i]+1) * sizeof(double)); 
	  (*fcum2)[i]=(double *)malloc((nac[i]+1) * sizeof(double));
	  (*fcum2)[i][0]=0;
	  for (j=1; j<= nac[i]; ++j)
	    { 
	      scanf(" %lf",&((*pfc)[i][j])); 
	      cc1 += (*pfc)[i][j]; 
	      (*fcum2)[i][j]=cc1; 
	      /*printf("locus %d allele %d fr�quence %f",i,j, (*pfc)[i][j]);    */
	    }
	  if ((cc1 > 1.0001) || (cc1< 0.9998))
	    {
	      printf ("\n cyto locus %d allele freqs wrong : %f \n",i,cc1);
	      exit (99);
	    }
	}
    }
}


void read_gen (gen,nl) 
     Geno *gen;
     int nl;
{
  int j; int d1,d2;
  for (j=1; j<= nl; ++j) 
    {
      scanf ("%d %d",&d1,&d2);
      gen[j].g1 =d1; gen[j].g2 = d2; 
    }
}

/* lecture du g�notype des parents for paternity analysis*/
void read_gen_dat_pater (npar, name_par, pargen, parcyt, nkid, name_mum, name_kid, kidgen, kidcyt, nl, nc)   
     int npar, *name_par, *name_kid, *name_mum, nl, nc, **kidcyt, **parcyt;
     Geno **pargen, **kidgen;
{ 
  int i, j, d; 
  for (i=1; i<=npar; ++i ) 
    {
      scanf("%d",name_par+i);
      read_gen ( pargen[i] ,nl-nc); 
      if (nc > 0)
	for (j=1; j<= nc; ++j)
	  {
	    scanf ("%d",&d);
	    parcyt[i][j]=d; 
	  }     
    }
 for (i=1; i<=nkid; ++i ) 
   {
     scanf("%d",name_mum+i);
     scanf("%d",name_kid+i);
     read_gen ( kidgen[i] ,nl-nc);     
     if (nc > 0)
       for (j=1; j<= nc; ++j) 
	 {
	   scanf ("%d",&d);
	   kidcyt[i][j]=d; 
	 }
   }
}


/* For parentage analysis */
void read_gen_dat(npar, nkid, name_kid, name_par, nl, nc, kidgen, pargen, kidcyt, parcyt)
     int npar, nkid, *name_kid, *name_par, nl, nc, **kidcyt, **parcyt;
     Geno **kidgen, **pargen;
{ 
  int i, j, d; 
  for (i=1; i<=npar; ++i ) 
    {
      scanf("%d",name_par+i);
      read_gen ( pargen[i] ,nl-nc); 
      if (nc > 0)
	for (j=1; j<= nc; ++j) 
	  {
	    scanf ("%d",&d);
	    parcyt[i][j]=d; 
	  }
    }
  for (i=1; i<=nkid; ++i )
    {
      scanf("%d",name_kid+i);
      read_gen ( kidgen[i] ,nl-nc); 
      if (nc > 0)
	for (j=1; j<= nc; ++j) 
	  {
	    scanf ("%d",&d);
	    kidcyt[i][j]=d; 
	  }
    }
}

/* For simulation, read only the parent */

void read_gen_dat_par(npar, name_par, pargen, parcyt, nl, nc)   /* lecture du g�notype des parents */
     int npar, *name_par, nl, nc, **parcyt;
     Geno **pargen;
{ 
  int i, j, d;
  
  for (i=1; i<=npar; ++i ) 
    {
      scanf("%d",name_par+i);
      read_gen ( pargen[i] ,nl-nc);      
      if (nc > 0)
	for (j=1; j<= nc; ++j) 
	  {
	    scanf ("%d",&d);
	    parcyt[i][j]=d; 
	  }
    }
}

/* Read parent genotype and species */

void read_gen_dat_par_sp (npar, name_par, sp, pargen, parcyt, nl, nc)   /* lecture du g�notype des parents */
     int npar, *name_par, *sp, nl, nc, **parcyt;
     Geno **pargen;
{ 
  int i, j, d;
  
  for (i=1; i<=npar; ++i ) 
    {
      scanf("%d",name_par+i);
      scanf("%d",sp+i);
      read_gen ( pargen[i] ,nl-nc); 
    }      
  if (nc > 0)
    for (j=1; j<= nc; ++j) 
      {
	scanf ("%d",&d);
	parcyt[i][j]=d; 
      }
}

/*************** Dominant markers *******************/

void read_loci_dom (nl, nc, na, pf1, pfc) 
     int nl, nc,*na; 
     double *pf1, ***pfc;
{
  int i, j;
  double cc1;
  for (i=1; i<=(nl-nc); ++i) scanf(" %lf",&(pf1[i])) ;
  /*   printf("locus %d fr�quence %f",i,pf1[i]);}  */
  if (nc > 0) /*  If cytoplasmic markers are present, read the haplotype number and frequencies */
    {
      *pfc=(double **)malloc((nc+1) * sizeof(double *));
      for (i=(1); i<=nc; ++i)
	{
	  cc1=0.0;
	  scanf("%d",na+i); /*nb all�les*/
	  /*printf("\n na %d", na[i]); */
	  (*pfc)[i]=(double *)malloc((na[i]+1) * sizeof(double)); 
	  for (j=1; j<= na[i]; ++j)
	    { 
	      scanf(" %lf",&((*pfc)[i][j])); 
	      cc1 += (*pfc)[i][j]; 
	      /*printf("\nlocus %d allele %d fr�quence %f",i,j, (*pfc)[i][j]); */
	    }
	  if ((cc1 > 1.0001) || (cc1< 0.9998))
	    {
	      printf ("\n cyto locus %d allele freqs wrong : %f \n",i,cc1);
	      exit (99);
	    }
	}
    }
}
 
void read_loci_dom_cum (nl, nc, na, pf1, pfc, fcumc) 
     int nl, nc,*na; 
     double *pf1, ***pfc, ***fcumc;
{
  int i, j;
  double cc1;
  for (i=1; i<=(nl-nc); ++i) scanf(" %lf",&(pf1[i])) ;
  /*   printf("locus %d fr�quence %f",i,pf1[i]);}  */
  if (nc > 0) 
    /*  If cytoplasmic markers are present, read the haplotype number and frequencies + cumulated freq */
    {
      *pfc=(double **)malloc((nc+1) * sizeof(double *));
      *fcumc=(double **)malloc((nc+1) * sizeof(double *));
      for (i=1; i<=nc; ++i)
	{
	  cc1=0.0;
	  scanf("%d",na+i); /*nb all�les*/
	  (*pfc)[i]=(double *)malloc((na[i]+1) * sizeof(double)); 
	  (*fcumc)[i]=(double *)malloc((na[i]+1) * sizeof(double));
	  for (j=1; j<= na[i]; ++j)
	    { 
	      scanf(" %lf",&((*pfc)[i][j])); 
	      cc1 += (*pfc)[i][j]; 
	      (*fcumc)[i][j]=cc1; 
	      /*printf("locus %d allele %d fr�quence %f",i,j, (*pfc)[i][j]);    */
	    }
	  if ((cc1 > 1.0001) || (cc1< 0.9998))
	    {
	      printf ("\n cyto locus %d allele freqs wrong : %f \n",i,cc1);
	      exit (99);
	    }
	}
    }
}

void read_gen_dom (gen,nl) 
     int *gen, nl;
{ 
  int j, d1;
  for (j=1; j<= nl; ++j) { scanf ("%d",&d1);
  gen[j]=d1; }
}

void read_gen_dat_pat_dom (npar, nkid, name_kid, name_par, name_mum, nl, nc, kidgen, pargen, kidcyt, parcyt)
     int npar, nkid, *name_kid, *name_par, *name_mum, nl, nc;
     int  **kidgen, **pargen, **kidcyt, **parcyt;
{
  int i, j, d;
  for (i=1; i<=npar; ++i )
    {
    scanf("%d",name_par+i);
    read_gen_dom (pargen[i],(nl-nc)); 
    if (nc > 0)
      for (j=1; j<= nc; ++j) 
	{
	  scanf ("%d",&d);
	  parcyt[i][j]=d; 
	}
    }
  for (i=1; i<=nkid; ++i )
    {
      scanf("%d",name_mum+i);
      scanf("%d",name_kid+i);

      read_gen_dom (kidgen[i],(nl-nc));
      if (nc > 0) 
	for (j=1; j<= nc; ++j) 
	  {
	    scanf ("%d",&d);
	    kidcyt[i][j]=d; 
	  }
    }
}
  

void read_gen_dat_dom (npar, nkid, name_kid, name_par, nl, nc, kidgen, pargen, kidcyt, parcyt)
     int npar, nkid, *name_kid, *name_par, nl, nc;
     int  **kidgen, **pargen, **kidcyt, **parcyt;
{
  int i, j, d;
  for (i=1; i<=npar; ++i ) 
    {
      scanf("%d",name_par+i);
      read_gen_dom ( pargen[i],nl-nc);   
      if (nc > 0)
	for (j=1; j<= nc; ++j) 
	  {
	    scanf ("%d",&d);
	    parcyt[i][j]=d; 
	  } 
    }      
  for (i=1; i<=nkid; ++i ) 
    {
      scanf("%d",name_kid+i);
      read_gen_dom ( kidgen[i],nl-nc); 
      if (nc > 0) 
	for (j=1; j<= nc; ++j) 
	  {
	    scanf ("%d",&d);
	    kidcyt[i][j]=d; 
	  }
    }
}

/* For simulation, read only the parent */

void read_gen_dat_par_dom (npar, name_par, pargen, nl, nc, parcyt)
     int npar, *name_par,  nl;
     int  **pargen, **parcyt;
{
  int i, d, j;
  for (i=1; i<=npar; ++i )
    {
      scanf("%d",name_par+i);
      read_gen_dom ( pargen[i],nl-nc); 
      if (nc > 0)
	for (j=1; j<= nc; ++j) 
	  {
	    scanf ("%d",&d);
	    parcyt[i][j]=d; 
	  }      
    }     
}


/* For parentage analysis with both codominant, dominant and cytoplasmic markers*/
void read_gen_dat_domcod(npar, nkid, name_kid, name_par, nl, nd, nc, kidgen, pargen, kidcyt, parcyt, kidgend, pargend)
     int npar, nkid, *name_kid, *name_par, nl, nd, nc, **kidcyt, **parcyt;
     Geno **kidgen, **pargen;
     int  **kidgend, **pargend;
{ 
  int i, j, d; 
  for (i=1; i<=npar; ++i ) 
    {
      scanf("%d",name_par+i);
      read_gen ( pargen[i] ,nl-nc); 
      if (nc > 0)
	for (j=1; j<= nc; ++j) 
	  {
	    scanf ("%d",&d);
	    parcyt[i][j]=d; 
	  }
      read_gen_dom ( pargend[i],nd);   
    }
  for (i=1; i<=nkid; ++i )
    {
      scanf("%d",name_kid+i);
      read_gen ( kidgen[i] ,nl-nc); 
      if (nc > 0)
	for (j=1; j<= nc; ++j) 
	  {
	    scanf ("%d",&d);
	    kidcyt[i][j]=d; 
	  }
      read_gen_dom ( kidgend[i],nd); 
    }
}

/* Read only parent genotype data */
void read_gen_dat_par_domcod(npar, name_par, nl, nd, nc, pargen, parcyt, pargend)
     int npar, *name_par, nl, nd, nc, **parcyt;
     Geno **pargen;
     int  **pargend;
{ 
  int i, j, d; 
  for (i=1; i<=npar; ++i ) 
    {
      scanf("%d",name_par+i);
      read_gen ( pargen[i] ,nl-nc); 
      if (nc > 0)
	for (j=(1); j<= nc; ++j) 
	  {
	    scanf ("%d",&d);
	    parcyt[i][j]=d; 
	  }
      read_gen_dom ( pargend[i],nd);   
    }
}



/* Read data for paternity analysis and dom + codom markers*/  
void read_gen_dat_pater_domcod (npar, name_par, pargen, pargend, parcyt, nkid, name_mum, name_kid, kidgen, kidgend, kidcyt, nl, nd, nc)   
     int npar, *name_par, *name_kid, *name_mum, nl, nd, nc, **kidgend, **pargend, **kidcyt, **parcyt;
     Geno **pargen, **kidgen;
{ 
  int i, j, d; 
  for (i=1; i<=npar; ++i ) 
    {
      scanf("%d",name_par+i);
      read_gen ( pargen[i] ,nl-nc); 
      if (nc > 0)
	for (j=1; j<= nc; ++j)
	  {
	    scanf ("%d",&d);
	    parcyt[i][j]=d; 
	  }     
      read_gen_dom (pargend[i],nd); 
    }
  for (i=1; i<=nkid; ++i ) 
    {
      scanf("%d",name_mum+i);
      scanf("%d",name_kid+i);
      read_gen ( kidgen[i] ,nl-nc);     
      if (nc > 0)
	for (j=1; j<= nc; ++j) 
	  {
	    scanf ("%d",&d);
	    kidcyt[i][j]=d; 
	  }
      read_gen_dom (kidgend[i],nd);
    }
}









