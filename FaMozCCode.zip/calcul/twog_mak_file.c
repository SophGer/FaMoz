
#include <math.h>
#include <stdio.h>
#include <stdlib.h> /* CHANGEMENT : rajout de cette biblotheque */

#include "nrutil.h"
#include "read.h"
#include "sort.h"


/**************************************************************************
19/06/03 Program to build a file for twogene analysis
***************************************************************************/



main (int argc, char *argv[])
{
  int i,j,k,l,m, nm, *name_mum, mum, c;
  int nloc, *nall, cyt, *nallc, nkid, npar, nparc, *name_kid, *name_par, *name_parc, **kidcyt, **parcyt;
  double **pf, **pfc, *x, *y, d;
  Geno **kidgen, **pargen;
  FILE *f, *g;


  /* Reading arguments */
  nm = atoi(argv[1]);  /* number of mothers */ /* CHANGEMENT atof -> atoi */
  d = atof(argv[2]);  /* adult density */
  f = fopen (argv[3], "r"); /* genotype file */
  /*   printf("\n%s\n", argv[3]); */
  
  g = fopen ("data_twog", "w");  


  (void) fscanf(f,"%d",&nparc);
  x=(double *)malloc((nparc+1)*sizeof(double));
  y=(double *)malloc((nparc+1)*sizeof(double));
  name_parc=(int *)malloc((nparc+1)*sizeof(int));
  for (i=1; i<= nparc; ++i) fscanf (f,"%d %lf %lf", name_parc+i, x+i, y+i);   
  /*for (i=1; i<= nparc; ++i) printf ("%d %lf %lf\n", name_parc[i], x[i], y[i]);*/


  /* Read data from genotype datafile */
  scanf ("%d", &nloc);
  nall=(int *)malloc((nloc-cyt+1)*sizeof(int));

  cyt = 0; /* CHANGEMENT : rajout de cette ligne */

  if (cyt > 0) nallc=(int *)malloc((cyt+1)*sizeof(int));
  read_loci (nloc, nall, &pf, cyt, nallc, &pfc);
  scanf ("%d %d", &npar, &nkid);    


  /*Allocation*/
  name_kid=(int *)malloc((nkid+1)*sizeof(int));
  name_mum=(int *)malloc((nkid+1)*sizeof(int));
  name_par=(int *)malloc((npar+1)*sizeof(int));
  kidgen=(Geno **)malloc((nkid+1) * sizeof(Geno *));
  pargen=(Geno **)malloc((npar+1) * sizeof(Geno *));
  kidcyt=(int **)malloc((nkid+1) * sizeof(int *));
  parcyt=(int **)malloc((npar+1) * sizeof(int *));
  for (i=1; i<=nkid; i++) 
    {
      kidgen[i]=(Geno *)malloc((nloc-cyt+1) * sizeof(Geno));
      kidcyt[i]=(int *)malloc((cyt+1) * sizeof(int));
    }
  for (i=1; i<=npar; i++) 
    {
      pargen[i]=(Geno *)malloc((nloc-cyt+1) * sizeof(Geno));
      parcyt[i]=(int *)malloc((cyt+1) * sizeof(int));
    }


  read_gen_dat_pater(npar, name_par, pargen, parcyt, nkid, name_mum, name_kid, kidgen, kidcyt, nloc, cyt);


  /* Counts number of mothers (nm)[does not work] and max number of offspring per mother (c) */
  /*   mum=0; */
  /*   nm=0; */
  /*   for (i=1; i<=nkid-1; ++i) { */
  /*     for (j=i+1; j<=nkid; ++j) { */
  /*       if (name_mum[i]==name_mum[j]) nm+=1; /*FAUX*/ 
  /*     } */
  /*   } */
  /*   printf("\n nb mere %d\n", nm); */


  c=0;
  for (i=1; i<=npar; ++i) {
    m=0;
    for (j=1; j<=nkid; ++j) if (name_par[i]==name_mum[j]) m+=1;
    if (m > c) c=m;  
  }


  /* Print parameters */
  printf("Number of mothers: %d",nm);
  printf("\nMaximum number of offspring per mother: %d", c); 
  printf("\nNumber of other adults: %d", npar-nm);
  printf("\nNumber of loci: %d", nloc);
  printf("\nMaximum number of alleles per locus: %d", valmax_int(nall, nloc-cyt));
  printf("\nAdult density: %f\n", d);


  if ( g != NULL)  {
  fprintf(g, "Number of mothers: %d", nm);
  fprintf(g, "\nMaximum number of offspring per mother: %d", c); 
  fprintf(g, "\nNumber of other adults: %d", npar-nm);
  fprintf(g, "\nNumber of loci: %d", nloc);
  fprintf(g, "\nMaximum number of alleles per locus: %d", valmax_int(nall, nloc-cyt));
  fprintf(g, "\nAdult density: %f\n", d);
  } 


  /* Create the genotype / coordinate data file for twogener, first the mothers and their offspring, then other adults*/
  mum=0;
  for (i=1; i<=nkid; ++i) {
    if (name_mum[i]!=mum) {
      for (j=1; j<=npar; ++j) {
        if (name_mum[i]==name_par[j]) {
          for (k=1; k<=nparc; ++k) {
            if (name_par[j]==name_parc[k]) {
              fprintf(g, "%d\t0",name_par[j]);
              for (l=1; l<=nloc; ++l) {
                if (pargen[j][l].g1==-5) pargen[j][l].g1=0;
                if (pargen[j][l].g2==-5) pargen[j][l].g2=0;
                fprintf (g, "\t%d\t%d", pargen[j][l].g1, pargen[j][l].g2);
              }
              fprintf(g, "\t%f %f\n",x[k], y[k]);
            } 
          }
        }
      }
    }
    fprintf(g, "%d\t%d", name_mum[i], name_kid[i]);
    for (l=1; l<=nloc; ++l) {
      if (kidgen[i][l].g1==-5) kidgen[i][l].g1=0;
      if (kidgen[i][l].g2==-5) kidgen[i][l].g2=0; 
      fprintf (g, "\t%d\t%d", kidgen[i][l].g1, kidgen[i][l].g2);
    }
    fprintf(g, "\n");
    mum=name_mum[i];
  }
  
  for (i=1; i<=npar; ++i) {
    m=0;
    for (j=1; j<=nkid; ++j) if (name_par[i]==name_mum[j]) m+=1;
    if (m==0)
      for (k=1; k<=nparc; ++k) {
        if (name_par[i]==name_parc[k]) {
          fprintf(g, "%d\t0",name_par[i]);
          for (l=1; l<=nloc; ++l) fprintf (g, "\t%d\t%d", pargen[i][l].g1, pargen[i][l].g2);
          fprintf(g, "\t%f\t%f\n",x[k], y[k]);
        } 
      }
  }
  
  fclose(f);
  fclose(g);
  return(0); 


}



