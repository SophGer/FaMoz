/**************************************************************************************
  16/5/01 
  The alea library contains programs to produce random numbers, and to generate gametes
 *************************************************************************************/


/* G�n�rateur de nombre al�atoires ]0;1[ de Numerical Recipies, chapitre 7 page 283 */
/* ran3 has one nice feature: if your machine is poor on integer arithmetic (i.e., is limited  */
/* to 16-bit integers), you can declare mj, mk, and ma[] as float, define mbig and  */
/* mseed as 4000000 and 1618033, respectively, and the routine will be rendered  */
/* entirely floating-point.  */

#define MBIG 1000000000 
#define MSEED 161803398 
#define MZ 0 
#define FAC (1.0/MBIG) 

/* According to Knuth, any large MBIG, and any smaller (but still large) MSEED can be substituted  */
/* for the above values. */
 
float ran3(long *idum) 
/* Returns a uniform random deviate between 0:0 and 1:0. Set idum to any negative value to  */
/* initialize or reinitialize the sequence.  */
{ 
  static int inext,inextp; 
  static long ma[56];                /* The value 56 (range ma[1..55]) is special and  */
  static int iff=0;                  /*  flows by Schrage's method. */
  long mj,mk; 
  int i,ii,k;
 
  if (*idum < 0 || iff == 0) {       /* Initialization.  */
    iff=1; 
    mj=labs(MSEED-labs(*idum));      /* Initialize ma[55] using the seed idum and the */ 
    mj %= MBIG;                      /* large number MSEED*/
    ma[55]=mj; 
    mk=1; 
    for (i=1;i<=54;i++) {            /*  Now initialize the rest of the table, */ 
      ii=(21*i) % 55;                /*  in a slightly random order,  */
      ma[ii]=mk;                     /* with numbers that are not especially random.  */
      mk=mj-mk; 
      if (mk < MZ) mk += MBIG; 
      mj=ma[ii]; 
    } 
    for (k=1;k<=4;k++)               /*  We randomize them by " warming up the gener-  */
      for (i=1;i<=55;i++) {          /* -ator */
	ma[i] -= ma[1+(i+30) % 55]; 
	if (ma[i] < MZ) ma[i] += MBIG; 
      }
    inext=0;                         /*  Prepare indices for our first generated number.  */
    inextp=31;                       /*  The constant 31 is special; see Knuth */ 
    *idum=1; 
  } 
  /* Here is where we start, except on initialization.  */
  if (++inext == 56) inext=1;        /* Increment inext and inextp, wrapping around  */
  if (++inextp == 56) inextp=1;      /* 56 to 1.  */
  mj=ma[inext]-ma[inextp];           /*  Generate a new random number subtractively.  */
  if (mj < MZ) mj += MBIG;           /*  Be sure that it is in range.  */
  ma[inext]=mj;                      /* Store it,  */
  return mj*FAC;                     /* and output the derived uniform deviate.  */
}  

float alea() /*Il suffit d'appeler alea() pour avoir un al�atoire [0;1]*/
{
  long i=1;
  float rand;
  rand=ran3(&i);
  return rand;
 }

/************* Gametes generator *********************/

/* Codominant markers, using mendelian inheritance */

void gamete(gen, gam, nl, na, Es, nc, nac, genc) 
     Geno *gen; 
     int *gam, nl, *na, nc, *nac, *genc;     /* tirage mend�lien d'un gam�te avec erreur de g�notype possible */
     double Es;
{
  int j, i,all ; 
  float seg, err;
  for (j=1; j<=nl-nc; ++j)
    {
      seg = alea()  ;       /* Nombre al�atoire ]0,1[ qui d�termine le tirage de l'un ou l'autre all�le */
      err = alea()  ;       /* Nombre al�atoire ]0,1[ qui d�termine l'erreur de g�notypage */
      if (err <= Es) 
	{
	  all = 1+(int)(na[j]*alea()); /* tirage al�atoire d'un all�le parmi les nall[j] du locus j*/
	  gam[j] = all ;  
	}
      else  if (seg < 0.5)   gam[j]  = gen[j].g1 ;
      else  if (seg >= 0.5)  gam[j]  = gen[j].g2 ;
    }
  if (nc > 0) 
    {
      for (i=nl-nc+1; i<=nl; ++i)       
	{
	  err = alea()  ;       /* Nombre al�atoire ]0,1[ qui d�termine l'erreur de g�notypage */
	  if (err <= Es) 
	    {
	      all = 1+(int)(nac[i-nl+nc]*alea()); /* tirage al�atoire d'un all�le parmi les nall[j] du locus j*/
	      gam[i] = all ;  
	    }
	  else gam[i] = genc[i-nl+nc] ; /*because genc, cytoplasmic data is stored from 1 to nc */
	}
    }
}

/* Codominant markers, using random mating */

void gamete_hp(gam, nl, na, fcum1, nc, nac, fcum2) 
     int *gam, nl, *na, *nac, nc; 
     double **fcum1, **fcum2;     
     /* tirage mend�lien d'un gam�te dans la population (hors parcelle) */
{
  int i, j, k, all ; 
  float tir;
  for (j=1; j<=nl-nc; ++j)
    {
      tir = alea()  ;       
      /* Nombre al�atoire ]0,1[ qui d�termine le tirage d'un all�le selon sa fr�quence */
      /*  printf("\n locus : %d, alea : %f freq cumul�es : \n",j,tir); */
      for (i=1;i<=na[j];++i) 
	{
	  /* printf(" %.2f ",fcum[j][i]);  */
	  if (tir > fcum1[j][i-1] && tir <= fcum1[j][i]) all=i;
	}
      gam[j] = all ; 
    }
  if (nc > 0)
    for (i=nl-nc+1; i<=nl; ++i) 
      {
	tir = alea()  ;       
	for (k=1; k<=nac[i-nl+nc]; ++k) if (tir > fcum2[i-nl+nc][k-1] && tir <= fcum2[i-nl+nc][k]) all=k;
	gam[i] = all ; 
      }       
}

/* Dominant markers, using mendelian inheritance */

void gamete_dom(gen, gam, genc, nl, Es, pf1, nc, nac)
     int *gen,*gam, *genc, nl, nc, *nac; 
     double Es,*pf1;    
     /* tirage al�atoire de l'all�le pr�sence ou absence de bande selon le g�notype des parent,erreur de g�notype possible */
{
  int i, j, all;
  float a2, a3, seg, err; 
  double p ;
  for (j=1; j<=nl-nc; ++j)
    {
      err = alea()  ;       /* Nombre al�atoire ]0,1[ qui d�termine l'erreur de g�notypage */
      p = pf1[j]; /* fr�quence de la bande*/
      if (err <= Es)
	{
	  a3 = alea();
	  if (a3 <= 0.5)   gam[j]  = 1 ;
          else  if (a3 > 0.5)  gam[j]  = 0 ;  
	} 
      /* en cas d'erreur : on d�cr�te la bande pr�sente de fa�on arbitraire : pr�sence ou absence �quiprobables*/
      if (gen[j]==0) gam[j]=0;
      else  if (gen[j]==1)  
	{
	  a2 = alea();
	  if (a2 <= (p/(2-p))) gam[j]=1; /* le parent est homozygote 1 1 avec une proba p�/(2pq+p�)=p/(2-p)*/
	  else 
	    {
	      seg = alea();           /* le parent est h�t�rozygote : il donne 1 ou 0 avec une proba 1/2*/
	      if (seg < 0.5)   gam[j]  = 0 ;
	      else  if (seg >= 0.5)  gam[j]  = 1 ;
	    }
	}
      else if (gen[j]==(-5)) 
	{
	  a3 = alea();   /* si donn�e manquante, tirage en fonction de la fr�quence de la bande*/
	  if (a3 <= p)   gam[j]  = 1 ;
	  else  if (a3 > p)  gam[j]  = 0 ; 
	}                         
    }
  if (nc > 0)	
    {
      for (i=nl-nc+1; i<=nl; i++)
	{
	  err = alea()  ;       /* Nombre al�atoire ]0,1[ qui d�termine l'erreur de g�notypage */
	  if (err <= Es) 
	    {
	      all = 1+(int)(nac[i-nl+nc]*alea()); /* tirage al�atoire d'un all�le parmi les nall[j] du locus j*/
	      gam[i] = all ;  
	    }
	  else gam[i] = genc[i-nl+nc] ;
	}
    }
}

/* Dominant markers, using random mating */

void gamete_hp_dom(gam, nl, pf1, nc, nac, fcum)
     int *gam, nl, nc, *nac; 
     double *pf1, **fcum;    
     /* tirage al�atoire de l'all�le pr�sence ou absence de bande selon la fr�quence dans la pop */
{
  int i, j, k, all; 
  float a3, tir; 
  double p ;
  for (j=1; j<=nl-nc; ++j)
    {
      p = pf1[j]; /* fr�quence de la bande*/
      a3 = alea();   /*  tirage en fonction de la fr�quence de la bande*/
      if (a3 <= p)   gam[j]  = 1 ;
      else  if (a3 > p)    gam[j]  = 0 ; 
      /*  printf("\n alea : %.3f, fr�q : %.3f, gam�te : %d \n",a3, p, gam[j]); */
    }
  if (nc > 0)
    for (i=nl-nc+1; i<=nl; ++i) 
      {
	tir = alea()  ;       
	for (k=1; k<=nac[i-nl+nc]; ++k) if (tir > fcum[i-nl+nc][k-1] && tir <= fcum[i-nl+nc][k]) all=k;
	gam[i] = all ; 
     }                         
}
