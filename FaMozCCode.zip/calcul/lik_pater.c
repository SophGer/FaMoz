#include <math.h>
#include <stdio.h>
#include "nrutil.h"
#include "read.h"
#include "sort.h"
#include "genetic.h"
#include "likely.h"

/**************************************************************************

Program to tabulate possible parent pairs, and log-likelihoods, for given
sets of juveniles, potential fathers, and potential mothers.
Ordered to find best 4 mums, best 4 dads, best 4 pairs.
Includes possibility of X-linked loci.

Modified from earlier programs; July 1996

Programme modifi� pour consid�rer des hermaphrodites, et int�grer possibles 
autof�condations 25/11/98

*** Pourcentage d'erreur ajout� dans les calculs 26/11/98
(inspir� de Marshall et al 1998)
utilis� en lan�ant le programme suivi de < fichier
le fichier contient 
nb_loc nb_all_loc1  freq_all1_loc1 freq_all2_loc2.... nb_all_loc2  etc...
nb_parents nb_desc
nom_parent1 all1_loc1 all2_loc1 etc... 
nom_m�re_du_desc nom_desc all1_loc1 all2_loc1 etc... 
le fichier likh est un fichier d'exemple pour ce programme
Donne les 8 meilleurs p�res  dans l'ordre.

Modifi� le 18/12/98 pour prendre les log 
de la vraisemblance

28/7/99 Calcul des lod-scores de paternit�, avec donn�es manquantes 
entrainant la non prise en compte du locus dans le calcul.

***************************************************************************/

extern double rans();
extern double log();


main (int argc, char *argv[])
{  
  int nloc, *nall, cyt, cytmater, *nallc, miss;
  double **pf, **pfc, E, F;	         /* loci details; prior freqs; fr�quences cumul�es*/
  /* E genotype error in the lod calculation*/
  int nkid,npar, nb;			 /*number of kids, parents, best displayed*/
  int  *name_kid, *name_par, *name_mum, **kidcyt, **parcyt;            /* individual names etc. */
  Geno **kidgen, **pargen; 	/* genotypic data */
  int i,j,k,ii, mere; 
  int npod; 
  double  *best_dads, *miss_dad, *missm_dad, *loclod, *delta, deltamax; 
  /* nb missing data and missmatch for each dad and dad/offsp and number of loci with no missing data*/
  double *score, cc, bc;

  /* read arguments*/

  E=atof(argv[1]); 
  nb=atof(argv[2]);
  cyt=atoi(argv[3]);
  cytmater=atoi(argv[4]);
  F=atof(argv[5]); 
  miss=atoi(argv[6]); 

  /* Lecture des donn�es locus */
  scanf ("%d", &nloc);
  nall=(int *)malloc((nloc-cyt+1)*sizeof(int));
  if (cyt > 0) nallc=(int *)malloc((cyt+1)*sizeof(int));
  read_loci (nloc, nall, &pf, cyt, nallc, &pfc);

  printf("\n Number of loci %d",nloc);
  printf("\n Among them, number of cytoplasmic markers: %d",cyt);
  scanf ("%d %d", &npar, &nkid);
  printf ("\n Number of parents: %d offspring: %d\n", npar,nkid);
  printf("\n Lod calculation error: %f, Heterozygote deficit %f", E, F); 
  printf("\n Number of best fathers displayed: %d\n", nb); 
  
  printf("\n For each offspring and each likely father: \n"); 
  printf("  Kid n� / mother / likely father / lod score / delta");
  printf("\n  Nb of missing locus in father / nb of loci with a > 0 contribution in score ");
  printf("\n   / nb of father-offspring mismatch among them \n");
   
  name_kid=(int *)malloc((nkid+1)*sizeof(int));
  name_mum=(int *)malloc((nkid+1)*sizeof(int));
  name_par=(int *)malloc((npar+1)*sizeof(int));
  kidgen=(Geno **)malloc((nkid+1) * sizeof(Geno *));
  pargen=(Geno **)malloc((npar+1) * sizeof(Geno *));
  score=(double *)malloc((nb+2)*sizeof(double));
  delta=(double *)malloc((nb+2)*sizeof(double));
  best_dads=(double *)malloc((nb+2)*sizeof(double));
  miss_dad=(double *)malloc((nb+2)*sizeof(double));
  missm_dad=(double *)malloc((nb+2)*sizeof(double));
  loclod=(double *)malloc((nb+2)*sizeof(double));
  kidcyt=(int **)malloc((nkid+1) * sizeof(int *));
  parcyt=(int **)malloc((npar+1) * sizeof(int *));

  for (i=1; i<=nkid; i++) {
      kidgen[i]=(Geno *)malloc((nloc-cyt+1) * sizeof(Geno));
      kidcyt[i]=(int *)malloc((cyt+1) * sizeof(int));
    }
  for (i=1; i<=npar; i++) {
      pargen[i]=(Geno *)malloc((nloc-cyt+1) * sizeof(Geno));
      parcyt[i]=(int *)malloc((cyt+1) * sizeof(int));
    }
  read_gen_dat_pater (npar, name_par, pargen, parcyt, nkid, name_mum, name_kid, kidgen, kidcyt, nloc, cyt);
  
  /*for (i=1;i<=3;++i) { printf("\n nom parent : %d",name_par[i]);  print_geno(pargen[i], nloc);}     */
  /*i=npar;   printf("\n nom parent : %d",name_par[i]);  print_geno(pargen[i], nloc);    */
  /*for (i=1;i<=3;++i) { printf("\n nom enfant : %d",name_kid[i]);  print_geno(kidgen[i], nloc);     */
  /*printf("\n nom de sa m�re : %d",name_mum[i]); }      */
  
  for (i=1; i<=nkid; ++i)
    {
      printf ("\n kid %d :", name_kid[i] );
      printf(" (%.0f missing data on %d alleles)", missing(kidgen[i], nloc-cyt), 2*(nloc-cyt));  
      for (ii=1;ii<=npar;++ii) 
	{
	  if (name_par[ii]==name_mum[i]) mere=ii; 
	}	    
      k=(nloc-cyt-match1 (kidgen[i], pargen[mere], nloc-cyt));
      if (k>0) printf("\n !! Kid %d has %d missmatch/es with his mother %d !! ", name_kid[i], k, name_par[mere]);
      npod=0; bc=1.0E6;
      for (k=0; k< nb+1; ++k){
	best_dads[k] =0; 
	delta[k]=0.0;
	score[k]=0.0;
	miss_dad[k] =0; 
	missm_dad[k] =0; 
	loclod[k] =0;
      }
      for (j=1; j<=npar; ++j){
	cc = pater(kidgen[i], pargen[mere], pargen[j], nloc-cyt, pf, E, F, nall, miss); 
	/* 	  cc = pater(kidgen[i], pargen[mere], pargen[j], nloc-cyt, pf, E, F); */
	if (cyt > 0 && cytmater==0) cc+=likr_pat_cyt(cyt, kidcyt[i], parcyt[j], pfc, E, nallc);
	/*printf("\n enfant : %d et g�notype\n", name_kid[i]);       */
	/*print_geno(kidgen[i], nloc);      */
	/*printf("\nmere %d \n",name_par[mere]);       */
	/*print_geno(pargen[mere], nloc);    */
	/*printf("\n p�re possible : %d\n",name_par[j]);       */
	/*print_geno(pargen[j], nloc);      */
	if (cc > 0.0 && finite(cc)==1) { 
	  ++npod;
	  if (npod < nb+1) {
	    best_dads[npod] = name_par[j]; 
	    score[npod]=cc; 
	    miss_dad[npod]=missing(pargen[j], nloc-cyt);
	    missm_dad[npod]=match2(kidgen[i], pargen[mere], pargen[j], nloc-cyt);
	    loclod[npod]=loc_lod_pater(kidgen[i], pargen[mere], pargen[j], nloc-cyt, pf, E, F, nall, miss);
	    if (cc < bc)  bc = cc; 
	  } 
	  else {
	    if (cc > bc) {
	      k = dexmin(score, nb);
	      best_dads[k] = name_par[j];
	      score[k] = cc;
	      miss_dad[k]=missing(pargen[j], nloc-cyt);
	      missm_dad[k]=match2(kidgen[i], pargen[mere], pargen[j], nloc-cyt);
	      loclod[k]=loc_lod_pater(kidgen[i], pargen[mere], pargen[j], nloc-cyt, pf, E, F, nall, miss);
	      bc = valmin(score, nb); 
	    }
	  }
	}/* printf ("\n pc: %f \t",pc); */ 
      }
      
      
      sort5(nb,score,best_dads,miss_dad, missm_dad, loclod);			
      deltamax=score[nb];
      for (k=nb; k>=1; --k){ if (k==nb) delta[k]=deltamax; else if (k<nb && score[k]>0) delta[k]=deltamax-score[k];}
      
      printf (" %d likely fathers", npod); 
      if  (npod > 0 ) { 
	if(npod > nb) 
	  for (k=nb; k>=1; k--) { 
	    printf ("\n  %d \t %d \t  %.0f \t %.2f \t %.2f \t", name_kid[i], name_mum[i], best_dads[k], score[k], delta[k]);  
	    printf ("%.0f/%.0f/%.0f ", miss_dad[k], loclod[k], nloc-missm_dad[k]);   
	  } 
	else for (k=nb; k>=nb-npod+1; k--) { 
	  printf ("\n  %d \t %d \t  %.0f \t %.2f \t %.2f \t", name_kid[i], name_mum[i] , best_dads[k], score[k], delta[k]);  
	  printf ("%.0f/%.0f/%.0f ", miss_dad[k], loclod[k], nloc-missm_dad[k]);   
	} 
      } 
      printf ("\n");
      
      fflush(stdout);       
    }
  printf ("\n");
  
  return(0);
}


