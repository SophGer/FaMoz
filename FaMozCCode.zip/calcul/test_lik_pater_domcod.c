#include <math.h>
#include <stdio.h>
#include "nrutil.h"
#include "read.h"
#include "sort.h"
#include "genetic.h"
#include "likely.h"

/**************************************************************************
14/2/02 Paternity analysis for both dom and codom markers
22/1/03 test for paternity
gives a list of all father with a lod score greater than SEUIL_P
***************************************************************************/

extern double rans();
extern double log();


main (int argc, char *argv[])
{  
  int nloc, nlocd, *nall, cyt, *nallc, cytmater, nb_off_fath, *fath, miss, test_type;
  double **pf, **pfc, *pfd, E, F, SEUIL_P, SEUIL_d;	         /* loci details; prior freqs; fr�quences cumul�es*/
  /* E genotype error in the lod calculation*/
  int nkid,npar, nb;			 /*number of kids, parents, best displayed*/
  int  *name_kid, *name_par, *name_mum, **kidcyt, **parcyt, **kidgend, **pargend;            /* individual names etc. */
  Geno **kidgen, **pargen; 	/* genotypic data */
  int i,j,k,ii,jj,kk, mere; 
  int npod; 
  double  *best_dads, *miss_dad, *missm_dad, *loclod, *delta, deltamax; 
  /* nb missing data and missmatch for each dad and dad/offsp and number of loci with no missing data*/
  double *score, cc, bc;
  FILE *f;

  /* read arguments*/

  E=atof(argv[1]); 
  nb=atoi(argv[2]);
  cyt=atoi(argv[3]);
  cytmater=atoi(argv[4]);
  F=atof(argv[5]); 
  miss=atoi(argv[6]);
  test_type=atoi(argv[7]); /* test type 1: test on lod scores 2: test on delta 3: test on both values*/
  if (test_type==1)
    SEUIL_P=atof(argv[8]);  /* Lod-score threshold to choose a father as the true one */
  else if  (test_type==2)
    SEUIL_d=atof(argv[8]);  /* Delta threshold to choose a father as the true one */
  else if  (test_type==3){
    SEUIL_P=atof(argv[8]);  /* Lod-score threshold to choose a father as the true one */
    SEUIL_d=atof(argv[9]);  /* Delta threshold to choose a father as the true one */
  }

  /* Lecture des donn�es locus */
  scanf ("%d", &nloc);
  nall=(int *)malloc((nloc-cyt+1)*sizeof(int));
  if (cyt > 0) nallc=(int *)malloc((cyt+1)*sizeof(int));
  read_loci (nloc, nall, &pf, cyt, nallc, &pfc);
  scanf ("%d", &nlocd);
  pfd=(double *)malloc((nlocd+1) * sizeof(double));
  read_loci_dom (nlocd, 0, nallc, pfd, &pfc);

  printf("\n Number of loci, codominant: %d, dominant: %d, cytoplasmic %d",nloc-cyt, nlocd, cyt);  
  scanf ("%d %d", &npar, &nkid);
  printf ("\n Number of parents: %d offspring: %d\n", npar,nkid);
  printf("\n Lod calculation error: %f, Heterozygote deficit %f\n", E, F); 
  if (test_type==1) 
    printf("\n Lod-score threshold to choose a father as the true one = %.2f ", SEUIL_P);
  else if (test_type==2) 
    printf("\n Delta threshold to choose a father as the true one = %.2f ", SEUIL_d);
  else if (test_type==3) 
    printf("\n Thresholds to choose a father as the true one Lod-score = %.2f Delta = %.2f\n", SEUIL_P, SEUIL_d);
  printf("\n Number of best fathers displayed: %d\n", nb); 
  printf(" For each likely father: \n"); 
  printf("\n  Nb of missing locus / nb of loci with a > 0 contribution in score ");
  printf("\n   / nb of father-offspring mismatch among them \n");
   
  name_kid=(int *)malloc((nkid+1)*sizeof(int));
  name_mum=(int *)malloc((nkid+1)*sizeof(int));
  name_par=(int *)malloc((npar+1)*sizeof(int));
  kidgen=(Geno **)malloc((nkid+1) * sizeof(Geno *));
  pargen=(Geno **)malloc((npar+1) * sizeof(Geno *));
  kidgend=(int **)malloc((nkid+1) * sizeof(int *));
  pargend=(int **)malloc((npar+1) * sizeof(int *));
  score=(double *)malloc((nb+2)*sizeof(double));
  delta=(double *)malloc((nb+2)*sizeof(double));
  best_dads=(double *)malloc((nb+2)*sizeof(double));
  miss_dad=(double *)malloc((nb+2)*sizeof(double));
  missm_dad=(double *)malloc((nb+2)*sizeof(double));
  loclod=(double *)malloc((nb+2)*sizeof(double));
  kidcyt=(int **)malloc((nkid+1) * sizeof(int *));
  parcyt=(int **)malloc((npar+1) * sizeof(int *));
  fath=(int *)malloc((nkid+1) * sizeof(int));

  for (i=1; i<=nkid; i++) 
    {
      fath[i]=0;
      kidgen[i]=(Geno *)malloc((nloc-cyt+1) * sizeof(Geno));
      kidcyt[i]=(int *)malloc((cyt+1) * sizeof(int));
      kidgend[i]=(int *)malloc((nlocd+1) * sizeof(int));
    }
  for (i=1; i<=npar; i++) 
    {
      pargen[i]=(Geno *)malloc((nloc-cyt+1) * sizeof(Geno));
      parcyt[i]=(int *)malloc((cyt+1) * sizeof(int));
      pargend[i]=(int *)malloc((nlocd+1) * sizeof(int));
    }
  read_gen_dat_pater_domcod (npar, name_par, pargen, pargend, parcyt, nkid, name_mum, name_kid, kidgen, kidgend, kidcyt, nloc, nlocd, cyt);

  f = fopen ("resfath", "w");  
  printf("\n ***** Compact results will be given in file \"resfath\"\n");
  printf("\t\t\t  (Number of observations at the end of the file)\n");
  nb_off_fath=0; 
  
  for (i=1; i<=nkid; ++i)
    {
      printf ("\n kid %d :", name_kid[i] );
      printf(" (%.0f missing data on %d alleles)\n", missing(kidgen[i], nloc-cyt), 2*(nloc-cyt));  
      for (ii=1;ii<=npar;++ii) 
	{
	  if (name_par[ii]==name_mum[i]) mere=ii; 
	}	    
      k=(nloc-cyt-match1 (kidgen[i], pargen[mere], nloc-cyt));
      if (k>0) printf(" !! Kid %d has %d codominant missmatch/es with his mother %d !! \n", name_kid[i], k, name_par[mere]);
      npod=0; bc=1.0E6;
      for (k=0; k< nb+1; ++k)
	{
	  best_dads[k] =0; 
	  score[k]=0.0;
	  delta[k]=0.0;
	  miss_dad[k] =0; 
	  missm_dad[k] =0; 
	  loclod[k] =0;
	}
      for (j=1; j<=npar; ++j)
	{
 	  cc = pater(kidgen[i], pargen[mere], pargen[j], nloc-cyt, pf, E, F, nall, miss); 
	  cc += pater_dom((nlocd), kidgend[i],pargend[mere],pargend[j], pfd, E, F); /* proba father:non father*/
 	  if (cyt > 0 && cytmater==0) cc+=likr_pat_cyt(cyt, kidcyt[i], parcyt[j], pfc, E, nallc);
	  if (cc > 0.0 && finite(cc)==1) 
	    { 
	      ++npod;
	      if (npod < nb+1) 
		{
		  best_dads[npod] = name_par[j]; 
		  score[npod]=cc; 
		  miss_dad[npod]=missing(pargen[j], nloc-cyt);
		  missm_dad[npod]=match2(kidgen[i], pargen[mere], pargen[j], nloc-cyt);
		  loclod[npod]=loc_lod_pater(kidgen[i], pargen[mere], pargen[j], nloc-cyt, pf, E, F, nall, miss);
		  loclod[npod]+=loc_lod_pater_dom(nlocd, kidgend[i], pargend[mere], pargend[j], pfd, E, F);
		  if (cc < bc)  bc = cc; 
		} 
	      else
		{
		  if (cc > bc) 
		    {
		      k = dexmin(score, nb);
		      best_dads[k] = name_par[j];
		      score[k] = cc;
		      miss_dad[k]=missing(pargen[j], nloc-cyt);
		      missm_dad[k]=match2(kidgen[i], pargen[mere], pargen[j], nloc-cyt);
		      loclod[k]=loc_lod_pater(kidgen[i], pargen[mere], pargen[j], nloc-cyt, pf, E, F, nall, miss);
		      loclod[k]+=loc_lod_pater_dom(nlocd, kidgend[i], pargend[mere], pargend[j], pfd, E, F);
		      bc = valmin(score, nb); 
		    }
		}
	    }/* printf ("\n pc: %f \t",pc); */ 
	}
      
      
      sort5(nb,score,best_dads,miss_dad, missm_dad, loclod);			
      deltamax=score[nb];
      for (k=nb; k>=1; --k){ if (k==nb) delta[k]=deltamax; else if (k<nb && score[k]>0) delta[k]=deltamax-score[k];}

     /* Affichage */
      jj=0;
      kk=0;
      for (k=nb; k>=1; --k) {
	if (test_type==1){
	  if (score[k] > SEUIL_P) {
	    ++jj;
	    printf ("\tLikely father n� %d: %5.0f\tscore:  %5.2f",jj, best_dads[k], score[k]);
	    printf ("\t %3.0f/%3.0f/%3.0f", miss_dad[k], loclod[k], missm_dad[k]);  printf ("\n"); 
	    if (kk==0)  { fath[i] = best_dads[k]; kk+=1;} 
	  }
	}  
	else if (test_type==2){
	  if (delta[k] > SEUIL_d) {
	    ++jj;
	    printf ("\tLikely father n� %d: %5.0f\tdelta:  %5.2f",jj, best_dads[k], delta[k]);
	    printf ("\t %3.0f/%3.0f/%3.0f", miss_dad[k], loclod[k], nloc-cyt-missm_dad[k]);  printf ("\n"); 
	    if (kk==0)  { fath[i] = best_dads[k]; kk+=1;} 
	  }
	}
	else if (test_type==3){
	  if (score[k] > SEUIL_P && delta[k] > SEUIL_d) {
	    ++jj;
	    printf ("\tLikely father n� %d: %5.0f\tlod score:  %5.2f\tdelta:  %5.2f",jj, best_dads[k], score[k],delta[k]);
	    printf ("\t %3.0f/%3.0f/%3.0f", miss_dad[k], loclod[k], nloc-cyt-missm_dad[k]);  printf ("\n"); 
	    if (kk==0)  { fath[i] = best_dads[k]; kk+=1;} 
	  }
	}  

      if (jj!=0)  nb_off_fath+=1;  
      if (jj==0)  
	{
	  printf ("\tNo likely father inside the stand\n");	      
	}
      fflush(stdout);          
      }
    }
  printf("\n Among %d offspring, %d have one father among the genotyped one", nkid, nb_off_fath);
  printf ("\n");

  for (i=1; i<=nkid; i++) 
    if ( f != NULL && fath[i]!=0) fprintf (f, "\n %d %d", name_kid[i], fath[i]);
  if ( f != NULL) fprintf (f, "\n %d ", nb_off_fath);  

  fclose(f);
  return(0);
}


