#include <math.h>
#include <stdio.h>
/* #include <time.h> */  /* pour initialiser le g�n�rateur de nombres al�atoires*/
#include <sys/time.h>
#include <unistd.h>
#include <stdlib.h>     
#include "nrutil.h"
#include "read.h"
#include "sort.h"
#include "alea.h"
#include "genetic.h"
#include "likely.h"


/**************************************************************************

09/01
Simulation of offspring with codominant, dominant and cytoplasmic markers,
looking for most likely parents/parent pairs

***************************************************************************/



extern double rans();
extern double log();


main (int argc, char *argv[])
{  
  char *name1, *name2, *name3, *name4, *name5, *name6;
  int nloc, nlocd, *nall, cyt, *nallc, miss;          /* number of alleles*/
  double **pf, **fcum, *pfd, **pfc, **fcumc;	         /* loci details; prior freqs; fr�quences cumul�es */
  int nkid, nkid1, npar, **kidgend, **pargend;			 /*number of kids, parents */
  int  *name_kid, *name_par, **parcyt, **kidcyt, cytmater;            /* individual names etc. */
  Geno **kidgen, **pargen; 	/* genotypic data */
  Geno *kidpar;                        /* nom des vrais parents du descendant*/
  int **dadgam, **mumgam, **dadgamd, **mumgamd;      /* Gam�tes paternel et paternel cod / dom*/
  int i,j,k,ii,jj, kk,iii, jjj,tp1,tp2, mum, dad, io; 
  int npop, *listp, npopp,bdc,mdc,bdp,mdp,bp, bc1,bc2;
  double  best_dads[10],  best_pars[10], best_pairs[2][10];
  double score[10], pcore[10], cc, bc, pc, E, Es, F, f, bdcf, bdpf;
  double *bestp1, *bestp2, *bestp, *bestc, x, y;
  /* the previous  two lines are for creating an histogram of best parents and couple of simulated offspring */
  double *deltatrue, *deltawrong, *deltawrongi, *deltawrongo1,*deltawrongo2 , deltamax, delta1, delta2;
  double *deltatrueC, *deltawrongC, *deltawrongiC, *deltawrongo1C,*deltawrongo2C;
  
  /* initialisation du g�n�rateur de nombres al�atoires :*/
  long m;
  float rand;
  struct timeval temps; 
  struct timezone  zone;
  gettimeofday(&temps,&zone);
  m=-temps.tv_usec; 
  rand=ran3(&m);
  
  /* Reading arguments */
  nkid=atoi(argv[1]);
  E=atof(argv[2]); 
  Es=atof(argv[3]);
  cyt=atoi(argv[4]);
  cytmater=atoi(argv[5]);
  io=atoi(argv[6]); 
  /* if io==1 pick gametes among genotyped individuals, if io==2, pick gametes randomly according to allele frequencies */
  F=atof(argv[7]); 
  miss=atoi(argv[8]);
  
  name1 = "Single parent";
  name2 = "Parent pair";
  name3 = "Delta, true parents";
  name4 = "Delta, true parent pairs";
  name5 = "Delta, wrong parents";
  name6 = "Delta, wrong parent pairs";
  
  /* Lecture des donn�es locus */
  scanf ("%d", &nloc);
  nall=(int *)malloc((nloc-cyt+1)*sizeof(int));
  if (cyt > 0) nallc=(int *)malloc((cyt+1)*sizeof(int));
  read_loci_cum (nloc, nall, &pf, &fcum, cyt, nallc, &pfc, &fcumc);
  scanf ("%d", &nlocd);
  pfd=(double *)malloc((nlocd+1) * sizeof(double));
  read_loci_dom_cum (nlocd, 0, nallc, pfd, &pfc, &fcumc);

  printf("\n Number of loci, codominant %d, dominant %d, cytoplasmic %d",nloc-cyt, nlocd, cyt);
  scanf ("%d %d", &npar, &nkid1);
  printf ("\n Number of parents: %d number of simulated offspring: %d\n", npar,nkid);


  listp=(int *)malloc((npar+1)*sizeof(int));
  name_kid=(int *)malloc((nkid+1)*sizeof(int));
  name_par=(int *)malloc((npar+1)*sizeof(int));
  kidgen=(Geno **)malloc((nkid+1) * sizeof(Geno *));
  kidpar=(Geno *)malloc((nkid+1) * sizeof(Geno));
  kidgend=(int **)malloc((nkid+1) * sizeof(int *));
  pargend=(int **)malloc((npar+1) * sizeof(int *));
  pargen=(Geno **)malloc((npar+1) * sizeof(Geno *));
  kidcyt=(int **)malloc((nkid+1) * sizeof(int *));
  parcyt=(int **)malloc((npar+1) * sizeof(int *));

  if (io==1) j=npar;
  else if (io==2) j=nkid;

  mumgam=(int **)malloc((j+1) * sizeof(int *));
  dadgam=(int **)malloc((j+1) * sizeof(int *));
  mumgamd=(int **)malloc((j+1) * sizeof(int *));
  dadgamd=(int **)malloc((j+1) * sizeof(int *));

  for (i=1; i<=j; i++)  
    {
      dadgam[i]=(int *)malloc((nloc+1) * sizeof(int));
      mumgam[i]=(int *)malloc((nloc+1) * sizeof(int));
      dadgamd[i]=(int *)malloc((nlocd+1) * sizeof(int));
      mumgamd[i]=(int *)malloc((nlocd+1) * sizeof(int));
    }
  for (i=1; i<=nkid; i++) 
    {
      kidgen[i]=(Geno *)malloc((nloc-cyt+1) * sizeof(Geno));
      kidgend[i]=(int *)malloc((nlocd+1) * sizeof(int));
      kidcyt[i]=(int *)malloc((cyt+1) * sizeof(int));
    }

  for (i=1; i<=npar; i++)  
    {
      pargen[i]=(Geno *)malloc((nloc-cyt+1) * sizeof(Geno));
      pargend[i]=(int *)malloc((nlocd+1) * sizeof(int));
      parcyt[i]=(int *)malloc((cyt+1) * sizeof(int));
    }
  
  read_gen_dat_par_domcod(npar, name_par, nloc, nlocd, cyt, pargen, parcyt, pargend);

  printf("\n Simulation error %f, Lod calculation error %f\n",Es, E);    

  /*initialisations*/
  bdc=0; mdc=0;   bdp=0; mdp=0; iii=1; jjj=1; 
  
  /* Cr�ation de descendants*/
  printf("\n Simulation step");

  if (io==1)
    {
      for (ii=1;ii<=nkid;++ii)
	{
	  name_kid[ii]=ii;
	  mum = 1+(int)(npar*alea()) ;         /* Tirage al�atoire des deux parents : */
	  f=alea();
	  if (f<=2*F/(1+F)) dad=mum;         /*selfing at equilibrium = [2*F/(1+F)] */
	  else dad = 1+(int)(npar*alea()) ;         /* nombre entier al�atoire dans [1,npar] */ 
	  gamete(pargen[mum],mumgam[mum], nloc, nall, Es, cyt, nallc, parcyt[mum]); /* Simulation des gam�tes parentaux : */ 
	  gamete(pargen[dad],dadgam[dad], nloc, nall, Es, cyt, nallc, parcyt[dad]);
	  gamete_dom(pargend[mum],mumgamd[mum], parcyt[mum],nlocd, Es, pfd, 0, nallc); /* Simulation des gam�tes parentaux : */  
	  gamete_dom(pargend[dad],dadgamd[dad], parcyt[dad],nlocd, Es, pfd, 0, nallc); 
	  kidpar[ii].g1=name_par[mum]; 
	  kidpar[ii].g2=name_par[dad];  
	  for (jj=1;jj<=nloc-cyt;++jj)
	    {
	      kidgen[ii][jj].g1=mumgam[mum][jj];  /* ii :enfant, jj locus*/
	      kidgen[ii][jj].g2=dadgam[dad][jj];   
	    }  
	  if  (cyt > 0)
	    {
	      if (cytmater==1) for (jj=nloc-cyt+1;jj<=nloc;++jj)  kidcyt[ii][jj-nloc+cyt] = mumgam[mum][jj];  
	      else if (cytmater==0) for (jj=nloc-cyt+1;jj<=nloc;++jj)  kidcyt[ii][jj-nloc+cyt] = dadgam[dad][jj];  
	    } 
	  for (jj=1;jj<=nlocd;++jj) 
	    {
	      if (mumgamd[mum][jj] == 0 && dadgamd[dad][jj] == 0) kidgend[ii][jj] = 0;
	      else if(mumgamd[mum][jj] == 1 || dadgamd[dad][jj] == 1) kidgend[ii][jj] = 1;   
	    }    
	}
    }
  else if (io==2)
    {
      for (ii=1;ii<=nkid;++ii)
	{
	  name_kid[ii]=ii; 
	  gamete_hp(mumgam[ii], nloc, nall, fcum, cyt, nallc, fcumc); /* Simulation des gam�tes parentaux : */ 
	  gamete_hp(dadgam[ii], nloc, nall, fcum, cyt, nallc, fcumc);   
	  gamete_hp_dom(mumgamd[ii], nlocd, pfd, 0, nallc, fcumc); /* Simulation des gam�tes parentaux : */ 
	  gamete_hp_dom(dadgamd[ii], nlocd, pfd, 0, nallc, fcumc);
	  for (jj=1;jj<=cyt;++jj) parcyt[ii][jj] = 1+(int)(nallc[jj]*alea()); 
	  for (jj=1;jj<=nloc-cyt;++jj)
	    {
	      kidgen[ii][jj].g1=mumgam[ii][jj];  /* ii :enfant, jj locus*/
	      f=alea();
	      if (f<=F) kidgen[ii][jj].g2=mumgam[ii][jj];
	      else kidgen[ii][jj].g2=dadgam[ii][jj];   
	    }  
	  if  (cyt > 0)	  
	    {
	      if (cytmater==1) for (jj=nloc-cyt+1;jj<=nloc;++jj)  kidcyt[ii][jj-nloc+cyt] = mumgam[ii][jj];             
	      else if (cytmater==0) for (jj=nloc-cyt+1;jj<=nloc;++jj)  kidcyt[ii][jj-nloc+cyt] = dadgam[ii][jj];  
	    }
	  for (jj=1;jj<=nlocd;++jj)
	    {
	      f=alea();
	      if (mumgamd[ii][jj] == 0)
		{ if( f<=F || dadgamd[ii][jj] == 0) kidgend[ii][jj] = 0; }
	      else if(mumgamd[ii][jj] == 1 || dadgamd[ii][jj] == 1) kidgend[ii][jj] = 1;   
	    }  
	}
    }
  
  printf("\n End of simulation step \n");
  printf("\n Calculation step");	
  
  /* 	First allocate memory to store data: draw a histogram later thanks to them */
  
  bestp1=(double *)malloc((nkid+1)*sizeof(double));
  bestp2=(double *)malloc((nkid+1)*sizeof(double));
  bestp=(double *)malloc((2*nkid+1)*sizeof(double));
  bestc=(double *)malloc((nkid+1)*sizeof(double));	
  deltatrue=(double *)malloc((2*nkid+1)*sizeof(double));
  deltawrongi=(double *)malloc((2*nkid+1)*sizeof(double));
  deltawrongo1=(double *)malloc((nkid+1)*sizeof(double));
  deltawrongo2=(double *)malloc((nkid+1)*sizeof(double));
  deltawrong=(double *)malloc((4*nkid+1)*sizeof(double));
  deltatrueC=(double *)malloc((2*nkid+1)*sizeof(double));
  deltawrongiC=(double *)malloc((2*nkid+1)*sizeof(double));
  deltawrongo1C=(double *)malloc((nkid+1)*sizeof(double));
  deltawrongo2C=(double *)malloc((nkid+1)*sizeof(double));
  deltawrongC=(double *)malloc((4*nkid+1)*sizeof(double));
  
  for (i=1; i<=(nkid); i++)       {bestp1[i]=0.0; bestp2[i]=0.0; bestc[i]=0.0;}
  for (i=1; i<=(2*nkid); i++)	    bestp[i]=0.0;
  
  
  for (i=1; i<=nkid; ++i) {
      /*       printf ("\t%5d\t", name_kid[i]); printf ("\b\b\b\b\b\b\b\b\b\b");     */
      
      npopp=0; npop=0;  bc=1.0E6; pc = 1.0E6; /* Number Possible Parent / Pairs */
      
      /* Calcul des vraisemblances des parents pour chaque descendant */
      
      for (k=1; k< 11; ++k) 
	{
	  score[k]=0.0; 
	  best_dads[k] =0; best_pars[k] =0; pcore[k]=0.0;
	  best_pairs[0][k]=0; best_pairs[1][k]=0;
	}
      for (j=1; j<=npar; ++j)
	{
	  cc = uparchk(nloc-cyt, *(kidgen+i), pargen[j], pf, E, F, nall, miss);  /* proba maternit�:non maternit�*/
	  cc += uparchk_dom(nlocd, kidgend[i], pargend[j], pfd, E, F); /* proba maternit�:non maternit�*/
	  if (cyt > 0) cc+=likr_cyt(cyt, kidcyt[i], parcyt[j], pfc, E, nallc);
	  if (cc > 0.0 && finite(cc)==1)
	    {
	      ++npop; listp[npop]=j; /*rang de tous les parents � proba > 0,npop observations*/
	      if (npop < 9) 
		{
		  best_pars[npop] = name_par[j]; 
		  score[npop]=cc; 
		  if (cc < bc)  bc = cc;
		} /* bc sera le score min parmi les 8 premiers >0 */
	      else
		{
		  if (cc > bc) /*score sup�rieur au min pr�c�dent*/
		    {
		      k = dexmin(score, 8); /* rang du score minimum parmi les 8*/
		      best_pars[k] = name_par[j];  /*on remplace la m�re k  ...  */
		      score[k] = cc;               /* par la j, qui est meilleure */ 
		      bc = valmin(score, 8);
		    }
		}  /*nouveau score min*/
	    } 
	}                                  /* � la fin on a les 8 meilleures des nmum*/
      
      /* Ins�rer un tri sur best_pars[k] et score[k], 1<=k<=8 */
      sort2(8,score,best_pars);
      deltamax=score[8];
      delta1=deltamax;
      delta2=score[7]-deltamax;
      if(io==1) { 
	if (best_pars[8]==kidpar[i].g1 || best_pars[8]==kidpar[i].g2) {deltatrue[iii]=delta1; iii+=1;} 
	else { deltawrongi[jjj]=delta1; jjj+=1;}
	if (best_pars[7]==kidpar[i].g1 || best_pars[7]==kidpar[i].g2) {deltatrue[iii]=delta2; iii+=1;}
	else deltawrongi[jjj]=delta2; jjj+=1;}
      if (io==2) { deltawrongo1[i]=delta1; deltawrongo2[i]=delta2; }       
      /* Stocker les vraisemblances de bonne d�cision (bd) et mauvaise d�cision (md) pour les deux meilleurs parents*/
      
      for (k=8;k>=7;--k)  
	{
	  bp=best_pars[k];
	  if (bp==kidpar[i].g1 || bp==kidpar[i].g2)   
	    {
	      if (score[k]>0.000000) ++bdp; /*the two best parents are the true one*/
	    }  
	  else 
	    {
	      if (score[k]>0.000000) ++mdp; /*the two best parents are not the true one*/
	    }
	}
      k=8; bestp1[i]=score[k]  ; /* kid n�i has bestp1 and 2 as most likely parents */
      k=7; bestp2[i]=score[k]  ;

      /* 	    printf("\nscores des meilleurs parents\n"); */
      /*printf("%f\t%f\n", bestp1[i], bestp2[i]);    */
      
      
      /* Calcul des vraisemblances pour les meilleurs couples*/
      pc=1.0E6;
      for (k=1; k< 11; ++k)  score[k]=0.0; 
      for (j=1; j<=npop; ++j)
	{ 
	  tp1 = listp[j];
	  if (npop > 0)
	    {
	      for (kk=1; kk<=npop; ++kk)
		{
		  tp2 = listp[kk];
		  if (tp2>=tp1)
		    {
		      cc = pparchk(nloc-cyt, kidgen[i], pargen[tp1], pargen[tp2], pf, E, F, nall, miss);  /*dans boucle en j*/
		      cc += pparchk_dom(nlocd, kidgend[i], pargend[tp1], pargend[tp2], pfd, E, F); /*dans boucle en j*/
		      if (cyt > 0) cc+=likr_pair_cyt(cyt, kidcyt[i],parcyt[tp1],parcyt[tp2], pfc, E, nallc);
		      if (cc > 0.0 && finite(cc)==1) 
			{
			  ++npopp; 
			  if (npopp < 9) 
			    {
			      best_pairs[0][npopp] = name_par[tp1]; 
			      best_pairs[1][npopp] = name_par[tp2]; 
			      pcore[npopp]=cc; 
			      if (cc < pc)  pc = cc; 
			      } 
			  else
			    {
			      if (cc > pc) 
				{
				  k = dexmin(pcore, 8);
				  best_pairs[0][k] = *(name_par+tp1); 
				  best_pairs[1][k] = *(name_par+tp2); 
				  pcore[k] = cc;
				  pc = valmin(pcore, 8); 
				}
			    }
			  
			}/* printf ("\n pc: %f \t",pc); */ 
		    }
		  }
	    }
	} 
      /* Tri*/
      
      sort3(8,pcore,best_pairs[0],best_pairs[1]);			
      
      /* Stocker les vraisemblances de bonne d�cision (bd) et mauvaise d�cision (md) pour le meilleur couple*/
	
      k=8;  
      deltamax=pcore[8];
      delta1= deltamax; /*delta of the first most likely parent pair*/
      delta2= pcore[7]-deltamax; /*delta of the second most likely parent pair*/
      if(io==1) { 
	if ((bc1==kidpar[i].g2 && bc2==kidpar[i].g2) || (bc2==kidpar[i].g1 && bc2==kidpar[i].g2)) deltatrueC[i]=delta1;
	else deltawrongiC[i]=delta1;
      }
      if (io==2) { deltawrongo1C[i]=delta1; deltawrongo2C[i]=delta2; } 

      bc1=best_pairs[0][k]; bc2=best_pairs[1][k];
      if ((bc1==kidpar[i].g1 && bc2==kidpar[i].g2) || (bc1==kidpar[i].g2 && bc2==kidpar[i].g1))  
	{
	  if (pcore[k]>0.000000) ++bdc;
	}  
      else 
	{
	  if (pcore[k]>0.000000) ++mdc; 
	  
	}
      bestc[i]=pcore[k];

/* Attention commenter les lignes suivantes pour tcltk  */   
/*        printf("\nscores des meilleurs couples\n");  */
/*        printf("%f\n", bestc[i]);  */

    }      /*  end loop in i (nkid) */
  
  printf("\n End of calculation step \n");
  x=bdp;
  y=2*nkid;
  bdpf=100*x/y;
  x=bdc;
  y=nkid;
  bdcf=100*x/y;
  /* 	printf("\nbdp %d, mdp %d, bdc %d, mdc %d",bdp,mdp,bdc,mdc); */
  /* 	printf ("\n"); */
  

  
/* store in bestp the two most likely parents for each offspring   */
  
  for (i=1; i<=nkid; i++) *(bestp+i)=*(bestp1+i);
  for (i=nkid+1; i<=2*nkid; i++) *(bestp+i)=*(bestp2+(i-nkid)) ;
  
  hist1(bestp, 2*nkid, name1);
  hist1(bestc, nkid, name2);
  if (io==1) {
    hist1(deltatrue, (iii-1), name3);
    hist1(deltatrueC, 2*nkid, name4);
  }
  
  for (i=1; i<=2*nkid; ++i) deltawrong[i]=deltawrongi[i];
  for (i=1; i<=2*nkid; ++i) deltawrongC[i]=deltawrongiC[i];
  for (i=2*nkid+1; i<=3*nkid; ++i)  deltawrong[i]=deltawrongo1[i-2*nkid];
  for (i=3*nkid+1; i<=4*nkid; ++i)  deltawrong[i]=deltawrongo2[i-3*nkid];
  for (i=2*nkid+1; i<=3*nkid; ++i)  deltawrongC[i]=deltawrongo1C[i-2*nkid];
  for (i=3*nkid+1; i<=4*nkid; ++i)  deltawrongC[i]=deltawrongo2C[i-3*nkid];

  if (io==1) 
    {
      printf("\n The two most likely parents are the right parents %d times over 2*%d simulated offspring (%.2f %%)",bdp,nkid,bdpf); 
      printf("\n");
      printf("\n The most likely parent pair is the right parent pair in %d simulations (%.2f %%)",bdc,bdcf); 
    }
  printf("\n");
   
  return(0);
  
}     /*   end of main() */


