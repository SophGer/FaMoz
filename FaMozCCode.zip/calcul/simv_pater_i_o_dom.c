
#include <math.h>
#include <stdio.h>
/* #include <time.h> */  /* pour initialiser le g�n�rateur de nombres al�atoires*/
#include <sys/time.h>
#include <unistd.h>
#include <stdlib.h>     
#include "nrutil.h"
#include "read.h"
#include "sort.h"
#include "alea.h"
#include "genetic.h"
#include "likely.h"

/**************************************************************************
Fait des simulations sur marqueurs AFLP :
cr�e des descendants hors parcelle :
- meilleurs 2 parents d'apr�s les vraisemblances
- meilleur couple

3/11/00 adapted to FaMoz.tcl 
10/01 combining outside/inside simulation
***************************************************************************/

main (int argc, char *argv[])
{
  char *name1, *name2, *name3;  
  int i, j, k, ii, jj, iii, *name_par, *name_kid, **kidgen, **pargen, **dadgam, **mumgam, **parcyt, **kidcyt; 
  int  npod, nkid, npar, nloc, cyt, cytmater, *nallc, nkid1, mum, mere, io, bp, bdp, mdp, dad;
  Geno *kidpar;                        /* nom des vrais parents du descendant*/
  double score[10], cc, bc, E, Es, F, f, *pf, **pfc, **fcumc, bdpf;
  double *bestf, best_dads[10], x, y, *deltatrue, *deltawrong, *deltawrongi, *deltawrongo1,*deltawrongo2 , deltamax, delta1, delta2;
  FILE *n, *n1, *nn, *nn1;  

  /* initialisation du g�n�rateur de nombres al�atoires :*/
  long m;
  float rand;
  struct timeval temps; 
  struct timezone  zone;
  gettimeofday(&temps,&zone);
  m=-temps.tv_usec; 
  rand=ran3(&m);

  name1="Best fathers";
  name2="Delta, true fathers";
  name3="Delta, wrong fathers";

  /* Reading arguments */
  nkid=atoi(argv[1]);
  E=atof(argv[2]); 
  Es=atof(argv[3]);
  cyt=atoi(argv[4]);
  cytmater=atoi(argv[5]); /* Maternal heredity of cytoplasme : yes=1 */
  io=atoi(argv[6]);
  F=atof(argv[7]);

  /* Lecture des donn�es locus */
  scanf ("%d", &nloc);
  pf=(double *)malloc((nloc-cyt+1) * sizeof(double));
  if (cyt > 0) nallc=(int *)malloc((cyt+1)*sizeof(int));
  read_loci_dom_cum (nloc, cyt, nallc, pf, &pfc, &fcumc);
  printf("\n Number of loci: %d",nloc);  
  printf("\n Of which %d cytoplasmic markers",cyt);
  scanf ("%d %d", &npar, &nkid1);
  printf ("\n Number of parents: %d, Number of simulated offspring: %d\n", npar,nkid);

  if (io==1) printf("\n***** Simulating offpring with father from genotyped parents *****\n");
  if (io==2) printf("\n***** Simulating offpring with father according to allele frequencies *****\n");

  printf("\n Simulation error %f, Lod calculation error %f, Heterozygote deficit %f\n",Es,E, F);    

  name_kid=(int *)malloc((nkid+1)*sizeof(int));
  name_par=(int *)malloc((npar+1)*sizeof(int));
  kidgen=(int **)malloc((nkid+1) * sizeof(int *));
  kidpar=(Geno *)malloc((nkid+1) * sizeof(Geno));
  pargen=(int **)malloc((npar+1) * sizeof(int *));
  mumgam=(int **)malloc((nkid+1) * sizeof(int *));
  parcyt=(int **)malloc((npar+1) * sizeof(int *));
  kidcyt=(int **)malloc((nkid+1) * sizeof(int *));

  if (io==1)  
    {
      dadgam=(int **)malloc((npar+1) * sizeof(int *));
      for (i=1; i<=npar; i++) dadgam[i]=(int *)malloc((nloc+1) * sizeof(int));
    }
  else if (io==2)  
    {
      dadgam=(int **)malloc((nkid+1) * sizeof(int *));
      for (i=1; i<=nkid; i++) dadgam[i]=(int *)malloc((nloc+1) * sizeof(int));
    }
   
  for (i=1; i<=nkid; i++) 
    {
      kidgen[i]=(int *)malloc((nloc-cyt+1) * sizeof(int));
      mumgam[i]=(int *)malloc((nloc+1) * sizeof(int));
      kidcyt[i]=(int *)malloc((cyt+1) * sizeof(int));
    }
  for (i=1; i<=npar; i++)  
    {
      pargen[i]=(int *)malloc((nloc-cyt+1) * sizeof(int));
      mumgam[i]=(int *)malloc((nloc+1) * sizeof(int));
      parcyt[i]=(int *)malloc((cyt+1) * sizeof(int));
    }

  read_gen_dat_par_dom(npar, name_par, pargen, nloc, cyt, parcyt);

  /*Initialisations*/
  bdp=0; mdp=0; iii=0;

  /* Cr�ation de descendants*/
  if(io==1)
    {
      for (ii=1;ii<=nkid;++ii)
	{
	  name_kid[ii]=ii;
	  mum = 1+(int)(npar*alea()) ;         /* Tirage al�atoire des deux parents : */
	  f=alea();
	  if (f<=2*F/(1+F)) dad=mum;         /*selfing at equilibrium = [2*F/(1+F)] */
	  else dad = 1+(int)(npar*alea()) ;         /* nombre entier al�atoire dans [1,npar] */ 
	  /*       printf("\nkid %d mum %d dad %d \n",ii, mum, dad); */
	  gamete_dom(pargen[mum], mumgam[mum], parcyt[mum], nloc, Es, pf, cyt, nallc); /* Simulation des gam�tes parentaux : */ 
	  gamete_dom(pargen[dad], dadgam[dad], parcyt[dad], nloc, Es, pf, cyt, nallc);
	  kidpar[ii].g1=name_par[mum]; 
	  kidpar[ii].g2=name_par[dad];
	  /*       printf("\nkidpar[ii].g1 %d kidpar[ii].g2 %d\n",kidpar[ii].g1,kidpar[ii].g2);   */
	  for (jj=1;jj<=nloc-cyt;++jj) 
	    {
	      if (mumgam[mum][jj] == 0 && dadgam[dad][jj] == 0) kidgen[ii][jj] = 0;
	      /* ii :enfant, jj locus*/ 
	      else if(mumgam[mum][jj] == 1 || dadgam[dad][jj] == 1) kidgen[ii][jj] = 1;
	    }     
	  if  (cyt > 0) 
	    {
	      if (cytmater==1) for (jj=nloc-cyt+1;jj<=nloc;++jj)  kidcyt[ii][jj-nloc+cyt] = mumgam[mum][jj];  
	      else if (cytmater==0) for (jj=nloc-cyt+1;jj<=nloc;++jj)  kidcyt[ii][jj-nloc+cyt] = dadgam[dad][jj]; 
	    }
	}
    }
  else if (io==2)
    {
      printf("\n Simulation step");
      for (ii=1;ii<=nkid;++ii)
	{ 
	  name_kid[ii]=ii; 
	  mum = 1+(int)(npar*alea()) ; 
	  gamete_dom(pargen[mum],mumgam[ii], parcyt[mum], nloc, Es, pf, cyt, nallc); /* Simulation des gam�tes parentaux : */ 
	  gamete_hp_dom(dadgam[ii], nloc, pf, cyt, nallc, fcumc);
	  kidpar[ii].g1=name_par[mum];            /* Nom du parent de la parcelle*/
	  
	  for (jj=1;jj<=nloc-cyt;++jj)
	    {	      
	      f=alea();
	      if (mumgam[mum][jj] == 0)
		{ if( f<=F || dadgam[ii][jj] == 0) kidgen[ii][jj] = 0;  /* ii :enfant, jj locus*/}
	      else if(mumgam[mum][jj] == 1 || dadgam[ii][jj] == 1) kidgen[ii][jj] = 1; 
	    }  
	  if  (cyt > 0)
	    {
	      if (cytmater==1) for (jj=nloc-cyt+1;jj<=nloc;++jj)  kidcyt[ii][jj-nloc+cyt] = mumgam[mum][jj];             
	      else if (cytmater==0) for (jj=nloc-cyt+1;jj<=nloc;++jj)  kidcyt[ii][jj-nloc+cyt] = dadgam[ii][jj];  
	    }
	  /* Paternal cytoplasmic heredity, if maternal, */
	  /* not interesting to use the information, except for checking right known mother*/
	}
    }
  printf("\n End of simulation step \n");
    if (io==1)   
      {  
        n = fopen ("deltafather.dom.gd.in", "w");   
        n1 = fopen ("deltafather.dom.bd.in", "w");  
        nn = fopen ("father.dom.gd.in", "w");   
        nn1 = fopen ("father.dom.bd.in", "w");  
      
      }  
    else if (io==2)  
      {  
        n = fopen ("deltafather.dom.bd.out", "w");   
        n1 = fopen ("father.dom.bd.out", "w");  
      }  

  printf("\n Calculation step");	

  /* 	First allocate memory to store data: draw a histogram later thanks to them */

  bestf=(double *)malloc((nkid+1)*sizeof(double)); 
  deltatrue=(double *)malloc((2*nkid+1)*sizeof(double));
  deltawrongi=(double *)malloc((2*nkid+1)*sizeof(double));
  deltawrongo1=(double *)malloc((nkid+1)*sizeof(double));
  deltawrongo2=(double *)malloc((nkid+1)*sizeof(double));
  deltawrong=(double *)malloc((4*nkid+1)*sizeof(double));
  for (i=1; i<=nkid; i++) bestf[i]=0.0; 
  
  for (i=1; i<=nkid; ++i)
    {

      /* Calcul des vraisemblances des p�res pour chaque descendant */
      
      npod=0; bc=1.0E6;
      for (k=1; k< 9; ++k) { best_dads[k] =0; score[k]=0.0;} 
      for (j=1; j<=npar; ++j)
	{
	  for (ii=1;ii<=npar;++ii) if ( kidpar[i].g1==name_par[ii]) mere=ii; 
	  /* 	  for (ii=1; ii<= nloc-cyt; ++ii) printf("\nloc-cyt %d freq %f\n",ii,pf[ii]); */
	  /* 	  printf("\nkid %d mere %d pere %d\n",i,mere, j); */

	  cc = pater_dom(nloc-cyt, kidgen[i], pargen[mere], pargen[j], pf, E, F); 
	  if (cyt > 0 && cytmater==0) cc+=likr_pat_cyt(cyt, kidcyt[i], parcyt[j], pfc, E, nallc);
	  if (cc>0.0 && finite(cc)==1)
	    {
	      ++npod;
	      if (npod < 9) 
		{
		  best_dads[npod] = name_par[j]; 
		  score[npod]=cc; 
		  if (cc < bc)  bc = cc; 
		} 

	      else
		{
		  if (cc > bc) 
		    {
		      k = dexmin(score, 8);
		      best_dads[k] = name_par[j];
		      score[k] = cc;
		      bc = valmin(score, 8); 
		    }
		}
	    }
	  
	  /* printf ("\n pc: %f \t",pc); */ 
	} 
      
      sort2(8,score,best_dads);			      
      k=8; 
      bestf[i]= score[k]; 
      deltamax=score[8];
      delta1= deltamax; /*delta of the first most likely father*/
      delta2= score[7]-deltamax; /*delta of the second most likely father*/
      if(io==1) { 
	if (best_dads[8]==kidpar[i].g2) {deltatrue[iii]=delta1; iii+=1;} else deltawrongi[i]=delta1;
	if (best_dads[7]==kidpar[i].g2) {deltatrue[iii]=delta2; iii+=1;} else deltawrongi[i]=delta2;
      }
      if (io==2) { deltawrongo1[i]=delta1; deltawrongo2[i]=delta2; } 
      /* Stocker les vraisemblances de bonne  (bd) et mauvaise d�cision (md) pour les meilleurs p�res*/
      if(io==1)
	{      
	  k=8; 
	  bestf[i]= score[k]; 
	  bp=best_dads[k]; 
	  if (bp==kidpar[i].g2)
	    {    
	      if (score[k]>0.000000) ++bdp; 
	      fprintf (n, " %f", score[8]-score[7]);  
	      fprintf (nn, " %f", score[8]);  
	    }
	  else
	    { 
	      ++mdp;    
	      fprintf (n1, " %f", score[8]-score[7]);  
  	      fprintf (nn1, " %f", score[8]);    
	    }
	}
      else if (io==2)	      
	{
	  if (score[8]>0.000000) 	      
	    {
	      fprintf (n, " %f", score[8]-score[7]);  
	      fprintf (n1, " %f", score[8]);    
	    }
	}
    }
      
  if(io==1)
    {      
      x=bdp;
      y=nkid;
      bdpf=100*x/y;
      printf("\n The most likely father is the right father in %d simulations (%.2f %%)",bdp,bdpf); 
    }
  printf("\n End of calculation step\n");	
  /*  printf("\nbdp %d, mdp %d",bdp,mdp);  */
  
  hist1(bestf,nkid, name1);
  if (io==1) hist1(deltatrue, (iii-1), name2);
  for (i=1; i<=2*nkid; ++i) deltawrong[i]=deltawrongi[i];
  for (i=2*nkid+1; i<=3*nkid; ++i)  deltawrong[i]=deltawrongo1[i-2*nkid];
  for (i=3*nkid+1; i<=4*nkid; ++i)  deltawrong[i]=deltawrongo2[i-3*nkid];

  if (io==2) hist1(deltawrong, 4*nkid, name3);

  if (io==1)
    {
      fclose(n);  
      fclose(nn);  
      fclose(n1);  
      fclose(nn1);
    }
  else if(io==2)
    {
      fclose(n);  
      fclose(n1);  
    }
  
  printf("\n");
  
  return(0);
  
}







