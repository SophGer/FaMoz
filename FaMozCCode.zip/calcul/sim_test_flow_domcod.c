/******************************sim_test_flow_domcod.c***************************************/

#include <math.h>
#include <stdio.h>
/* #include <time.h> */  /* pour initialiser le g�n�rateur de nombres al�atoires*/
#include <sys/time.h>
#include <unistd.h>
#include <stdlib.h>     
#include "nrutil.h"
#include "read.h"
#include "sort.h"
#include "alea.h"
#include "genetic.h"
#include "likely.h"

/**************************************************************************
  19/6/01
  Simulation of a population with codominant, dominant and cytoplasmic markers
  - applying a test
  - recording correct decision
  - recording different types of gene flow events
  ***************************************************************************/

main (int argc, char *argv[])
{  
  int nloc, nlocd, cyt, *nall, *nallc, cytmater, miss, test_type;
  double **pf, *pfd, **pfc, **fcum, **fcumc, E, Es, F, f, SEUIL_P, SEUIL_C, SEUIL_dP, SEUIL_dC;	         /*freqs*/
  int   nkid, nkid1, npar, *name_kid, *name_par, **kidgend, **pargend, **parcyt, **kidcyt;/* individual names, genotypic data */
  Geno **kidgen, **pargen; 	/* genotypic data */
  Geno  *kidpar;                        /* nom des vrais parents du descendant*/
  int **dadgam, **mumgam, **dadgamd, **mumgamd;      /* Gam�tes paternel et paternel*/
  int i, j, k, l, ii, jj, kk, mm, tp1, tp2, mum, dad, pp, ppo, cc1, j1, j2, gf, agf, cgf; 
  int npop, *listp, npopp, parchoi[3], p0;
  double  best_pars[10], best_pairs[3][10], coupchoi[3];
  double agff, agffo, cgff, nkidf, pagffo, gfo, cgfo, agfo, pagff, alpha, tgf, rgf;  /*  Gene flow measures */
  double score[10], pcore[10], cc, bc, pc, bch, mchc, total, pcbc, pcmcc, ogf, deltaP[10], deltaC[10], deltamaxP, deltamaxC;
  
  /* initialisation du g�n�rateur de nombres al�atoires :*/
  long m;
  float rand;
  struct timeval temps; 
  struct timezone  zone;
  gettimeofday(&temps,&zone);
  m=-temps.tv_usec; 
  rand=ran3(&m);
  
  /*Initialisations*/ 
  bch=0.0; mchc=0.0; total=0.0; pcbc=0.0; pcmcc=0.0; pp=0.0; cc1=0.0;
  gf=0; p0=0; cgf=0; agf=0; ppo=0; gfo=0; cgfo=0; agfo=0;
  
  /* Reading arguments */
  nkid=atoi(argv[1]);
  Es=atof(argv[2]);      /* Simulation error */
  E=atof(argv[3]);     /* Lod calculation error */
  cyt=atoi(argv[4]);
  cytmater=atoi(argv[5]);
  F=atof(argv[6]);
  miss=atoi(argv[7]);
  ogf=atof(argv[8]); 
  test_type=atoi(argv[9]); /* test type 1: test on lod scores 2: test on delta 3: test on both values*/
  if (test_type==1){
    SEUIL_P=atof(argv[10]);  /* Lod-score threshold to choose a parent / couple as the true one */
    SEUIL_C=atof(argv[11]); } 
  else if  (test_type==2) {
    SEUIL_dP=atof(argv[10]);  /* Delta threshold to choose a parent / couple  as the true one */
    SEUIL_dC=atof(argv[11]);}
  else if  (test_type==3){
    SEUIL_P=atof(argv[10]);  /* Lod-score threshold to choose a parent / couple as the true one */
    SEUIL_C=atof(argv[11]);  /* Delta threshold to choose a parent / couple as the true one */
    SEUIL_dP=atof(argv[12]);  /* Lod-score threshold to choose a parent / couple as the true one */
    SEUIL_dC=atof(argv[13]); }
  
  /* Lecture des donn�es locus */
  scanf ("%d", &nloc);
  nall=(int *)malloc((nloc-cyt+1)*sizeof(int));
  if (cyt > 0) nallc=(int *)malloc((cyt+1)*sizeof(int));
  read_loci_cum (nloc, nall, &pf, &fcum, cyt, nallc, &pfc, &fcumc);
  scanf ("%d", &nlocd);
  pfd=(double *)malloc((nlocd+1) * sizeof(double));
  read_loci_dom_cum (nlocd, 0, nallc, pfd, &pfc, &fcumc);
  
  printf("\n Number of loci, codominant %d, dominant %d, cytoplasmic %d",nloc-cyt, nlocd, cyt);
  scanf ("%d %d", &npar, &nkid1);
  printf ("\n Number of genotyped parents: %d, \n Number of simulated offspring: %d", npar, nkid);
  printf("\n Simulation error %f, Lod calculation error %f, Heterozygote deficit %f\n", Es, E, F);    
  if (test_type==1) {
    printf("\n Lod-score test thresholds: to choose a parent as the true one      = %.2f, ", SEUIL_P);
    printf("\n                  to choose a parent pair as the true one = %.2f", SEUIL_C);}
  if (test_type==2) {
    printf("\n Delta test thresholds: to choose a parent as the true one      = %.2f, ", SEUIL_dP);
    printf("\n                  to choose a parent pair as the true one = %.2f", SEUIL_dC);}
  if (test_type==3) {
    printf("\n Lod-score,  Delta test thresholds: to choose a parent as the true one      = %.2f %.2f,", SEUIL_P, SEUIL_dP);
    printf("\n                  to choose a parent pair as the true one = %.2f %.2f", SEUIL_C, SEUIL_dC);}
  
  if (nkid>npar) mm=nkid; else mm=npar;
  listp=(int *)malloc((npar+1)*sizeof(int));
  name_kid=(int *)malloc((nkid+1)*sizeof(int));
  name_par=(int *)malloc((mm+1)*sizeof(int));
  kidgen=(Geno **)malloc((nkid+1) * sizeof(Geno *));
  kidpar=(Geno *)malloc((nkid+1) * sizeof(Geno));
  pargen=(Geno **)malloc((npar+1) * sizeof(Geno *));
  mumgam=(int **)malloc((mm+1) * sizeof(int *));
  dadgam=(int **)malloc((mm+1) * sizeof(int *));
  mumgamd=(int **)malloc((mm+1) * sizeof(int *));
  dadgamd=(int **)malloc((mm+1) * sizeof(int *));
  kidgend=(int **)malloc((nkid+1) * sizeof(int *));
  pargend=(int **)malloc((npar+1) * sizeof(int *));
  parcyt=(int **)malloc((npar+1) * sizeof(int *));
  kidcyt=(int **)malloc((nkid+1) * sizeof(int *));
  
  for (i=1; i<=nkid; i++) {
    kidgen[i]=(Geno *)malloc((nloc-cyt+1) * sizeof(Geno));
    kidgend[i]=(int *)malloc((nlocd+1) * sizeof(int));
    kidcyt[i]=(int *)malloc((cyt+1) * sizeof(int));
  }
  for (i=1; i<=npar; i++) {
    pargen[i]=(Geno *)malloc((nloc-cyt+1) * sizeof(Geno)); 
    pargend[i]=(int *)malloc((nlocd+1) * sizeof(int));
    parcyt[i]=(int *)malloc((cyt+1) * sizeof(int));
  }
  for (i=1; i<=mm; i++) {
    mumgam[i]=(int *)malloc((nloc+1) * sizeof(int));
    dadgam[i]=(int *)malloc((nloc+1) * sizeof(int));
    mumgamd[i]=(int *)malloc((nlocd+1) * sizeof(int));
    dadgamd[i]=(int *)malloc((nlocd+1) * sizeof(int));
  }
  
  read_gen_dat_par_domcod(npar, name_par, nloc, nlocd, cyt, pargen, parcyt, pargend);  
  
  /* 1/ Cr�ation de descendants*/
  /* First simulate offspring with genotyped parents */
  for (ii=1;ii<=nkid; ++ii)
    { 
      name_kid[ii]=ii;
      mum = 1+(int)(npar*alea()) ;
      /* Tirage al�atoire d'un parent parmi ceux de la population (pop individus)*/ 
      f=alea();
      if (f<=2*F/(1+F)) {
	dad=ii; 
	gamete(pargen[mum], dadgam[dad], nloc, nall, Es, cyt, nallc, parcyt[mum]);
	gamete_dom(pargend[mum], dadgamd[dad], parcyt[dad], nlocd, Es, pfd, 0, nallc);
      }
      else dad = 1+(int)(npar*alea()) ; 
      gamete(pargen[mum], mumgam[mum], nloc, nall, Es, cyt, nallc, parcyt[mum]); /* Simulation des gam�tes parentaux : */ 
      gamete_dom(pargend[mum], mumgamd[mum], parcyt[mum], nlocd, Es, pfd, 0, nallc); 
      gamete(pargen[dad],dadgam[dad], nloc, nall, Es, cyt, nallc, parcyt[dad]);
      gamete_dom(pargend[dad],dadgamd[dad], parcyt[dad], nlocd, Es, pfd, 0, nallc);
      if  (cyt > 0) {
	if (cytmater==1) for (jj=nloc-cyt+1;jj<=nloc;++jj)  kidcyt[ii][jj-nloc+cyt] = mumgam[mum][jj];             
	else if (cytmater==0) for (jj=nloc-cyt+1;jj<=nloc;++jj)  kidcyt[ii][jj-nloc+cyt] = dadgam[dad][jj];  
      }
      kidpar[ii].g1=name_par[mum];            /* Nom des parents (=-5 si hors parcelle) */
      kidpar[ii].g2=name_par[dad];  
      for (jj=1;jj<=nloc-cyt;++jj) {
	kidgen[ii][jj].g1=mumgam[mum][jj];  /* ii :enfant, jj locus*/
	kidgen[ii][jj].g2=dadgam[dad][jj];   
      }  
      for (jj=1;jj<=nlocd;++jj) {
	if (mumgamd[mum][jj] == 0 && dadgamd[dad][jj] == 0) kidgend[ii][jj] = 0; 
	/* ii :enfant, jj locus*/
	else if (mumgamd[mum][jj] == 1 || dadgamd[dad][jj] == 1) kidgend[ii][jj] = 1;   
      }  
    }
  for (i=1; i<=nkid; ++i) { 
    
    npopp=0; npop=0;  bc=1.0E6; pc = 1.0E6; /* Number Possible Parent / Pairs */
    
    /* Calcul des vraisemblances des parents pour chaque descendant */
    
    for (k=0; k< 9; ++k) {
      score[k]=0.0; best_pars[k] =0; pcore[k]=0.0;
      best_pairs[0][k]=0; best_pairs[1][k]=0; 
    }
    for (j=1; j<=npar; ++j) {
      cc = uparchk(nloc-cyt, *(kidgen+i), pargen[j], pf, E, F, nall, miss);  /* proba maternit�:non maternit�*/
      cc += uparchk_dom(nlocd, kidgend[i], pargend[j], pfd, E, F); /* proba maternit�:non maternit�*/
      if (cyt > 0) cc+=likr_cyt(cyt, kidcyt[i], parcyt[j], pfc, E, nallc);
      if (cc > 0.0 && finite(cc)==1) { 
	++npop; listp[npop]=j; /*rang de tous les parents � proba > 0,npop observations*/
	if (npop < 9) { 
	  best_pars[npop] = name_par[j]; 
	  score[npop]=cc; 
	  if (cc < bc)  bc = cc;
	} /* bc sera le score min parmi les 8 premiers >0 */
	else {
	  if (cc > bc) { /*score sup�rieur au min pr�c�dent*/
	    k = dexmin(score, 8); /* rang du score minimum parmi les 8*/
	    best_pars[k] = name_par[j];  /*on remplace la m�re k  ...  */
	    score[k] = cc;               /* par la j, qui est meilleure */ 
	    bc = valmin(score, 8); 
	  }
	}  /*nouveau score min*/
      } 
    }                                  /* � la fin on a les 8 meilleures des nmum*/
    
    /* Ins�rer un tri sur best_pars[k] et score[k], 1<=k<=8 */
    sort2(8,score,best_pars);
    deltamaxP=score[8];
    for (k=8; k>=1; --k){ if (k==8) deltaP[k]=deltamaxP; else deltaP[k]=deltamaxP-score[k];}    
    
      
    /* Affichage avec le test*/
    j1=0;
    for (k=8; k>=1; --k) {
      if (test_type==1) {
	if (score[k] > SEUIL_P) {
	  ++j1;
	  if (j1==1) parchoi[1]= best_pars[k];
	  else if (j1==2)  parchoi[2]= best_pars[k];
	}
      }
      else if (test_type==2) {
	if (deltaP[k] > SEUIL_dP) {
	  ++j1;
	  if (j1==1) parchoi[1]= best_pars[k];
	  else if (j1==2)  parchoi[2]= best_pars[k];
	}
      }
      else if (test_type==3) {
	if (score[k] > SEUIL_P && deltaP[k] > SEUIL_dP) {
	  ++j1;
	  if (j1==1) parchoi[1]= best_pars[k];
	  else if (j1==2)  parchoi[2]= best_pars[k];
	}
      }         
    } 
    if (j1==0) {
      parchoi[1]=(-5); 
      parchoi[2]=(-5);
    }
    else if (j1==1)  parchoi[2]= (-5);
    if ((parchoi[1]==kidpar[i].g1 && parchoi[2]==kidpar[i].g2) || 
	(parchoi[1]==kidpar[i].g2) && parchoi[2]==kidpar[i].g1) {
      ++pp; 
      ++pp;
    }
    else if (parchoi[1]==kidpar[i].g1 && parchoi[2]!=kidpar[i].g2) ++pp;
    else if (parchoi[1]==kidpar[i].g2 && parchoi[2]!=kidpar[i].g1) ++pp; 
    else if (parchoi[2]==kidpar[i].g1 && parchoi[1]!=kidpar[i].g2) ++pp; 
    else if (parchoi[2]==kidpar[i].g2 && parchoi[1]!=kidpar[i].g1) ++pp;
    
    fflush(stdout);
    
    /* Calcul des vraisemblances pour les meilleurs couples*/
    pc=1.0E6; for (k=0; k< 9; ++k)  pcore[k]=0.0; 
    for (j=1; j<=npop; ++j) { 
      tp1 = listp[j];
      if (npop > 0) {
	for (kk=1; kk<=npop; ++kk) { 
	  tp2 = listp[kk];
	  if (tp2>=tp1) {
	    cc = pparchk(nloc-cyt, kidgen[i], pargen[tp1], pargen[tp2], pf, E, F, nall, miss);  /*dans boucle en j*/
	    cc += pparchk_dom(nlocd, kidgend[i], pargend[tp1], pargend[tp2], pfd, E, F); /*dans boucle en j*/
	    if (cyt > 0) cc+=likr_pair_cyt(cyt, kidcyt[i], parcyt[tp1], parcyt[tp2], pfc, E, nallc);
	    if (cc > 0.0 && finite(cc)==1) {
	      ++npopp; 
	      if (npopp < 9) { 
		best_pairs[0][npopp] = name_par[tp1]; 
		best_pairs[1][npopp] = name_par[tp2]; 
		pcore[npopp]=cc; 
		if (cc < pc)  pc = cc; 
	      } 
	      else {
		if (cc > pc) { 
		  k = dexmin(pcore, 8);
		  best_pairs[0][k] = name_par[tp1]; 
		  best_pairs[1][k] = name_par[tp2]; 
		  pcore[k] = cc;
		  pc = valmin(pcore, 8); 
		}
	      }
	    }/* printf ("\n pc: %f \t",pc); */ 
	  }
	}
      }
    } 
    /* Tri*/
    
    sort3(8, pcore, best_pairs[0], best_pairs[1]);			
    deltamaxC=pcore[8];
    for (k=8; k>=1; --k){ if (k==8) deltaC[k]=deltamaxC; else deltaC[k]=deltamaxC-pcore[k];}    
    
    
    /* Affichage des meilleurs avec le test */
    
    j2=0;
    for (k=8; k>=1; --k) {
      if (test_type==1) {
	if (pcore[k] > SEUIL_C) {
	  for (j=8; j>=1;--j) {
	    if (best_pairs[0][k]==best_pars[j] && score[j]> SEUIL_P) {
	      for (l=8; l>=1;--l) {
		if (best_pairs[1][k]==best_pars[l] && score[l]> SEUIL_P) {
		  ++j2;
		}
	      }
	    }
	  }
	}
      }
      else if (test_type==2) {
	if (deltaC[k] > SEUIL_dC) {
	  for (j=8; j>=1;--j) {
	    if (best_pairs[0][k]==best_pars[j] && deltaP[j]> SEUIL_dP) {
	      for (l=8; l>=1;--l) {
		if (best_pairs[1][k]==best_pars[l] && deltaP[l]> SEUIL_dP) {
		  ++j2;
		}
	      }
	    }
	  }
	}
      }
      else if (test_type==3) {
	if (pcore[k] > SEUIL_C && deltaC[k] > SEUIL_dC) {
	  for (j=8; j>=1;--j) {
	    if (best_pairs[0][k]==best_pars[j] && score[j]> SEUIL_P && deltaP[j]> SEUIL_dP ) {
	      for (l=8; l>=1;--l) {
		if (best_pairs[1][k]==best_pars[l] && score[l]> SEUIL_P && deltaP[j]> SEUIL_dP) {
		  ++j2;
		}
	      }
	    }
	  }
	}
      }
    } 
    
    if (j2==0) {
      /* printf ("\tPas de couple probable intra parcelle \n"); */ 
      coupchoi[1]=(-5);
      coupchoi[2]=(-5);
    }
    else if (j2>0) {
      coupchoi[1]=best_pairs[0][8]; 
      coupchoi[2]=best_pairs[1][8];
    } 
    
    if (j2==0 && kidpar[i].g1==(-5) || kidpar[i].g2==(-5)) ++cc1; 
    if (j2>0 && ((coupchoi[1]==kidpar[i].g1 && coupchoi[2]==kidpar[i].g2) || 
		 (coupchoi[2]==kidpar[i].g1 && coupchoi[1]==kidpar[i].g2))) ++cc1; 

      /* V�rif */
      /*printf("\nkid %d", i); */
      /*printf("\nparchoi[1] %d kidpar[i].g1 %d", parchoi[1], kidpar[i].g1); */
      /*printf("\nparchoi[2] %d kidpar[i].g2 %d", parchoi[2], kidpar[i].g2); */
      /*printf("\ncoupchoi[1] %.0f coupchoi[2] %.0f",coupchoi[1], coupchoi[2]); */

      /* Calcul des flux de g�nes (gf) apparents (agf), cach� (cgf)*/
      
    if (kidpar[i].g1==-5 && kidpar[i].g2==-5) {
      p0=2; 
      ++gf; 
      ++gf;
    }
    else if ((kidpar[i].g1==-5 && kidpar[i].g2!=-5)||(kidpar[i].g1!=-5 && kidpar[i].g2==-5)) {
      p0=1;
      ++gf;
    }
    else p0=0;
    if (j2>0) {
      if (p0==2) {
	++cgf; 
	++cgf;
      }
      else if (p0==1) ++cgf; 
    }
    else if (j2==0) {
      if (j1!=0) {
	++agf; 
	if (p0==2) ++cgf;
      }
      if (j1==0) {
	++agf;
	++agf;
      }
    }     
  }

  
  /* 2/ Cr�ation de descendants*/
  /* Second, simulate offspring with random parents */
 
    if (mum > npar) 	  
	{
	  gamete_hp(mumgam[mum], nloc, nall, fcum, cyt, nallc, fcumc); /* Simulation des gam�tes parentaux : */ 
	  gamete_hp_dom(mumgamd[mum], nlocd, pfd, 0, nallc, fcumc);  
	}
      /* Sinon, tirage du gamete du parent de la parcelle */
      if (dad > npar) 
	{
	  gamete_hp(dadgam[dad], nloc, nall, fcum, cyt, nallc, fcumc);   
	  gamete_hp_dom(dadgamd[dad], nlocd, pfd, 0, nallc, fcumc);  
	}
  for (ii=1;ii<=nkid;++ii) {
      name_kid[ii]=ii;
      mum=ii; 
      dad=ii;        
      f=alea();      
      gamete_hp(mumgam[mum], nloc, nall, fcum, cyt, nallc, fcumc);  
      gamete_hp_dom(mumgamd[mum], nlocd, pfd, 0, nallc, fcumc);  
      if (f<=2*F/(1+F)) { /*selfing at equilibrium = [2*F/(1+F)] */
	/*create a diploid mother to make selfing in case of f<=2*F/(1+F), */
	/*use kidgen as an intermediate containing the "mother" from which male gamete will be taken*/
	gamete_hp(dadgam[dad], nloc, nall, fcum, cyt, nallc, fcumc); 
	gamete_hp_dom(dadgamd[dad], nlocd, pfd, 0, nallc, fcumc); 
	for (jj=1;jj<=nloc-cyt;++jj) {
	  kidgen[ii][jj].g1=mumgam[ii][jj];  /* ii :enfant, jj locus*/
	  kidgen[ii][jj].g2=dadgam[ii][jj];   
	} 	
	for (jj=1;jj<=nlocd;++jj) {
	  if (mumgam[mum][jj] == 0 && dadgam[dad][jj] == 0) kidgend[ii][jj] = 0;
	  else if (mumgam[mum][jj] == 1 || dadgam[dad][jj] == 1) kidgend[ii][jj] = 1;   
	}
	gamete(kidgen[ii], dadgam[dad], nloc, nall, Es, cyt, nallc, parcyt[mum]); 
	gamete_dom(kidgend[ii], dadgamd[dad], parcyt[dad], nlocd, Es, pfd, 0, nallc); 
      }
      else {
	gamete_hp(dadgam[dad], nloc, nall, fcum, cyt, nallc, fcumc);  
	gamete_hp_dom(dadgamd[dad], nlocd, pfd, 0, nallc, fcumc);  
      }
      kidpar[ii].g1=-5;            /* Nom des parents (=-5 si hors parcelle) */
      kidpar[ii].g2=-5;           
      for (jj=1;jj<=nloc-cyt;++jj) {
	kidgen[ii][jj].g1=mumgam[ii][jj];  /* ii :enfant, jj locus*/
	kidgen[ii][jj].g2=dadgam[ii][jj];   
      }       
      for (jj=1;jj<=nloc-cyt;++jj) {
	if (mumgam[mum][jj] == 0 && dadgam[dad][jj] == 0) kidgend[ii][jj] = 0;
	else if (mumgam[mum][jj] == 1 || dadgam[dad][jj] == 1) kidgend[ii][jj] = 1;   
      }    
      if  (cyt > 0) {
	if (cytmater==1) for (jj=nloc-cyt+1;jj<=nloc;++jj)  kidcyt[ii][jj-nloc+cyt] = mumgam[mum][jj];             
	else if (cytmater==0) for (jj=nloc-cyt+1;jj<=nloc;++jj)  kidcyt[ii][jj-nloc+cyt] = dadgam[dad][jj];  
      }
  }
  
  for (i=1; i<=nkid; ++i) {
    npopp=0; npop=0;  bc=1.0E6; pc = 1.0E6; /* Number Possible Parent / Pairs */
    
    /* Calcul des vraisemblances des parents pour chaque descendant */ 
    for (k=1; k< 9; ++k) {
      score[k]=0.0; deltaP[k]=0.0; deltaC[k]=0.0;
      best_pars[k] =0; pcore[k]=0.0;
      best_pairs[0][k]=0; best_pairs[1][k]=0;
    }
    for (j=1; j<=npar; ++j) {
      cc = uparchk(nloc-cyt, *(kidgen+i), pargen[j], pf, E, F, nall, miss);  /* proba maternit�:non maternit�*/
      cc += uparchk_dom(nlocd, kidgend[i], pargend[j], pfd, E, F); /* proba maternit�:non maternit�*/
      if (cyt > 0) cc+=likr_cyt(cyt, kidcyt[i], parcyt[j], pfc, E, nallc);
      if (cc > 0.0 && finite(cc)==1) {
	++npop; listp[npop]=j; /*rang de tous les parents � proba > 0,npop observations*/
	if (npop < 9) {
	  best_pars[npop] = name_par[j]; 
	  score[npop]=cc; 
	  if (cc < bc)  bc = cc; 
	} /* bc sera le score min parmi les 8 premiers >0 */
	else {
	  if (cc > bc) { /*score sup�rieur au min pr�c�dent*/
	    k = dexmin(score, 8); /* rang du score minimum parmi les 8*/
	    best_pars[k] = name_par[j];  /*on remplace la m�re k  ...  */
	    score[k] = cc;               /* par la j, qui est meilleure */ 
	    bc = valmin(score, 8); 
	  }
	}  /*nouveau score min*/
      }
    }
    
    /* Ins�rer un tri sur best_pars[k] et score[k], 1<=k<=8 */
    sort2(8,score,best_pars);
    deltamaxP=score[8];
    for (k=8; k>=1; --k){ if (k==8) deltaP[k]=deltamaxP; else deltaP[k]=deltamaxP-score[k];}
    
    
    /* Affichage avec le test*/
    j1=0;
    for (k=8; k>=1; --k) { 
      if (test_type==1) {
	if (score[k] > SEUIL_P) {
	  ++j1;
	  if (j1==1) parchoi[1]= best_pars[k];
	  else if (j1==2)  parchoi[2]= best_pars[k];
	}
      }
      else if (test_type==2) {
	if (deltaP[k] > SEUIL_dP) {
	  ++j1;
	  if (j1==1) parchoi[1]= best_pars[k];
	  else if (j1==2)  parchoi[2]= best_pars[k];
	}
      }
      else if (test_type==3) {
	if (score[k] > SEUIL_P && deltaP[k] > SEUIL_dP) {
	  ++j1;
	  if (j1==1) parchoi[1]= best_pars[k];
	  else if (j1==2)  parchoi[2]= best_pars[k];
	}
      }
    }
    if (j1==0) {
      parchoi[1]=(-5); 
      parchoi[2]=(-5);
    }
    else if (j1==1)  parchoi[2]= (-5);
    if ((parchoi[1]==kidpar[i].g1 && parchoi[2]==kidpar[i].g2) || 
	(parchoi[1]==kidpar[i].g2) && parchoi[2]==kidpar[i].g1) {
      ++ppo; 
      ++ppo;
    }
    else if (parchoi[1]==kidpar[i].g1 && parchoi[2]!=kidpar[i].g2) ++ppo;
    else if (parchoi[1]==kidpar[i].g2 && parchoi[2]!=kidpar[i].g1) ++ppo;
    else if (parchoi[2]==kidpar[i].g1 && parchoi[1]!=kidpar[i].g2) ++ppo; 
    else if (parchoi[2]==kidpar[i].g2 && parchoi[1]!=kidpar[i].g1) ++ppo; 
    
    /*  	if (jj==0)  printf ("\tPas de parent probable intra parcelle \n");  */
    fflush(stdout);    
    
    
    /* Calcul des vraisemblances pour les meilleurs couples*/
    pc=1.0E6; 
    for (k=0; k< 9; ++k)  pcore[k]=0.0; 
    for (j=1; j<=npop; ++j) { 
      tp1 = listp[j];
      if (npop > 0) {
	for (kk=1; kk<=npop; ++kk) {
	  tp2 = listp[kk];
	  if (tp2>=tp1) { 
	    cc = pparchk(nloc-cyt, kidgen[i], pargen[tp1], pargen[tp2], pf, E, F, nall, miss);  /*dans boucle en j*/
	    cc += pparchk_dom(nlocd, kidgend[i], pargend[tp1], pargend[tp2], pfd, E, F); /*dans boucle en j*/
	    if (cyt > 0) cc+=likr_pair_cyt(cyt, kidcyt[i], parcyt[tp1], parcyt[tp2], pfc, E, nallc);
	    if (cc > 0.0 && finite(cc)==1) {
	      ++npopp; 
	      if (npopp < 9) {
		best_pairs[0][npopp] = name_par[tp1]; 
		best_pairs[1][npopp] = name_par[tp2]; 
		pcore[npopp]=cc; 
		if (cc < pc)  pc = cc; 
	      } 
	      else {
		if (cc > pc) {
		  k = dexmin(pcore, 8);
		  best_pairs[0][k] = name_par[tp1]; 
		  best_pairs[1][k] = name_par[tp2]; 
		  pcore[k] = cc;
		  pc = valmin(pcore, 8); 
		}
	      }
	    }/* printf ("\n pc: %f \t",pc); */
	  }
	}
      }
    } 
    /* Tri*/
    
    sort3(8, pcore, best_pairs[0], best_pairs[1]);			
    deltamaxC=pcore[8];
    for (k=8; k>=1; --k){ if (k==8) deltaC[k]=deltamaxC; else deltaC[k]=deltamaxC-pcore[k];}
    
    
    /* Affichage des meilleurs avec le test */
    
    j2=0;
    for (k=8; k>=1; --k) {
      if (test_type==1) {
	if (pcore[k] > SEUIL_C) {
	  for (j=8; j>=1;--j) {
	    if (best_pairs[0][k]==best_pars[j] && score[j]> SEUIL_P) {
	      for (l=8; l>=1;--l) {
		if (best_pairs[1][k]==best_pars[l] && score[l]> SEUIL_P) {
		  ++j2;
		}
	      }
	    }
	  }
	}
      }
      else if (test_type==2) {
	if (deltaC[k] > SEUIL_dC) {
	  for (j=8; j>=1;--j) {
	    if (best_pairs[0][k]==best_pars[j] && deltaP[j]> SEUIL_dP) {
	      for (l=8; l>=1;--l) {
		if (best_pairs[1][k]==best_pars[l] && deltaP[l]> SEUIL_dP) {
		  ++j2;
		}
	      }
	    }
	  }
	}
      }
      else if (test_type==3) {
	if (pcore[k] > SEUIL_C && deltaC[k] > SEUIL_dC) {
	  for (j=8; j>=1;--j) {
	    if (best_pairs[0][k]==best_pars[j] && score[j]> SEUIL_P && deltaP[j]> SEUIL_dP) {
	      for (l=8; l>=1;--l) {
		if (best_pairs[1][k]==best_pars[l] && score[l]> SEUIL_P && deltaP[j]> SEUIL_dP) {
		  ++j2;
		}
	      }
	    }
	  }
	}
      }
    } 
    
    if (j2==0) {/*  printf ("\tPas de couple probable intra parcelle \n"); */  
      coupchoi[1]=(-5);
      coupchoi[2]=(-5);
    }
    else if (j2>0) {
      coupchoi[1]=best_pairs[0][8];
      coupchoi[2]=best_pairs[1][8];
    }
    
    if (j2==0 && kidpar[i].g1==(-5) || kidpar[i].g2==(-5)) ++cc1; 
      if (j2>0 && ((coupchoi[1]==kidpar[i].g1 && coupchoi[2]==kidpar[i].g2) || 
		   (coupchoi[2]==kidpar[i].g1 && coupchoi[1]==kidpar[i].g2))) ++cc1;
      
      
      /* Calcul des flux de g�nes (gf) apparents (agf), cach� (cgf)*/
      
      if (kidpar[i].g1==-5 && kidpar[i].g2==-5) {
	p0=2; 
	++gfo; 
	++gfo;
      }
      else if ((kidpar[i].g1==-5 && kidpar[i].g2!=-5)||(kidpar[i].g1!=-5 && kidpar[i].g2==-5)) {
	p0=1;
	++gfo;
      }
      else p0=0;
      if (j2>0) {
	if (p0==2) {
	  ++cgfo; 
	  ++cgfo;
	}
	else if (p0==1) ++cgfo; 
      }
      else if (j2==0) {
	if (j1!=0) {
	  ++agfo; 
	  if (p0==2) ++cgfo;
	}
	if (j1==0) {
	  ++agfo;
	  ++agfo;
	}
      }
  }      


  fflush(stdout);
  printf ("\n");

  bch=pp+ppo;
  total=nkid;
  pcbc=(bch/(2*2*total))*100;
  mchc=cc1;
  pcmcc=(mchc/(2*total))*100; 
  printf("\n\n*** Results ***\n\n");
  printf("\n Percentages of:\n");
  printf(" - correct single parent choice = \t%8.2f \n",pcbc);
  printf(" - correct parent pair choice   = \t%8.2f \n",pcmcc);
  
  printf("\n");
  agff=agf;
  cgff=cgf;
  nkidf=2*nkid;

  agffo=agfo;
  pagffo=agffo/nkidf;
  pagff=agff/nkidf;
  tgf=(ogf-pagff)/pagffo-pagff;
  rgf=tgf*pagffo; /*true gene flow*/
  cgff=tgf*(1-pagffo); /*cryptic gene flow = beta or type II error, assign a father when the true father is outside*/
  alpha=(1-tgf)*pagff; /*alpha or type I error, assign no father when the true father is inside*/

  printf("Apparent gene flow ('gfo', true) when offspring are generated with random parents:\n \tpercentage = %8.4f \tnumber = %8.0f\n",pagffo*100, agffo);
  printf("Apparent gene flow ('gfi', untrue) when offspring are generated with genotyped parents:\n \tpercentage = %8.4f \tnumber = %8.0f\n",pagff*100, agff);
  printf("The true gene flow ('tgf') and the gene flow observed in the parentage experiment ('ogf') are connected:\n");
  printf("\togf = tgf*gfo + (1-tgf)*gfi = real gene flow + alpha errors\n");
  printf("\ttgf is calculated thanks to this expression\n");
  printf("Cryptic gene flow ('cgf' or beta) is deduced:  \tcgf = tgf*(1-gfo) \n");
  printf("Alpha is deduced:  \t\talpha = (1-tgf)gfi \n\n");

  printf("Real gene flow:  \tpercentage %8.4f \tnumber = %8.0f\n", rgf*100, rgf*total);
  printf("Cryptic gene flow:  \tpercentage %8.4f \tnumber = %8.0f\n", cgff*100,cgff*total);
  printf("-> Equivalent to beta or type II error, assign a parent when the true parent is outside \n");
  printf("Alpha or type I error:  \tpercentage %8.4f \tnumber = %8.0f\n", alpha*100, alpha*total);
  printf("-> Assign no parent when the true parent is inside \n");



/*   bch=pp; */
/*   total=nkid; */
/*   pcbc=(bch/(2*total))*100; */
/*   mchc=cc1; */
/*   pcmcc=(mchc/total)*100;  */
/*   printf("\n\n*** Results ***\n\n"); */
/*   printf("\n Percentages of:\n"); */
/*   printf(" - correct single parent choice = \t%8.2f \n",pcbc); */
/*   printf(" - correct parent pair choice   = \t%8.2f \n",pcmcc); */
/*   printf("\n"); */
  
/*   agff=agf; */
/*   cgff=cgf; */
/*   nparf=npar; */
/*   nkidf=nkid; */
/*   popf=pop; */
/*   att=((popf-nparf)/popf)*2*nkidf; */
/*   gff=gf; */
/*   printf(" On a total of %d gametes produced: \n",2*nkid); */
/*   printf(" - expected* gene flow =  \t%10.0f\n", att); */
/*   printf(" - true** gene flow =    \t%10d \n", gf); */
/*   printf(" - apparent� gene flow =  \t%10d \n", agf); */
/*   printf(" - cryptic�� gene flow =  \t%10d \n", cgf); */
/*   printf("\n Percentages: \n - true/apparent = \t%10.2f \n - cryptic/apparent = \t%10.2f", (gff/agff)*100,(cgff/agff*100)); */
  
/*   printf("\n\n* [(Total reproducing population size - number of genotyped parent)/Total reproducing population size]\ */
/* \t\t\t*(number of simulated gametes)"); */
/*   printf("\n** Actual number of times a parent different from the genotyped parents produced one of the offspring."); */
/*   printf("\n� Number of times no genotyped parent was detected for the simulated offspring,\n  according to the statistical tests."); */
/*   printf("\n�� Number of times a parent had been detected among the genotyped parent\n according to the statistical tests whereas the true parent was not part of them."); */
  
  printf ("\n");


  return(0);

}

