#include <math.h>
#include <stdio.h>
#include "nrutil.h"
#include "read.h"
#include "genetic.h"
#include "likely.h"

/**************************************************************************
  10/3/99
  Programme pour comparer des individus par paire et calculer les vraisemblances
  de plein-fr�res (FS), demi-fr�re (HS), non apparent�s (U).
  Fichier d'entr�e testpm
  nb_loci
  nb_all_loc1 freq_all1_loc1 ....
  nb_all_loc2 freq_all1_loc2 ....
  number_individuals
  number_ind1 genotype...
  number_ind2 genotype...
  
  25/8/2000 adapt� pour le programme g�n�ral tcltk : malloc partout
  14/11/00 pour FaMoz

  ***************************************************************************/

extern double rans();

main (int argc, char *argv[])
{  
  int nloc, *nall, cyt, *nallc, i, j, npar, nkid1, *name_par, **parcyt, **rel;
  double  **pf, **pfc, **hs, **fs, SEUIL_fs, SEUIL_hs;
  Geno **pargen;
  /* hs et fs matrices des lod scores demi fr�res et pleins fr�res*/
    
  cyt=atoi(argv[1]);
  SEUIL_hs=atof(argv[2]);
  SEUIL_fs=atof(argv[3]);
 
  scanf ("%d", &nloc);
  nall=(int *)malloc((nloc+1)*sizeof(int));
  if (cyt > 0) nallc=(int *)malloc((cyt+1)*sizeof(int));
  read_loci (nloc, nall, &pf, cyt, nallc, &pfc);
  printf("\n Number of loci %d",nloc); 
  printf("\n Among them, number of cytoplasmic markers: %d",cyt);
  scanf ("%d %d", &npar, &nkid1);
  printf ("\n Number of parents: %d \n", npar);
  printf (" Half-sibship threshold: %f, full-sibship threshold: %f\n", SEUIL_hs, SEUIL_fs);
  
  name_par=(int *)malloc((npar+1) * sizeof(int));
  pargen=(Geno **)malloc((npar+1) * sizeof(Geno *));
  parcyt=(int **)malloc((npar+1) * sizeof(int *));
  hs=(double **)malloc((npar+1) * sizeof(double *));
  fs=(double **)malloc((npar+1) * sizeof(double *));
  rel=(int **)malloc((npar+1) * sizeof(int *));
  for (i=1; i<=npar; i++)  
    {
      pargen[i]=(Geno *)malloc((nloc+1) * sizeof(Geno));
      parcyt[i]=(int *)malloc((cyt+1) * sizeof(int));
      hs[i]=(double *)malloc((npar+2) * sizeof(double));
      fs[i]=(double *)malloc((npar+2) * sizeof(double));
      rel[i]=(int *)malloc((npar+2) * sizeof(int));
   }
  
  read_gen_dat_par(npar,name_par,pargen, parcyt, nloc, cyt); 

/*    f = fopen ("pchs", "w");    */
/*    g = fopen ("pcfs", "w");   */
  
  for (i=1; i<=npar; ++i)
    {
      for (j=1; j<=npar; ++j)	
	{ 
	if (j>i)
	  {
/* 	    printf("individu %d - individu %d \n", name_par[i], name_par[j]) ;  */
/* 	    printf("g�notype individu 1") ;  */
/* 	    print_geno(pargen[i], nloc); printf("\n");                */
/* 	    printf("g�notype individu 2") ;    */
/* 	    print_geno(pargen[j], nloc); printf("\n") ;             */
/* 	    verif_loc(pargen[i],pargen[j], nloc, pf);  */
	    hs[i][j]= half_sib(pargen[i],pargen[j],nloc, pf); /*lod score demi-fr�re*/
	    fs[i][j]= full_sib(pargen[i],pargen[j],nloc, pf); /*lod score plein-fr�re*/
	    if (hs[i][j] >= SEUIL_hs && fs[i][j] >= SEUIL_fs) rel[i][j]=1;
	    else  rel[i][j]=0;
	    /* 	         if ( f != NULL) fprintf(f,"  %5f  ",fs[i][j]);  */
 	    /*printf ("\n lodhs : %.2f ",  hs[i][j]);  */
	    /*printf ("lodfs : %.2f ",  fs[i][j]); */
	    /*printf ("relation : %d \n",  rel[i][j]);*/ 

	  }          
	}                                
    }
  
  /* Affichage des matrices de r�sultats  */
/*   printf("   Matrice des lod scores demi-fr�res\n");   */
/*   for (i=1; i<=npar-1; ++i) for (j=1; j<=npar; ++j) if (j>i) if ( f != NULL) fprintf(f,"  %5.2f  ",hs[i][j]);   */

/*   printf("   Matrice des lod scores plein-fr�res\n");   */
/*   for (i=1; i<=npar-1; ++i) for (j=1; j<=npar; ++j) if (j>i) if ( g != NULL) fprintf(g,"  %5.2f  ",fs[i][j]); */
  
/*      fclose (f);   */
/*      fclose (g);    */
  
   printf("\n   Half-sib lod scores matrix \n"); 
        printf("         "); 
        for (i=2; i<=npar; ++i)  printf("   %3d   ",name_par[i]); 
    	printf ("\n"); 
       for (i=1; i<=npar-1; ++i)         
	 {
	   printf("   %3d   ",name_par[i]);  
	   for (j=1; j<=npar; ++j)
	     {  
	       if (j<i) printf("         "); 
	       else if (j>i)  printf("  %5.2f  ",hs[i][j]);  
	     } 
	   printf ("\n"); 
	 } 
       printf ("\n"); 
  
       printf("  Full-sib lod scores matrix\n"); 
       printf("         "); 
       for (i=2; i<=npar; ++i)  printf("   %3d   ",name_par[i]); 
       printf ("\n"); 
       for (i=1; i<=npar-1; ++i)         
	 {
	   printf("   %3d   ",name_par[i]);  
	   for (j=1; j<=npar; ++j)	
	     {  
	       if (j<i) printf("         "); 
	       else if (j>i)  printf("  %5.2f  ",fs[i][j]);  
	     } 
	   printf ("\n"); 
	 } 
       printf("  Relatedness matrix (1 means half- or full-sibs, 0 means unrelated)\n"); 
       printf("         "); 
       for (i=2; i<=npar; ++i)  printf("   %3d   ",name_par[i]); 
       printf ("\n"); 
       for (i=1; i<=npar-1; ++i)         
	 {
	   printf("   %3d   ",name_par[i]);  
	   for (j=1; j<=npar; ++j)	
	     {  
	       if (j<i) printf("         "); 
	       else if (j>i)  printf("   %3d   ",rel[i][j]);  
	     } 
	   printf ("\n"); 
	 }      
  printf ("\n"); 
  return(0);
}

