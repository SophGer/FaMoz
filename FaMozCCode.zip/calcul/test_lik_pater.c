#include <math.h>
#include <stdio.h>
#include "nrutil.h"
#include "sort.h"
#include "read.h"
#include "genetic.h"
#include "likely.h"

/**************************************************************************

Program to tabulate possible parent pairs, and log-likelihoods, for given
sets of juveniles, potential fathers, and potential mothers.
Ordered to find best 4 mums, best 4 dads, best 4 pairs.
Includes possibility of X-linked loci.

Modified from earlier programs; July 1996

Programme modifi� pour consid�rer des hermaphrodites, et int�grer possibles 
autof�condations 25/11/98

*** Pourcentage d'erreur ajout� dans les calculs 26/11/98
(inspir� de Marshall et al 1998)
utilis� en lan�ant le programme suivi de < fichier
le fichier contient 
nb_loc nb_all_loc1 0 freq_all1_loc1 freq_all2_loc2.... nb_all_loc2 0 etc...
nb_parents nb_desc
num�ro_parent1 all1_loc1 all2_loc1 etc... 
le fichier likh est un fichier d'exemple pour ce programme
Donne les 8 meilleurs parents et couples dans l'ordre.
Modifi� le 18/12/98 pour prendre les log 
de la vraisemblance
8/3/99 Fait le test sur des donn�es lues dans un fichier (exemple, descendances
maternelles R. Streiff, pour test (testpm.txt)) renvoie les parents probables
de vraisemblances >= SEUIL_P et les couples probables tels que les parents aient une 
vraisemblances >= SEUIL_P et la vraisemblances du couple >= SEUIL_C
15/11/00 Adapted to FaMoz
17/1/03 test for paternity
gives a list of all father with a lod score greater than SEUIL_P
***************************************************************************/

extern double rans();

main (int argc, char *argv[])
{
  int i,j,k, ii, jj, kk, npod, mere, nb, nb_off_fath, *fath, miss, test_type, exae;
  int nloc, *nall, cyt, cytmater, *nallc, nkid, npar, *name_kid, *name_par, *name_mum, **kidcyt, **parcyt; 
  double *best_dads, *miss_dad, *missm_dad, *loclod, *delta, deltamax;
  double **pf, **pfc, E, SEUIL_F, SEUIL_d, *score, cc, bc, F, x, y;
  Geno **kidgen, **pargen;
  FILE *f;

  /* Reading arguments */
  E = atof(argv[1]);        /* mistyping percentage*/
  nb=atoi(argv[2]);         /* Number of most likely displayed */
  cyt=atoi(argv[3]);
  cytmater=atoi(argv[4]);
  F = atof(argv[5]); 
  miss=atoi(argv[6]);  
  exae=atoi(argv[7]);/*  if exae=1 no assignment in case of exaequo, if =0 assign anyway */
  test_type=atoi(argv[8]); /* test type 1: test on lod scores 2: test on delta 3: test on both values*/
  if (test_type==1)
    SEUIL_F=atof(argv[9]);  /* Lod-score threshold to choose a father as the true one */
  else if  (test_type==2)
    SEUIL_d=atof(argv[9]);  /* Delta threshold to choose a father as the true one */
  else if  (test_type==3){
    SEUIL_F=atof(argv[9]);  /* Lod-score threshold to choose a father as the true one */
    SEUIL_d=atof(argv[10]);  /* Delta threshold to choose a father as the true one */
  }

  scanf ("%d", &nloc);
  nall=(int *)malloc((nloc-cyt+1)*sizeof(int));
  if (cyt > 0) nallc=(int *)malloc((cyt+1)*sizeof(int));
  read_loci (nloc, nall, &pf, cyt, nallc, &pfc);
  
  printf("\n Number of loci: %d",nloc);
  printf(" of which %d cytoplasmic markers",cyt);
  scanf ("%d %d", &npar, &nkid);    
  printf ("\n Number of parents: %d offspring: %d\n", npar,nkid);
  printf("\n Lod calculation error: %f, Heterozygote deficit %f\n", E, F);
  if (test_type==1) 
    printf("\n Lod-score threshold to choose a father as the true one = %.2f ", SEUIL_F);
  else if (test_type==2) 
    printf("\n Delta threshold to choose a father as the true one = %.2f ", SEUIL_d);
  else if (test_type==3) 
    printf("\n Thresholds to choose a father as the true one Lod-score = %.2f Delta = %.2f\n", SEUIL_F, SEUIL_d);
  if (exae==1)  printf("\n No assignement if ex-aequo fathers\n");
  if (exae==0)  printf("\n Assign even if ex-aequo fathers\n");
  printf("\n Number of best fathers displayed: %d\n\n", nb); 
  printf(" For each likely father: \n"); 
  printf("  nb of missing locus / nb of loci with a > 0 contribution in score ");
  printf("\n   / nb of father-offspring mismatch among them \n");
 
  /*Allocation*/
  name_kid=(int *)malloc((nkid+1)*sizeof(int));
  name_mum=(int *)malloc((nkid+1)*sizeof(int));
  name_par=(int *)malloc((npar+1)*sizeof(int));
  kidgen=(Geno **)malloc((nkid+1) * sizeof(Geno *));
  pargen=(Geno **)malloc((npar+1) * sizeof(Geno *));
  score=(double *)malloc((nb+2)*sizeof(double));
  delta=(double *)malloc((nb+2)*sizeof(double));
  best_dads=(double *)malloc((nb+2)*sizeof(double));
  miss_dad=(double *)malloc((nb+2)*sizeof(double));
  missm_dad=(double *)malloc((nb+2)*sizeof(double));
  loclod=(double *)malloc((nb+2)*sizeof(double));
  kidcyt=(int **)malloc((nkid+1) * sizeof(int *));
  parcyt=(int **)malloc((npar+1) * sizeof(int *));
  fath=(int *)malloc((nkid+1) * sizeof(int));

  for (i=1; i<=nkid; i++) 
    {
      fath[i]=0;
      kidgen[i]=(Geno *)malloc((nloc-cyt+1) * sizeof(Geno));
      kidcyt[i]=(int *)malloc((cyt+1) * sizeof(int));
    }
  for (i=1; i<=npar; i++) 
    {
      pargen[i]=(Geno *)malloc((nloc-cyt+1) * sizeof(Geno));
      parcyt[i]=(int *)malloc((cyt+1) * sizeof(int));
    }
  read_gen_dat_pater (npar, name_par, pargen, parcyt, nkid, name_mum, name_kid, kidgen, kidcyt, nloc, cyt);

  f = fopen ("resfath", "w");  
  printf("\n ***** Compact results will be given in file \"resfath\"");
  printf("\n       Number of assigned fathers \n        (kid name, mother name, likely father name)\n");
  nb_off_fath=0; 
  
  for (i=1; i<=nkid; ++i)
    {
      printf ("\n kid %d, mother %d: ", name_kid[i], name_mum[i]);
      printf(" (%.0f missing data on %d alleles)\n", missing(kidgen[i], nloc-cyt), 2*(nloc-cyt));  
      for (ii=1;ii<=npar;++ii) 
	{
	  if (name_par[ii]==name_mum[i]) mere=ii; 
	}	    
      k=(nloc-cyt-match1 (kidgen[i], pargen[mere], nloc-cyt));
      if (k>0) printf(" !! Kid %d has %d missmatch/es with his mother %d !! \n", name_kid[i], k, name_par[mere]);
      npod=0; bc=1.0E6;
      for (k=0; k< nb+1; ++k)
	{
	  best_dads[k] =0; 
	  delta[k]=0.0;
	  score[k]=0.0;
	  miss_dad[k] =0; 
	  missm_dad[k] =0; 
	  loclod[k] =0;
	}
      for (j=1; j<=npar; ++j)
	{
 	  cc = pater(kidgen[i], pargen[mere], pargen[j], nloc-cyt, pf, E, F, nall, miss); 
 	  if (cyt > 0 && cytmater==0) cc+=likr_pat_cyt(cyt, kidcyt[i], parcyt[j], pfc, E, nallc);
	  if (cc > 0.0 && finite(cc)==1) 
	    { 
	      ++npod;
	      if (npod < nb+1) 
		{
		  best_dads[npod] = name_par[j]; 
		  score[npod]=cc; 
		  miss_dad[npod]=missing(pargen[j], nloc-cyt);
		  missm_dad[npod]=match2(kidgen[i], pargen[mere], pargen[j], nloc-cyt);
		  loclod[npod]=loc_lod_pater(kidgen[i], pargen[mere], pargen[j], nloc-cyt, pf, E, F, nall, miss);
		  if (cc < bc)  bc = cc; 
		} 
	      else
		{
		  if (cc > bc) 
		    {
		      k = dexmin(score, nb);
		      best_dads[k] = name_par[j];
		      score[k] = cc;
		      miss_dad[k]=missing(pargen[j], nloc-cyt);
		      missm_dad[k]=match2(kidgen[i], pargen[mere], pargen[j], nloc-cyt);
		      loclod[k]=loc_lod_pater(kidgen[i], pargen[mere], pargen[j], nloc-cyt, pf, E, F, nall, miss);
		      bc = valmin(score, nb); 
		    }
		}
	    }/* printf ("\n pc: %f \t",pc); */ 
	}
  
  sort5(nb,score,best_dads,miss_dad, missm_dad, loclod);			
  deltamax=score[nb];
  for (k=nb; k>=1; --k){ if (k==nb) delta[k]=deltamax; else if (k<nb && score[k]>0) delta[k]=deltamax-score[k];}
  
  /* Affichage */
  jj=0;
  kk=0;
 
  for (k=nb; k>=1; --k){
    if (test_type==1){
      if (score[k] > SEUIL_F) {
	if (exae==1 && (score[nb]==score[nb-1])) printf ("\tEx-aequo fathers: no assignment\n");
	else {
	  ++jj;
	  printf ("\tLikely father n� %d: %5.0f\tscore:  %5.2f",jj, best_dads[k], score[k]);
	  printf ("\t %3.0f/%3.0f/%3.0f", miss_dad[k], loclod[k], nloc-cyt-missm_dad[k]);  printf ("\n"); 
	  if (kk==0)  { fath[i] = best_dads[k]; kk+=1;} 
	}
      }
    }
    else if (test_type==2){
      if (delta[k] > SEUIL_d) {
	if (exae==1 && delta[k]==delta[k-1]) printf ("\tEx-aequo fathers: no assignment\n");
	else {
	  ++jj;
	  printf ("\tLikely father n� %d: %5.0f\tdelta:  %5.2f",jj, best_dads[k], delta[k]);
	  printf ("\t %3.0f/%3.0f/%3.0f", miss_dad[k], loclod[k], nloc-cyt-missm_dad[k]);  printf ("\n"); 
	  if (kk==0)  { fath[i] = best_dads[k]; kk+=1;} 
	}
      }
    }
    else if (test_type==3){
      if (score[k] > SEUIL_F && delta[k] > SEUIL_d) {
	if (exae==1 && (score[nb]==score[nb-1]) && (delta[nb]==delta[nb-1])) printf ("\tEx-aequo fathers: no assignment\n");
	else {
	  ++jj;
	  printf ("\tLikely father n� %d: %5.0f\tlod score:  %5.2f\tdelta:  %5.2f",jj, best_dads[k], score[k],delta[k]);
	  printf ("\t %3.0f/%3.0f/%3.0f", miss_dad[k], loclod[k], nloc-cyt-missm_dad[k]);  printf ("\n"); 
	  if (kk==0)  { fath[i] = best_dads[k]; kk+=1;} 
	}
      }
    }
  } 
  if (jj!=0)  nb_off_fath+=1;  
  if (jj==0)  
    {
      printf ("\tNo likely father inside the stand\n");	      
    }
  
  fflush(stdout);    
  
  }
  printf("\n Among %d offspring, %d have one father among the genotyped one", nkid, nb_off_fath);
  x=nkid-nb_off_fath;
  y=nkid;
  printf("\n Total gene flow \tnumber = %d \tpercentage = %.4f", nkid-nb_off_fath, x/y*100);
  printf ("\n");
  
  if ( f != NULL) fprintf (f, "\n %d ", nb_off_fath);  
  for (i=1; i<=nkid; i++) 
    if ( f != NULL && fath[i]!=0) fprintf (f, "\n %d %d %d", name_kid[i], name_mum[i], fath[i]);
  
  fclose(f);
  return(0); 
 
}







