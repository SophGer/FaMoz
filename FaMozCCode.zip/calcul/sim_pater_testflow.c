/**************** Programme sim_pater_testflow.c ********************/


#include <math.h>
#include <stdio.h>
/* #include <time.h> */  /* pour initialiser le g�n�rateur de nombres al�atoires*/
#include <sys/time.h>
#include <unistd.h>
#include <stdlib.h>     
#include "nrutil.h"
#include "read.h"
#include "sort.h"
#include "alea.h"
#include "genetic.h"
#include "likely.h"

/***************************************************************************
24/2/99
Fait des simulations :
Cr�e des descendants avec zero un ou deux parents dans la parcelle, selon un tirage aleatoire
parmi les POP individus de la population de reproduction totale.
Fait un test pour decider si on a zero un ou deux parents dans la parcelle
montre le resultat

19/6/01
Simulation of a population
- applying a test
- recording correct decision
- recording different types of gene flow events

6/1/06
Modified according to suggestions by Olivier Hardy to avoid 
the use of a reproductive population size. 
Include also an option for tests on lod score and/or delta
***************************************************************************/

extern double rans();


main (int argc, char *argv[])
{  
  int nloc, *nall, cyt, *nallc, cytmater, miss, test_type;         /* number of alleles */
  double **pf, **pfc, **fcum, **fcumc, E, Es, SEUIL_F, F, f, SEUIL_d;	 /* loci details; prior freqs; fr�quences cumul�es */
  int nkid, nkid1, npar, nmo, simo;			 /* individual names etc. */
  int *name_kid, *name_par, *mo, mere, **parcyt, **kidcyt;
  Geno **kidgen, **pargen; 	/* genotypic data */
  Geno  *kidpar;                /* nom des vrais parents du descendant*/
  int **dadgam, **mumgam;       /* Gam�tes paternel et maternel tir�s au hasard dans la pop/hors parcelle*/
  int i,j,k,l,ii,jj, kk, ll,  mum, dad, pp, ppo, agf, cgf, gfo, cgfo, agfo; 
  int npod, fazchoi, exae;
  double  best_dads[10];
  double score[10], cc, bc, bch, total, pcbc, ogf, delta[10], deltamax;
  double agff, cgff, tgf, rgf, alpha, agffo, pagffo, pagff, ppf, nkidf, nmof;


  /* initialisation du g�n�rateur de nombres al�atoires :*/
  long m;
  float rand;
  struct timeval temps; 
  struct timezone  zone;
  gettimeofday(&temps,&zone);
  m=-temps.tv_usec; 
  rand=ran3(&m);
  
  /* Reading arguments */
  nmo=atoi(argv[1]);   /*  Number of mother */
  nkid=atoi(argv[2]);  /*  Number of kid per mother */
  Es=atof(argv[3]);      /* Simulation error */
  E=atof(argv[4]);     /* Lod calculation error */
  simo=atoi(argv[5]);   /* Pick mother in a random manner (simo=0) or determine mothers in a list */
  cyt=atoi(argv[6]);
  cytmater=atoi(argv[7]); /* Maternal heredity of cytoplasme : yes=1 */
  F=atof(argv[8]);
  miss=atoi(argv[9]); /*miss=0, skip missing data*/
  ogf=atof(argv[10]); 
  exae=atoi(argv[11]);/*  if exae=1 no assignment in case of exaequo, if =0 assign anyway */
  /* observed gene flow (% of offspring with no father) after the paternity analysis on real data,*/
  test_type=atoi(argv[12]); /* test type 1: test on lod scores 2: test on delta 3: test on both values*/
  if (test_type==1)
    SEUIL_F=atof(argv[13]);  /* Lod-score threshold to choose a father as the true one */
  else if  (test_type==2)
    SEUIL_d=atof(argv[13]);  /* Delta threshold to choose a father as the true one */
  else if  (test_type==3){
    SEUIL_F=atof(argv[13]);  /* Lod-score threshold to choose a father as the true one */
    SEUIL_d=atof(argv[14]);  /* Delta threshold to choose a father as the true one */
  }
  mo=(int *)malloc((nmo+1)*sizeof(int));

  if (simo > 0){
    if (test_type==3)
      for (i=1; i<=nmo; i++) mo[i]=atoi(argv[13+i]);
    else
      for (i=1; i<=nmo; i++) mo[i]=atoi(argv[12+i]);
    printf("\n The %d mothers are the following: \n", nmo);
    for (i=1; i<=nmo; i++) 	printf("\t %d ", mo[i]);
  }
  else printf("\n The %d mothers will be selected at random", nmo);
 
  /*Initialisations*/ 
  bch=0.0; total=0.0; pcbc=0.0; 
  pp=0; ppo=0;
  cgf=0; agf=0; gfo=0; cgfo=0; agfo=0;
  
  /* Lecture des donn�es locus */
  scanf ("%d", &nloc);
  nall=(int *)malloc((nloc-cyt+1)*sizeof(int));
  if (cyt > 0) nallc=(int *)malloc((cyt+1)*sizeof(int));

  read_loci_cum (nloc, nall, &pf, &fcum, cyt, nallc, &pfc, &fcumc);

  printf("\n Number of loci: %d",nloc);
  scanf ("%d %d", &npar, &nkid1);
  printf ("\n Number of genotyped parents: %d", npar);
  printf ("\n Number of mother: %d, number of simulated offspring per mother: %d", nmo, nkid);
  printf ("\n %% Gene flow observed in the real paternity experiment: %f", ogf);
  printf("\n Simulation error %f, Lod calculation error %f, Heterozygote deficit %f", Es, E, F);    
  if (test_type==1) 
    printf("\n Lod-score threshold to choose a father as the true one = %.2f ", SEUIL_F);
  else if (test_type==2) 
    printf("\n Delta threshold to choose a father as the true one = %.2f ", SEUIL_d);
  else if (test_type==3) 
    printf("\n Thresholds to choose a father as the true one Lod-score = %.2f Delta = %.2f\n", SEUIL_F, SEUIL_d);
  if (exae==1)  printf("\n No assignement if ex-aequo fathers\n");
  if (exae==0)  printf("\n Assign even if ex-aequo fathers\n");

  l=nmo*nkid;
  if (l>=npar) ll=l; else ll=npar;

  name_kid=(int *)malloc((ll+1)*sizeof(int));
  kidgen=(Geno **)malloc((ll+1) * sizeof(Geno *));
  pargen=(Geno **)malloc((ll+1) * sizeof(Geno *));
  kidpar=(Geno *)malloc((ll+1) * sizeof(Geno));
  name_par=(int *)malloc((ll+1)*sizeof(int));
  dadgam=(int **)malloc((ll+1) * sizeof(int *));
  mumgam=(int **)malloc((ll+1) * sizeof(int *));
  parcyt=(int **)malloc((ll+1) * sizeof(int *));
  kidcyt=(int **)malloc((ll+1) * sizeof(int *));
  
  for (i=1; i<=ll; i++){
    kidgen[i]=(Geno *)malloc((nloc-cyt+1) * sizeof(Geno));
    kidcyt[i]=(int *)malloc((cyt+1) * sizeof(int));
    pargen[i]=(Geno *)malloc((nloc-cyt+1) * sizeof(Geno));  
    mumgam[i]=(int *)malloc((nloc+1) * sizeof(int));
    dadgam[i]=(int *)malloc((nloc+1) * sizeof(int));      
    parcyt[i]=(int *)malloc((cyt+1) * sizeof(int));
  }
  
  read_gen_dat_par(npar, name_par, pargen, parcyt, nloc, cyt);   

  /* Cr�ation de descendants*/  
  /* First simulate offspring with genotyped parents */

  for (ii=1;ii<=nmo;++ii){ 
    k=0;
    if (simo > 0) /* Choose mothers in a list given by user */
      {
	for (i=1;i<=npar;++i)	      
	  {
	    if ( mo[ii]==name_par[i]) 
	      {
		mum=i; 
		k+=1;
	      }
	  }
	if (k==0) printf("\n Mother %d is not part of your genotyped individuals\n", mo[ii]);
      }
    else 
      {
	mum = 1+(int)(npar*alea()) ;   /* Determine mother at random  */
	mo[ii]=name_par[mum];
      }
    for (jj=(1+(ii-1)*nkid);jj<=(nkid+(ii-1)*nkid);++jj){ 
      name_kid[jj]=jj;
      gamete(pargen[mum], mumgam[mum], nloc, nall, Es, cyt, nallc, parcyt[mum]);
      f=alea();
      if (f<=2*F/(1+F)) {dad=mum; gamete(pargen[mum], dadgam[dad], nloc, nall, Es, cyt, nallc, parcyt[mum]);}
      /*selfing at equilibrium = [2*F/(1+F)] */
      else dad = 1+(int)(npar*alea()) ; 
      gamete(pargen[dad],dadgam[dad],nloc, nall, Es, cyt, nallc, parcyt[dad]);
      kidpar[jj].g1=mo[ii];
      kidpar[jj].g2=name_par[dad];   /* Nom du p�re */ 
      for (kk=1;kk<=nloc-cyt;++kk)
	{
	  kidgen[jj][kk].g1=mumgam[mum][kk];  /* jj :enfant, kk locus*/
	  kidgen[jj][kk].g2=dadgam[dad][kk];   
	}  
      if  (cyt > 0) 
	{
	  if (cytmater==1) for (kk=nloc-cyt+1;kk<=nloc;++kk)  kidcyt[jj][kk-nloc+cyt] = mumgam[mum][kk];  
	  else if (cytmater==0) for (kk=nloc-cyt+1;kk<=nloc;++kk)  kidcyt[jj][kk-nloc+cyt] = dadgam[dad][kk];  
	} 
      /*     printf("desc n�%d", jj); print_geno_cyt(kidgen[jj], kidcyt[jj], nloc, cyt); */
    }
  }
  /* Looking for most likely fathers */
  for (i=1; i<=nkid*nmo; ++i){	   
    npod=0; bc=1.0E6;
    for (k=0; k< 10; ++k)
      {
	best_dads[k] =0; 
	score[k]=0.0;
      }
    
    for (j=1; j<=npar; ++j)
      {  
	for (ii=1;ii<=npar;++ii) 
	  {
	    if (kidpar[i].g1==name_par[ii]) 
	      mere=ii;
	  }
	cc = pater(kidgen[i], pargen[mere], pargen[j], nloc-cyt, pf, E, F, nall, miss);
	if (cyt > 0 && cytmater==0) cc+=likr_pat_cyt(cyt, kidcyt[i], parcyt[j], pfc, E, nallc);
	if (cc > 0.0) 
	  { 
	    ++npod;
	    if (npod < 9) 
	      {
		best_dads[npod] = name_par[j]; 
		score[npod]=cc; 
		if (cc < bc)  bc = cc; 
	      } 
	    else
	      {
		if (cc > bc) 
		  {
		    k = dexmin(score, 8);
		    best_dads[k] = name_par[j];
		    score[k] = cc;
		    bc = valmin(score, 8); 
		  }
	      }
	  }
      }
    sort2(8,score,best_dads);			
    deltamax=score[8];
    for (k=8; k>=1; --k){ if (k==8) delta[k]=deltamax; else if (score[k]>0) delta[k]=deltamax-score[k];}
        
    /* Affichage avec le test*/
    k=8;
    if(exae==0) {
      if (test_type==1)
	{
	  if (score[k] > SEUIL_F) fazchoi = best_dads[k];
	  else fazchoi = -5;
	  if (fazchoi == kidpar[i].g2) ++pp;
	}
      else if (test_type==2)
	{
	  if (delta[k] > SEUIL_d) fazchoi = best_dads[k];
	  else fazchoi = -5;
	  if (fazchoi == kidpar[i].g2) ++pp;
	}
      else if (test_type==3)
	{
	  if (score[k] > SEUIL_F && delta[k] > SEUIL_d) fazchoi = best_dads[k];
	  else fazchoi = -5;
	  if (fazchoi == kidpar[i].g2) ++pp;
	}
    }
    
    else if(exae==1) {      
      if (test_type==1)
	{
	  if (score[k] > SEUIL_F  && (score[k]!=score[k-1]) ) fazchoi = best_dads[k];
	  else fazchoi = -5;
	  if (fazchoi == kidpar[i].g2) ++pp;
	}
      else if (test_type==2)
	{
	  if (delta[k] > SEUIL_d  && (delta[k]!=delta[k-1]) ) fazchoi = best_dads[k];
	  else fazchoi = -5;
	  if (fazchoi == kidpar[i].g2) ++pp;
	}
      else if (test_type==3)
	{
	  if (score[k] > SEUIL_F && delta[k] > SEUIL_d  && ((score[k]!=score[k-1]) && (delta[k]!=delta[k-1])) ) fazchoi = best_dads[k];
	  else fazchoi = -5;
	  if (fazchoi == kidpar[i].g2) ++pp;
	}    
    }
    /* Calcul des flux de g�nes apparents (agf), cach� (cgf)*/
    
    if (fazchoi == -5) ++agf;
    if (fazchoi != -5 && kidpar[i].g2 == (-5)) ++cgf;
/* printf("\ndesc n�%d vrai p�r %d p�rechoix %d best_dads[8] %.0f delta[8] %.2f best_dads[7] %.0f delta[7] %.2f agf %d cgf %d", i, kidpar[i].g2, fazchoi, best_dads[8], delta[8],best_dads[7], delta[7], agf, cgf);  */
  }    

  /* Next, simulate offspring with random genotypes */

  for (ii=1;ii<=nmo;++ii){ 
    k=0;
    if (simo > 0) /* Choose mothers in a list given by user */
      {
	for (i=1;i<=npar;++i)	      
	  {
	    if ( mo[ii]==name_par[i]) 
	      {
		mum=i; 
		k+=1;
	      }
	  }
	if (k==0) printf("\n Mother %d is not part of your genotyped individuals\n", mo[ii]);
      }
    else 
      {
	mum = 1+(int)(npar*alea()) ;   /* Determine mother at random  */
	mo[ii]=name_par[mum];
      }
    
    for (jj=(1+(ii-1)*nkid);jj<=(nkid+(ii-1)*nkid);++jj){ 
      name_kid[jj]=jj;
      gamete(pargen[mum], mumgam[mum], nloc, nall, Es, cyt, nallc, parcyt[mum]);
      f=alea();
      dad=jj;
      if (f<=2*F/(1+F)) gamete(pargen[mum], dadgam[dad], nloc, nall, Es, cyt, nallc, parcyt[mum]);     
      /*selfing at equilibrium = [2*F/(1+F)] */ 
      else gamete_hp(dadgam[dad], nloc, nall, fcum, cyt, nallc, fcumc);  
      kidpar[jj].g1=mo[ii];
      kidpar[jj].g2=-5;  /* Nom du p�re (=-5 si hors parcelle) */ 
      for (kk=1;kk<=nloc-cyt;++kk)
	{
	  kidgen[jj][kk].g1=mumgam[mum][kk];  /* jj :enfant, kk locus*/
	  kidgen[jj][kk].g2=dadgam[dad][kk];   
	}  
      if  (cyt > 0) 
	{
	  if (cytmater==1) for (kk=nloc-cyt+1;kk<=nloc;++kk)  kidcyt[jj][kk-nloc+cyt] = mumgam[mum][kk];  
	  else if (cytmater==0) for (kk=nloc-cyt+1;kk<=nloc;++kk)  kidcyt[jj][kk-nloc+cyt] = dadgam[jj][kk];  
	} 
      /*     printf("desc n�%d", jj);  print_geno_cyt(kidgen[jj], kidcyt[jj], nloc, cyt); */
    }
  }	    
  
  /* Looking for most likely fathers */
  for (i=1; i<=nkid*nmo; ++i){	   
    npod=0; bc=1.0E6;
    for (k=0; k< 10; ++k)
      {
	best_dads[k] =0; 
	score[k]=0.0;
      }
    
    for (j=1; j<=npar; ++j)
      {  
	for (ii=1;ii<=npar;++ii) 
	  {
	    if (kidpar[i].g1==name_par[ii]) 
	      mere=ii;
	  }
	cc = pater(kidgen[i], pargen[mere], pargen[j], nloc-cyt, pf, E, F, nall, miss);
	if (cyt > 0 && cytmater==0) cc+=likr_pat_cyt(cyt, kidcyt[i], parcyt[j], pfc, E, nallc);
	if (cc > 0.0) 
	  { 
	    ++npod;
	    if (npod < 9) 
	      {
		best_dads[npod] = name_par[j]; 
		score[npod]=cc; 
		if (cc < bc)  bc = cc; 
	      } 
	    else
	      {
		if (cc > bc) 
		  {
		    k = dexmin(score, 8);
		    best_dads[k] = name_par[j];
		    score[k] = cc;
		    bc = valmin(score, 8); 
		  }
	      }
	  }
      }
    sort2(8,score,best_dads);			
    deltamax=score[8];
    for (k=8; k>=1; --k){ if (k==8) delta[k]=deltamax; else delta[k]=deltamax-score[k];}
        
    /* Affichage avec le test*/
    k=8;
    if(exae==0) {
      if (test_type==1)
	{
	  if (score[k] > SEUIL_F) fazchoi = best_dads[k];
	  else fazchoi = -5;
	  if (fazchoi == kidpar[i].g2) ++ppo;
	}
      else if (test_type==2)
	{
	  if (delta[k] > SEUIL_d) fazchoi = best_dads[k];
	  else fazchoi = -5;
	  if (fazchoi == kidpar[i].g2) ++ppo;
	}
      else if (test_type==3)
	{
	  if (score[k] > SEUIL_F && delta[k] > SEUIL_d) fazchoi = best_dads[k];
	  else fazchoi = -5;
	  if (fazchoi == kidpar[i].g2) ++ppo;
	}
    }
    
    else if(exae==1) {      
      if (test_type==1)
	{
	  if (score[k] > SEUIL_F  && (score[k]!=score[k-1]) ) fazchoi = best_dads[k];
	  else fazchoi = -5;
	  if (fazchoi == kidpar[i].g2) ++ppo;
	}
      else if (test_type==2)
	{
	  if (delta[k] > SEUIL_d  && (delta[k]!=delta[k-1]) ) fazchoi = best_dads[k];
	  else fazchoi = -5;
	  if (fazchoi == kidpar[i].g2) ++ppo;
	}
      else if (test_type==3)
	{
	  if (score[k] > SEUIL_F && delta[k] > SEUIL_d  && ((score[k]!=score[k-1]) && (delta[k]!=delta[k-1])) ) fazchoi = best_dads[k];
	  else fazchoi = -5;
	  if (fazchoi == kidpar[i].g2) ++ppo;
	}    
    }
    
    /* Calcul des flux de g�nes outside (gfo) apparents (agfo), cach� (cgfo)*/
    
    if (kidpar[i].g2 ==-5) ++gfo;
    if (fazchoi == -5) ++agfo;
    if (fazchoi != -5 && kidpar[i].g2 == (-5)) ++cgfo;   
    /*     printf("desc n�%d vrai p�re %d p�re choisi %d score %f\n", i, kidpar[i].g2, fazchoi, score[8]); */
  }    
  /*   printf("\nppo = %d agfo = %d", ppo, agfo); */
  fflush(stdout);
  printf ("\n");
  bch=pp+ppo;
  nkidf=nkid;
  nmof=nmo;
  total=nkidf*nmof;
  pcbc=(bch/(2*total))*100;
  printf("\n\n*** Results ***\n\n");
  printf("\n Percentage of correct father choice = \t%8.2f \n",pcbc);
  
  printf("\n");
  agff=agf;
  cgff=cgf;
  agffo=agfo;

  printf(" Number of paternity correctly assigned \t%d \n",pp);  
  ppf=pp;
  printf(" Percentage of paternity correctly assigned \n");
  printf("         among the assigned paternities = \t%8.2f \n\n",100*(ppf)/(2*total-agff-agffo));  

  /*Gene flow calculation according to Olivier Hardy's method */
  agffo=agfo;
  pagffo=agffo/total;
  pagff=agff/total;
  tgf=(ogf-pagff)/(pagffo-pagff);
  rgf=tgf*pagffo; /*true gene flow*/
  cgff=tgf*(1-pagffo); /*cryptic gene flow = beta or type II error, assign a father when the true father is outside*/
  alpha=(1-tgf)*pagff; /*alpha or type I error, assign no father when the true father is inside*/
/*    printf("\nnkid= %d, nmo= %d, total (nmo*nkid)= %10.2f tgf= %10.2f, rgf= %10.2f, agfo= %d\n", nkid, nmo, total, tgf, rgf, agfo); */
  printf("Apparent gene flow ('gfo', true) when offspring are generated with no genotyped father:\n \tpercentage = %8.4f \tnumber = %8.0f\n",pagffo*100, agffo);
  printf("Apparent gene flow ('gfi', untrue) when offspring are generated with genotyped fathers:\n \tpercentage = %8.4f \tnumber = %8.0f\n",pagff*100, agff);
  printf("The true gene flow ('tgf') and the gene flow observed in the paternity experiment ('ogf') are connected:\n");
  printf("\togf = tgf*gfo + (1-tgf)*gfi = real gene flow + alpha errors\n");
  printf("\ttgf is calculated thanks to this expression tgf = (ogf-gfi)/(gfo-gfi)\n");
  printf("Cryptic gene flow ('cgf' or beta) is deduced:  \tcgf = tgf*(1-gfo) \n");
  printf("Alpha is deduced:  \t\talpha = (1-tgf)gfi \n\n");

  printf("Real gene flow:  \tpercentage %8.4f \tnumber = %8.0f\n", rgf*100, rgf*total);
  printf("Cryptic gene flow:  \tpercentage %8.4f \tnumber = %8.0f\n", cgff*100,cgff*total);
  printf("-> Equivalent to beta or type II error, assign a father when the true father is outside \n");
  printf("Alpha or type I error:  \tpercentage %8.4f \tnumber = %8.0f\n", alpha*100, alpha*total);
  printf("-> Assign no father when the true father is inside \n");


  /*   printf(" On a total of %.0f gametes produced: \n",2*total); */
  /*   printf(" - expected* gene flow =  \t%10.0f\n", att); */
  /*   printf(" - true** gene flow =    \t%10d \n", gf); */
  /*   printf(" - apparent� gene flow =  \t%10d \n", agf); */
  /*   printf(" - cryptic�� gene flow =  \t%10d \n", cgf); */
  /*   printf("\n Percentages: \n - true/apparent = \t%10.2f \n - cryptic/apparent = \t%10.2f", (gff/agff)*100,(cgff/agff100)); */
  
  /*   printf("\n\n* [(Total reproducing population size - number of genotyped parent)/ Total reproducing population size]"); */
  /*   printf("\n\t\t  * number of simulated gametes"); */
  /*   printf("\n** Actual number of times a parent different from the genotyped parents produced one of the offspring."); */
  /*   printf("\n� Number of times no genotyped parent was detected for the simulated offspring,\n  according to the statistical tests.");*/
  /*   printf("\n�� Number of times a parent had been detected among the genotyped parent\n "); */
  /*   printf("according to the statistical tests whereas the true parent was not part of them."); */
  /*   printf("\n"); */
  
  return(0);
  
}

