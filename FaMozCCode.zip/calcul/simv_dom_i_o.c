
#include <math.h>
#include <stdio.h>
/* #include <time.h> */  /* pour initialiser le g�n�rateur de nombres al�atoires*/
#include <sys/time.h>
#include <unistd.h>
#include <stdlib.h>     
#include "nrutil.h"
#include "read.h"
#include "sort.h"
#include "alea.h"
#include "genetic.h"
#include "likely.h"

/**************************************************************************

Program to tabulate possible parent pairs, and log-likelihoods, for given
sets of juveniles, potential fathers, and potential mothers.
Ordered to find best 4 mums, best 4 dads, best 4 pairs.
Includes possibility of X-linked loci.

Modified from earlier programs; July 1996

Programme modifi� pour consid�rer des hermaphrodites, et int�grer possibles 
autof�condations 25/11/98

*** Pourcentage d'erreur ajout� dans les calculs 26/11/98
(inspir� de Marshall et al 1998)
utilis� en lan�ant le programme suivi de < fichier
le fichier contient 
nb_bandes  freq_bande1 freq_bande2 etc...
nb_parents nb_desc
num�ro_parent1 etat_bande_1 �tat_bande_2_ etc... 
Donne les 8 meilleurs parents et couples dans l'ordre.
Modifi� le 18/12/98 pour prendre les ln 
de la vraisemblance

Fait des simulations sur marqueurs AFLP :
cr�e des descendants intra parcelle, stocke en m�moire les vrais parents :
- meilleurs 2 parents d'apr�s les vraisemblances
- meilleur couple
Stocke les vraisemblance : 
Vraisemblances des parents choisis avec une bonne d�cision : fichier Parbd
                                            mauvaise                 Parmd
Vraisemblances des couples choisis avec une bonne d�cision : fichier Coupbd
                                            mauvaise                 Coupmd
Fr�quences de bonnes d�cisions.

6/10/00 adapted to FaMoz.tcl (malloc, argv etc.) before leaving in hollidays
10/01 Combining outside/inside simulations

***************************************************************************/


extern double rans();

main (int argc, char *argv[])
{
  char *name1, *name2, *name3, *name4, *name5, *name6;
  int nloc, nkid, nkid1, npar, *name_par, *name_kid, **kidgen, **pargen, **dadgam, **mumgam;
  int i,j,k,ii,jj, kk, iii, jjj, tp1,tp2, mum, dad, bdp, mdp, bdc, mdc, cyt, *nallc, **kidcyt, **parcyt; 
  int npop, *listp, npopp, bp, bc1, bc2, cytmater, io;
  double   E, Es, F, f, *pf, **pfc, **fcumc, bdcf, bdpf;
  double best_mums[10], best_dads[10],  best_pars[10], best_pairs[2][10];
  double score[10], pcore[10], cc, bc, pc;
  Geno *kidpar;
  double *bestp1, *bestp2, *bestp, *bestc, x, y;
  /* these last lines are for creating an histogram of best parents and couple of simulated offspring */
  double *deltatrue, *deltawrong, *deltawrongi, *deltawrongo1,*deltawrongo2 , deltamax, delta1, delta2;
  double *deltatrueC, *deltawrongC, *deltawrongiC, *deltawrongo1C,*deltawrongo2C;

  
  /* initialisation du g�n�rateur de nombres al�atoires :*/
  long m;
  float rand;
  struct timeval temps; 
  struct timezone  zone;
  gettimeofday(&temps,&zone);
  m=-temps.tv_usec; 
  rand=ran3(&m);

  /* Reading arguments */
  nkid=atoi(argv[1]);
  E=atof(argv[2]); 
  Es=atof(argv[3]);
  cyt=atoi(argv[4]);
  cytmater=atoi(argv[5]);
  io=atoi(argv[6]);
  F=atof(argv[7]); 

  name1 = "Single parent";
  name2 = "Parent pair";
  name3 = "Delta, true parents";
  name4 = "Delta, true parent pairs";
  name5 = "Delta, wrong parents";
  name6 = "Delta, wrong parent pairs";
  
  /* Lecture des donn�es locus */
  scanf ("%d", &nloc);
  pf=(double *)malloc((nloc-cyt+1) * sizeof(double));
  if (cyt > 0) nallc=(int *)malloc((cyt+1)*sizeof(int));
  read_loci_dom_cum (nloc, cyt, nallc, pf, &pfc, &fcumc);
  printf("\n Number of loci: %d",nloc);  
  printf("\n Of which %d cytoplasmic markers",cyt);
  scanf ("%d %d", &npar, &nkid1);
  printf ("\n Number of parents: %d, Number of simulated offspring: %d\n", npar,nkid);

  if (io==1) printf("\n***** Simulating offpring with genotyped parents *****\n");
  if (io==2) printf("\n***** Simulating offpring according to allele frequencies *****\n");

  if (io==1) printf("\n Simulation error %f",Es);    
  printf("\n Lod calculation error %f, Heterozygote deficit %f\n",E, F);    

  
  listp=(int *)malloc((npar+1)*sizeof(int));
  name_kid=(int *)malloc((nkid+1)*sizeof(int));
  name_par=(int *)malloc((npar+1)*sizeof(int));
  kidgen=(int **)malloc((nkid+1) * sizeof(int *));
  kidpar=(Geno *)malloc((nkid+1) * sizeof(Geno));
  pargen=(int **)malloc((npar+1) * sizeof(int *));
  kidcyt=(int **)malloc((nkid+1) * sizeof(int *));
  parcyt=(int **)malloc((npar+1) * sizeof(int *));

  if (io==1)  
    {
      mumgam=(int **)malloc((npar+1) * sizeof(int *));
      dadgam=(int **)malloc((npar+1) * sizeof(int *));
      for (i=1; i<=npar; i++) 
	{
	  mumgam[i]=(int *)malloc((nloc+1) * sizeof(int));
	  dadgam[i]=(int *)malloc((nloc+1) * sizeof(int));
	}
    }
  else if (io==2)  
    {
      mumgam=(int **)malloc((nkid+1) * sizeof(int *));
      dadgam=(int **)malloc((nkid+1) * sizeof(int *));
      for (i=1; i<=nkid; i++) 
	{
	  mumgam[i]=(int *)malloc((nloc+1) * sizeof(int));
	  dadgam[i]=(int *)malloc((nloc+1) * sizeof(int));
	}
    }  

  for (i=1; i<=nkid; i++)
    {
      kidgen[i]=(int *)malloc((nloc-cyt+1) * sizeof(int));      
      kidcyt[i]=(int *)malloc((cyt+1) * sizeof(int));
    }
  for (i=1; i<=npar; i++) 
    {
      pargen[i]=(int *)malloc((nloc-cyt+1) * sizeof(int));
      parcyt[i]=(int *)malloc((cyt+1) * sizeof(int));
    }
  
  read_gen_dat_par_dom (npar, name_par, pargen, nloc, cyt, parcyt);

  /*initialisations*/
  bdc=0; mdc=0; bdp=0; mdp=0; iii=1; jjj=1; 
  
  /* Cr�ation de descendants*/
  printf("\n Simulation step");
  if(io==1)
    {
      for (ii=1;ii<=nkid;++ii) 
	{
	  name_kid[ii]=ii; 
	  mum = 1+(int)(npar*alea()) ;         /* Tirage al�atoire des deux parents : */ 
	  f=alea();
	  if (f<=2*F/(1+F)) dad=mum;         /*selfing at equilibrium = [2*F/(1+F)] */
	  else dad = 1+(int)(npar*alea()) ;         /* nombre entier al�atoire dans [1,npar] */  
	  gamete_dom(pargen[mum],mumgam[mum], parcyt[mum], nloc, Es, pf, cyt, nallc); /* Simulation des gam�tes parentaux : */  
	  gamete_dom(pargen[dad],dadgam[dad], parcyt[dad], nloc, Es, pf, cyt, nallc); 
	  kidpar[ii].g1=name_par[mum];  
	  kidpar[ii].g2=name_par[dad];   
	  for (jj=1;jj<=nloc-cyt;++jj) 
	    {
	      if (mumgam[mum][jj] == 0 && dadgam[dad][jj] == 0) kidgen[ii][jj] = 0;
	      /* ii :enfant, jj locus*/ 
	      else if (mumgam[mum][jj] == 1 || dadgam[dad][jj] == 1) kidgen[ii][jj] = 1;   
	    }
	  if  (cyt > 0) 
	    {
	      if (cytmater==1) for (kk=nloc-cyt+1;kk<=nloc;++kk)  kidcyt[ii][kk-nloc+cyt] = mumgam[mum][kk];  
	      else if (cytmater==0) for (kk=nloc-cyt+1;kk<=nloc;++kk)  kidcyt[ii][kk-nloc+cyt] = dadgam[dad][kk];  
	    }
	  /*printf("\n kidgen %d ", ii); print_geno_dom(kidgen[ii], nloc); printf("\n");   */
	  /*for (k=1;k<=npar;++k) {if (name_par[k]==kidpar[ii].g1) { printf(" par 1 %d",kidpar[ii].g1); */
	  /*print_geno_dom(pargen[k], nloc);}} printf("\n");      */
	  /*for (k=1;k<=npar;++k) {if (name_par[k]==kidpar[ii].g2) { printf(" par 2 %d",kidpar[ii].g2); */
	  /*print_geno_dom(pargen[k], nloc);}} printf("\n");         */
	}
   } 
  else if (io==2)
    {      
      for (ii=1;ii<=nkid;++ii)
	{ 
	  name_kid[ii]=ii;      
	  gamete_hp_dom(mumgam[ii], nloc, pf, cyt, nallc, fcumc); /* Simulation des gam�tes parentaux : */ 
	  gamete_hp_dom(dadgam[ii], nloc, pf, cyt, nallc, fcumc);
	  for (jj=1;jj<=nloc-cyt;++jj)
	    {
	      f=alea();
	      if (mumgam[ii][jj] == 0)
		{ if( f<=F || dadgam[ii][jj] == 0) kidgen[ii][jj] = 0;  /* ii :enfant, jj locus*/}
	      else if(mumgam[ii][jj] == 1 || dadgam[ii][jj] == 1) kidgen[ii][jj] = 1; 
	    }  
	  if  (cyt > 0)
	    {
	      if (cytmater==1) for (jj=nloc-cyt+1;jj<=nloc;++jj)  kidcyt[ii][jj-nloc+cyt] = mumgam[ii][jj];             
	      else if (cytmater==0) for (jj=nloc-cyt+1;jj<=nloc;++jj)  kidcyt[ii][jj-nloc+cyt] = dadgam[ii][jj];  
	    }
	  /*printf("kidgen simul� %d", ii); print_geno_dom(kidgen[ii], nloc); printf("\n");   */
	}
   }
  
  printf("\n End of simulation step \n");
  printf("\n Calculation step");	

  /* 	First allocate memory to store data: draw a histogram later thanks to them */
  
  bestp1=(double *)malloc((nkid+1)*sizeof(double));
  bestp2=(double *)malloc((nkid+1)*sizeof(double));
  bestp=(double *)malloc((2*nkid+1)*sizeof(double));
  bestc=(double *)malloc((nkid+1)*sizeof(double));	
  deltatrue=(double *)malloc((2*nkid+1)*sizeof(double));
  deltawrongi=(double *)malloc((2*nkid+1)*sizeof(double));
  deltawrongo1=(double *)malloc((nkid+1)*sizeof(double));
  deltawrongo2=(double *)malloc((nkid+1)*sizeof(double));
  deltawrong=(double *)malloc((4*nkid+1)*sizeof(double));
  deltatrueC=(double *)malloc((2*nkid+1)*sizeof(double));
  deltawrongiC=(double *)malloc((2*nkid+1)*sizeof(double));
  deltawrongo1C=(double *)malloc((nkid+1)*sizeof(double));
  deltawrongo2C=(double *)malloc((nkid+1)*sizeof(double));
  deltawrongC=(double *)malloc((4*nkid+1)*sizeof(double));
  
  for (i=1; i<=(nkid +1); i++)       {bestp1[i]=0.0; bestp2[i]=0.0; bestc[i]=0.0;}
  for (i=1; i<=(2*nkid +1); i++)	    bestp[i]=0.0;
    
  for (i=1; i<=nkid; ++i)
    {   
      /*printf ("\t%5d\t", name_kid]); printf ("\b\b\b\b\b\b\b\b\b\b");     */
/*       printf ("\n kid %d mum %d dad %d \n", name_kid[i], kidpar[i].g1, kidpar[i].g2);     */
/*       print_geno_dom(kidgen[i],nloc); printf("\n");      printf("\n");       */
      
      npopp=0; npop=0;  bc=1.0E6; pc = 1.0E6; /* Number Possible Parent / Pairs */
      
      /* Calcul des vraisemblances des parents pour chaque descendant */
      
      for (k=0; k< 10; ++k)
	{
	  best_mums[k] =0; score[k]=0.0; 
	  best_dads[k] =0; best_pars[k] =0; pcore[k]=0.0;
	  best_pairs[0][k]=0; best_pairs[1][k]=0; 
	}
      for (j=1; j<=npar; ++j)
	{
	  cc = uparchk_dom(nloc-cyt,kidgen[i],pargen[j], pf, E, F); /* proba maternit�:non maternit�*/
	  /*printf("\n kid %d par %d score %f \n", name_kid[i], name_par[j], cc); */
	  if (cyt > 0) cc+=likr_cyt(cyt, kidcyt[i], parcyt[j], pfc, E, nallc);
	  if (cc > 0.0 && finite(cc)==1)
	    { 
	      ++npop; listp[npop]=j; /*rang de tous les parents � proba > 0,npop observations*/
	      if (npop < 9) 
		{
		  best_pars[npop] = name_par[j]; 
		  score[npop]=cc; 
		  if (cc < bc)  bc = cc; 
		} /* bc sera le score min parmi les 8 premiers >0 */
	      else
		{
		  if (cc > bc) /*score sup�rieur au min pr�c�dent*/
		    {
		      k = dexmin(score, 8); /* rang du score minimum parmi les 8*/
		      best_pars[k] = name_par[j];  /*on remplace la m�re k  ...  */
		      score[k] = cc;               /* par la j, qui est meilleure */ 
		      bc = valmin(score, 8); 
		    }
		}  /*nouveau score min*/
	    }
	}                                  /* � la fin on a les 8 meilleures des nmum*/
      
      /* Ins�rer un tri sur best_pars[k] et score[k], 1<=k<=8 */
      sort2(8,score,best_pars);
      deltamax=score[8];
      delta1=deltamax;
      delta2=score[7]-deltamax;
      if(io==1) { 
	if (best_pars[8]==kidpar[i].g1 || best_pars[8]==kidpar[i].g2) {deltatrue[iii]=delta1; iii+=1;} 
	else { deltawrongi[jjj]=delta1; jjj+=1;}
	if (best_pars[7]==kidpar[i].g1 || best_pars[7]==kidpar[i].g2) {deltatrue[iii]=delta2; iii+=1;}
	else deltawrongi[jjj]=delta2; jjj+=1;}
      if (io==2) { deltawrongo1[i]=delta1; deltawrongo2[i]=delta2; } 
      
      
      /*Compteur bd, md*/     
      if (io==1)
	for (k=8;k>=7;--k)    
	  {
	    bp=best_pars[k];
	    if (bp==kidpar[i].g1 || bp==kidpar[i].g2)     
	      {
	      if (score[k]>0.000000 ) bdp+=1; 
	      }      		    
	    else  
	      {
		if (score[k]>0.000000 ) mdp+=1;
	      }    
	  }    
      
      k=8; bestp1[i]=score[k]  ;
      k=7; bestp2[i]=score[k]  ;
      
      /* Affichage */
      /*   	 printf ("\n best parents and their scores:\n");        */
      /*        	for (k=8; k>=1; --k) printf ("\t %.0f",best_pars[k]); printf ("\n");        */
      /*        	for (k=8; k>=1; --k) printf ("\t %.2f",score[k]); fflush(stdout);  */     
      
      
      /* Calcul des vraisemblances pour les meilleurs couples*/
      pc=1.0E6; for (k=0; k< 11; ++k)  pcore[k]=0.0; 
      for (j=1; j<=npop; ++j)
	{
	  tp1 = listp[j];
	  if (npop > 0)
	    {
	      for (kk=1; kk<=npop; ++kk)
		{
		  tp2 = listp[kk];
		  if (tp2>=tp1)
		    {
		      cc = pparchk_dom(nloc-cyt,kidgen[i],pargen[tp1],pargen[tp2], pf, E, F); /*dans boucle en j*/
		      if (cyt > 0) cc+=likr_pair_cyt(cyt, kidcyt[i],parcyt[tp1],parcyt[tp2], pfc, E, nallc);
		      if (cc > 0.0 && finite(cc)==1) 
			{
			  ++npopp; 
			  if (npopp < 9) 
			    {
			      best_pairs[0][npopp] = name_par[tp1]; 
			      best_pairs[1][npopp] = name_par[tp2]; 
			      pcore[npopp]=cc; 
			      if (cc < pc)  pc = cc; 
			    } 
			  else
			    {
			      if (cc > pc) 
				{
				  k = dexmin(pcore, 8);
				  best_pairs[0][k] = name_par[tp1]; 
				  best_pairs[1][k] = name_par[tp2]; 
				  pcore[k] = cc;
				  pc = valmin(pcore, 8); 
				}
			    }
			}/* printf ("\n pc: %f \t",pc); */ 
		    }
		}
	    }
	} 
      /* Tri*/
      
      sort3(8,pcore,best_pairs[0],best_pairs[1]);			
      
      
      /* Compteur bd, md*/
      
      k=8;
      bc1=best_pairs[0][k]; bc2= best_pairs[1][k];    
      deltamax=pcore[8];
      delta1= deltamax; /*delta of the first most likely parent pair*/
      delta2= pcore[7]-deltamax; /*delta of the second most likely parent pair*/
      if (io==1)
	if ((bc1==kidpar[i].g1 && bc2==kidpar[i].g2) || (bc1==kidpar[i].g2 && bc2==kidpar[i].g1)) {
	    if ( pcore[k]>0.000000 )bdc+=1;
	  }    
	else {
	    if (pcore[k]>0.000000 ) mdc+=1;
	  }    
      
      
      /*Calcul du score du vrai couple*/
      
      /*        for (k=1;k<=npar;++k) {if (name_par[k]==kidpar[i].g1)  k1=k;}  */
      /*          for (k=1;k<=npar;++k) {if (name_par[k]==kidpar[i].g2) k2=k;}   */
      /*  printf("\nparent 1 %d\n", name_par[k1]); print_geno(pargen[k1]); */
      /*  cc1 = uparchk(kidgen[i],pargen[k1]); */
      /* printf ( " score parent 1 %f \n",cc1); */
      /*  printf("parent 2 %d\n", name_par[k2]); print_geno(pargen[k2]); */
      /*  cc2 = uparchk(kidgen[i],pargen[k2]); */
      /* printf ( " score parent 2 %f \n",cc2); */
      /*   cc3 = pparchk(kidgen[i],pargen[k1],pargen[k2]); */
      /*           if ( g != NULL) f printf ( " score couple %f \n",cc3); */
      /*   cc4 = pparchk(kidgen[i],pargen[k2],pargen[k1]); */
      /*           if ( g != NULL) f printf ( " score couple %f \n",cc4); */
      
      
      /* Affichage des meilleurs*/
      
      /* 	printf ("\n best pairs and their scores:\n");        */
      /*      	for (k=8; k>=1; --k) printf (" (%3.0f  %3.0f)",best_pairs[0][k], best_pairs[1][k]); */
      /*         printf ("\n"); */
      /*         for (k=8; k>=1; --k) printf ("  %-9.2f",pcore[k]);        */
      /*         printf ("\n");    */
      k=8;
      bestc[i]=pcore[k];
    }
  printf("\n End of calculation step \n");
  if (io==1)
    {
      x=bdp;
      y=2*nkid;
      bdpf=100*x/y;
      x=bdc;
      y=nkid;
      bdcf=100*x/y;
      printf("\n The two most likely parents are the right parents %d times over 2*%d simulated offspring (%.2f %%)",bdp,nkid,bdpf); 
      printf("\n");
      printf("\n The most likely parent pair is the right parent pair in %d simulations (%.2f %%)",bdc,bdcf); 
    }
  for (i=1; i<=nkid; i++) *(bestp+i)=*(bestp1+i);
  for (i=nkid+1; i<=2*nkid; i++) *(bestp+i)=*(bestp2+(i-nkid)) ;
  
  hist1(bestp, 2*nkid, name1);
  hist1(bestc, nkid, name2);  
  if (io==1) {
    hist1(deltatrue, (iii-1), name3);
    hist1(deltatrueC, 2*nkid, name4);
  }
  
  for (i=1; i<=2*nkid; ++i) deltawrong[i]=deltawrongi[i];
  for (i=1; i<=2*nkid; ++i) deltawrongC[i]=deltawrongiC[i];
  for (i=2*nkid+1; i<=3*nkid; ++i)  deltawrong[i]=deltawrongo1[i-2*nkid];
  for (i=3*nkid+1; i<=4*nkid; ++i)  deltawrong[i]=deltawrongo2[i-3*nkid];
  for (i=2*nkid+1; i<=3*nkid; ++i)  deltawrongC[i]=deltawrongo1C[i-2*nkid];
  for (i=3*nkid+1; i<=4*nkid; ++i)  deltawrongC[i]=deltawrongo2C[i-3*nkid];
  
  if (io==2) {
    hist1(deltawrong, 4*nkid, name5);
    hist1(deltawrongC, 4*nkid, name6);
  }  
  printf("\n");

  return(0);
          
}






