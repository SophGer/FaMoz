
#include <math.h>
#include <stdio.h>
#include "nrutil.h" 
#include "sort.h"
#include "read.h"
#include "genetic.h"

/**************************************************************************

Program to compute exclusion probabilities for parent and parent-pair
relationships, over a set of loci, given allele frequencies.

Modified from earlier programs; June 1996

17/5/99
Nettoy� pour tourner plus vite... Probas d'exclusion d'un parent l'autre �tant
connu, d'un seul parent ou d'un couple de parents � partir des fr�quences 
all�liques pour un marqueur codominant.

Voici le programme exclude.c un peu revu,
j'ai arrange un peu (a ma facon) la 
presentation... c'est du style mais ca ma 
permis de voir que les parantheses autour de 
*pf1 n'etaint pas bien placees,
par ailleurs j'ai refais de pf et nall un var locale
a main... comme elles sont passes en argument
c'est pas  la peine de les garder en global... 

j'ai teste avec un petit fichier data que je me suis cree...
et pour le quel ca marche....

***************************************************************************/

/*#define NL 15   number of loci +1 */ 
/*#define NA 40   max number of alleles +1 */ 


extern double rans();
extern double pow();
			

/* lit les donn�es pour chaque locus et chaque all�le, taper, nb_locus nb_all_loc1
 freq_all1_loc1 freq_all2_loc1 nb_all_loc2 freq_all1_loc2, etc...*/

main (int argc, char *argv[])
{
  int i,j; 
  double pp, a2, a3, a4, a5, a6, pater, unseulpar, couple, pcum, uncum, coucum;
  int nloc, *nall, cyt, *nallc;                       /* nb locus, number of alleles / idem cytoplasmic */
  double **pf, **pfc;                           /* loci details */
  double *probex[4], procyt, pairprocyt, cumcyt, paircumcyt;               
    /*this array will contain the locus n� in [0] and the 3 exclusion probabilities */

  cyt=atoi(argv[1]);

  scanf ("%d", &nloc);        
  printf("Number of loci: %d \n",nloc);
  printf("Among them, cytoplasmic markers: %d \n",cyt);
  nall=(int *)malloc((nloc+1)*sizeof(int));
  if (cyt > 0) nallc=(int *)malloc((cyt+1)*sizeof(int));

  read_loci (nloc, nall, &pf, cyt, nallc, &pfc); 

  for  (j=0; j<=3; ++j) probex[j] =(double *)malloc((nloc-cyt+1)*sizeof(double));

  pater = 0.0; unseulpar=0.0; couple=0.0;
  pcum=1; uncum=1; coucum=1; cumcyt=1; paircumcyt=1;
 
  for (j=1; j<=nloc-cyt; ++j) {
    a2 = 0.0; a3 = 0.0; a4 = 0.0; a5 = 0.0; a6 = 0.0;
    for (i=1; i<=nall[j]; ++i)
      {
	pp = pf[j][i];
	a2 += pow(pp,2);       a3 += pow(pp,3);
	a4 += pow(pp,4);       a5 += pow(pp,5);
	a6 += pow(pp,6);
      }
    pater = 1 - 2*a2 + a3 +2*a4 -3*a5 -2*a2*a2 + 3*a2*a3; 
    pcum*=(1-pater);
    unseulpar = 1 - 4*a2 + 2*a2*a2 + 4*a3 - 3*a4; 
    uncum*=(1-unseulpar);
    couple = 1 + 4*a4 - 4*a5 - 3*a6 - 8*a2*a2 + 8*a2*a3 + 2*a3*a3; 
    coucum*=(1-couple);

    printf("\nExclusion at locus %d:\n", j);
    printf("Exclusion probabilities: \n");
    printf("\tsingle parent: \tpaternity: \tpair parents:\n \t%f \t%f \t%f", unseulpar, pater, couple);
    /* Store locus number */
    probex[0][j]=j;  
    /* Store probabilities */
    probex[1][j]=unseulpar;   
    probex[2][j]=pater;
    probex[3][j]=couple;
    printf("\nCumulative probabilities: \n");
    printf("\tsingle parent: \tpaternity: \tpair parents: \n \t%f \t%f \t%f",(1-uncum),(1-pcum),(1-coucum));
    printf("\n");
  }
  printf("\n\nCumulated probabilities over all loci: \n");
  printf("\tsingle parent: \tpaternity: \tpair parents: \n \t%f \t%f \t%f", (1-uncum),(1-pcum),(1-coucum)); 

  /* Sort probabilities by single parent exclusion (probex[1])*/
  sort4(nloc-cyt, probex[1], probex[0], probex[2], probex[3]);

  printf("\n\nLoci sorted by decreasing exclusion probabilities: \n");
  printf("Locus n�: \tsingle parent: \tpaternity: \tparent pair:\n");
  for (i=nloc-cyt;i>=1;--i)
    printf("\n\t %.0f \t%f \t%f \t%f", probex[0][i], probex[1][i], probex[2][i], probex[3][i]);

  printf("\n\nCumulated exclusions: \n");
  printf("Locus n�: \tsingle parent: \tpaternity: \tparent pair:\n");
  pcum=1; uncum=1; coucum=1;
  for (i=nloc-cyt;i>=1;--i)
    {    
      uncum*=(1- probex[1][i]);
      pcum*=(1-probex[2][i]);
      coucum*=(1-probex[3][i]);
      printf("\n\t %.0f \t%f \t%f \t%f", probex[0][i], (1-uncum), (1-pcum), (1-coucum));
    }

  /* Exclusion probabilities for cytoplasmic markers */
  if (cyt > 0)
    {
      for (i=1; i<=cyt; ++i) 
	{
	  procyt=0;
	  pairprocyt=0;
	  for (j=1; j<=nallc[i]; ++j)
	    {
	      pp = pfc[i][j];
	      procyt+=pp*(1-pp);
	      pairprocyt+=pp*(1-pp)*(1-pp);
	    }
	  
	  cumcyt*=(1-procyt);
	  paircumcyt*=(1-pairprocyt);
	}
      printf("\n\n Exclusion probability at cytoplasmic marker: ");
      printf("\n Single parent: \t%f\n", 1-cumcyt);
      printf(" Pair of parents: \t%f\n", 1-paircumcyt);

      printf("\n\n Total exclusion probabilities (nuclear and cytoplasmic markers): \n");
      printf(" Single parent: \t%f\n", 1-uncum*cumcyt);
      printf(" Pair of parents: \t%f\n", 1-coucum*paircumcyt);
    }
  
  return(0);
  
}

/*   -------------  CUT HERE ------------------------*/

/*  exemlpe de data  */

/* 20 */
/* 2 0.95 0.05 3 0.94 0.03 0.03 3 0.94 0.03 0.03 3 0.94 0.03 0.03 */
/* 2 0.95 0.05 3 0.94 0.03 0.03 3 0.94 0.03 0.03 3 0.94 0.03 0.03 */
/* 2 0.95 0.05 3 0.94 0.03 0.03 3 0.94 0.03 0.03 3 0.94 0.03 0.03 */
/* 2 0.95 0.05 3 0.94 0.03 0.03 3 0.94 0.03 0.03 3 0.94 0.03 0.03 */
/* 2 0.95 0.05 3 0.94 0.03 0.03 3 0.94 0.03 0.03 3 0.94 0.03 0.03 */

/************************************************************/


