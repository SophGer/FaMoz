
#include <math.h>
#include <stdio.h>
#include "nrutil.h"
#include "sort.h"
#include "read.h"

/**************************************************************************

Calcul des probas d'exclusion pour des locus dominants (proba d'excl d'une
paire de parents, d'un parent l'autre �tant connu). La proba d'exclusion
d'un parent seul est nulle.
Adapted to FaMoz.tcl
entry file :
number_of_bands freq_band1 freq_band2 ....
where freq_band = square_root(frequency_absence_of_the_band_phenotype)
***************************************************************************/

main (int argc, char *argv[])
{   
  int i,j, nloc, cyt, *nall; 
  double pair, pater, *paircum, *patcum, p, *pf, **pfc, patcu, paircu, procyt, cumcyt, pairprocyt, paircumcyt;
  double *probex[3], pp;               
  /*this array will contain the locus n� in [0] and the 2 exclusion probabilities */
  
  cyt=atoi(argv[1]);

  /*  printf("entrez nb_bandes freq_bande1 freq_bande2...\n"); */	
  scanf ("%d", &nloc);

  pf=(double *)malloc((nloc+1) * sizeof(double));
  paircum=(double *)malloc((nloc-cyt+1) * sizeof(double));
  patcum=(double *)malloc((nloc-cyt+1) * sizeof(double));
  for  (j=0; j<=2; ++j) probex[j] =(double *)malloc((nloc-cyt+1)*sizeof(double));

  if (cyt > 0) nall=(int *)malloc((cyt+1)*sizeof(int));

  read_loci_dom (nloc, cyt, nall, pf, &pfc);
  printf("\n Number of loci: %d ",nloc);
  printf("\n Among them, cytoplasmic markers: %d \n",cyt);
  paircum[0] = 1.0; patcum[0] =1.0; cumcyt=1; paircumcyt=1;
  /* 	for (k=0; k<=4; ++k) */
  /* 		{  txu[k] = 1.0; txuu[k] = 1.0; txqu[k] =1.0; } */
  
  for (j=1; j<=nloc-cyt; ++j)
    {
      /*  printf("\n locus j : %d \n", j); */        
      p = pf[j];
      pair = p*(1-p)*(1-p)*(1-p)*(1-p)*(2-p); /* exclusion d'une paire de parents pour le locus */  
      paircum[j] = paircum[j-1]*(1.0 - pair); /* exclusion cumul�e d'une paire de parents*/  
      /*   printf("cuu : %f\n",cuu); */
      pater = p*(1-p)*(1-p)*(1-p)*(1-p) ;  /*exclusion de paternit� pour le locus*/
      patcum[j]= patcum[j-1]*(1.0 - pater);      /*exclusion cumul�e de paternit�*/

      /* Store locus number */
      probex[0][j]=j;  
      /* Store probabilities: first paternity, second pair exclusion*/
      probex[1][j]=pater;   
      probex[2][j]=pair;

      /*  printf("cqu : %f\n",cqu); */
      /*  printf("\n exclusion at autosomal locus %d : */
      /*\n exclusion d'une paire de parents possible : \t %f */
      /*\n exclusion d'un parent, l'autre �tant connu : \t %f", j, cuu, cqu );  */      
      /*    printf(" %d ", j); */   /*  locus */      
      /*   printf(" %f ", cuu );  */    /*  paire  */      
      /*  printf(" %f ", cqu ); */    /*  paternit� */
      
    }
  printf("\n Single locus exclusion probabilities:\n");
  printf(" Locus n�: \n");    
  for (j=1; j<=nloc-cyt; ++j) printf("\t%8d",j);
  printf("\n");    
  printf(" Paternity: \n");    
  for (j=1; j<=nloc-cyt; ++j) printf("\t%8.5f",(probex[1][j]));
  printf("\n");   
  printf(" Pair: \n");    
  for (j=1; j<=nloc-cyt; ++j) printf("\t%8.5f",(probex[2][j]));
  printf("\n");   
  
  printf("\n Single locus exclusion cumulated probabilities:\n");
  printf(" Locus n�: \n");    
  for (j=1; j<=nloc-cyt; ++j) printf("\t%8d",j);
  printf("\n");    
  printf(" Paternity: \n");    
  for (j=1; j<=nloc-cyt; ++j) printf("\t%8.5f",(1-patcum[j]));
  printf("\n");   
  printf(" Pair: \n");    
  for (j=1; j<=nloc-cyt; ++j) printf("\t%8.5f",(1-paircum[j]));
  printf("\n");   
  
  printf("\n Overall exclusion probabilities:\n paternity:\t\t%8.5f \n pair of parents:\t%8.5f\n", (1.0-patcum[nloc-cyt]), (1.0- paircum[nloc-cyt]) ); 
  
  printf("\n"); 
 
  /* Sort probabilities by paternity exclusion (probex[1])*/
  sort3(nloc-cyt, probex[1], probex[0], probex[2]);

  printf("\n\nLoci sorted by decreasing exclusion probabilities: \n");
  printf("Locus n�: \tpaternity: \tparent pair:\n");
  for (i=nloc-cyt;i>=1;--i)
    printf("\n\t %.0f \t%8.5f \t%8.5f", probex[0][i], probex[1][i], probex[2][i]);

  printf("\n\nCumulated exclusions: \n");
  printf("Locus n�: \tpaternity: \tparent pair:\n");
  patcu=1; paircu=1;
  for (i=nloc-cyt;i>=1;--i)
    {    
      patcu*=(1- probex[1][i]);
      paircu*=(1-probex[2][i]);
      printf("\n\t %.0f \t%8.5f \t%8.5f", probex[0][i], (1-patcu), (1-paircu));
    }

  /* Exclusion probabilities for cytoplasmic markers */
  if (cyt > 0)
    {
      for (i=1; i<=cyt; ++i) 
	{
	  procyt=0;
	  pairprocyt=0;
	  for (j=1; j<=nall[i]; ++j)
	    {
	      pp = pfc[i][j];
	      procyt+=pp*(1-pp);
	      pairprocyt+=pp*(1-pp)*(1-pp);
	    }
	  
	  cumcyt*=(1-procyt);
	  paircumcyt*=(1-pairprocyt);
	}
      printf("\n\n Exclusion probabilities at cytoplasmic marker: ");

      printf("\n Paternity: \t%f\n", 1-cumcyt);
      printf(" Pair of parents: \t%f\n", 1-paircumcyt);

      printf("\n\n Total exclusion probabilities (nuclear and cytoplasmic markers): \n");
      printf(" Paternity: \t%f\n", 1-patcum[nloc-cyt]*cumcyt);
      printf(" Pair of parents: \t%f\n", 1-paircum[nloc-cyt]*paircumcyt);

    }
  return(0);
  

}
