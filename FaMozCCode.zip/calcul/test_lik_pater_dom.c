#include <math.h>
#include <stdio.h>
#include "nrutil.h"
#include "read.h"
#include "sort.h"
#include "genetic.h"
#include "likely.h"

/**************************************************************************
31/10/00 Calculate father likelihood for dominant markers
21/01/03 Makes paternity test with a given threshold
***************************************************************************/

extern double rans();


main (int argc, char *argv[])
{
  int nloc, i,j,k, ii, jj, kk, *nallc, test_type;  
  int nkid,npar, npod, nb, mere, cyt, cytmater, nb_off_fath, *fath;
  int *name_mum, *name_kid, *name_par, **kidgen, **pargen, **kidcyt, **parcyt;
  double  E, F, SEUIL_P, SEUIL_d, *pf, **pfc, *best_dads, *miss_dad, *missm_dad, *loclod, *delta, deltamax; 
  /* nb missing data and missmatch for each dad and dad/offsp and number of loci with no missing data*/
  double *score, cc, bc;
  FILE *f;

  E=atof(argv[1]);
  nb=atoi(argv[2]);
  cyt=atoi(argv[3]);
  cytmater=atoi(argv[4]);
  F=atof(argv[5]);
  test_type=atoi(argv[6]); /* test type 1: test on lod scores 2: test on delta 3: test on both values*/
  if (test_type==1)
    SEUIL_P=atof(argv[7]);  /* Lod-score threshold to choose a father as the true one */
  else if  (test_type==2)
    SEUIL_d=atof(argv[7]);  /* Delta threshold to choose a father as the true one */
  else if  (test_type==3){
    SEUIL_P=atof(argv[7]);  /* Lod-score threshold to choose a father as the true one */
    SEUIL_d=atof(argv[8]);  /* Delta threshold to choose a father as the true one */
  }

  scanf ("%d", &nloc);
  pf=(double *)malloc((nloc-cyt+1) * sizeof(double));
  if (cyt > 0) nallc=(int *)malloc((cyt+1)*sizeof(int));

  read_loci_dom (nloc, cyt, nallc, pf, &pfc);

  printf("\n Number of loci: %d",nloc);
  printf(" of which %d cytoplasmic markers",cyt);
  scanf ("%d %d", &npar, &nkid);
  printf ("\n Number of parents: %d offspring: %d\n", npar,nkid);
  printf("\n Lod calculation error %f, Heterozygote deficit %f\n", E, F);    
  if (test_type==1) 
    printf("\n Lod-score threshold to choose a father as the true one = %.2f ", SEUIL_P);
  else if (test_type==2) 
    printf("\n Delta threshold to choose a father as the true one = %.2f ", SEUIL_d);
  else if (test_type==3) 
    printf("\n Thresholds to choose a father as the true one Lod-score = %.2f Delta = %.2f\n", SEUIL_P, SEUIL_d);
  printf("\n Number of best fathers displayed: %d\n", nb); 
  printf("\n For each likely father: "); 
  printf ("\n -Nb of missing locus in father / nb of loci with a > 0 contribution in score ");
  printf("\n  / nb of father-offspring mismatch among them\n");

  name_kid=(int *)malloc((nkid+1)*sizeof(int));
  name_par=(int *)malloc((npar+1)*sizeof(int));
  name_mum=(int *)malloc((nkid+1)*sizeof(int));
  kidgen=(int **)malloc((nkid+1) * sizeof(int *));
  pargen=(int **)malloc((npar+1) * sizeof(int *));
  best_dads=(double *)malloc((nb+2)*sizeof(double));
  score=(double *)malloc((nb+2)*sizeof(double));
  delta=(double *)malloc((nb+2)*sizeof(double));
  miss_dad=(double *)malloc((nb+2)*sizeof(double));
  missm_dad=(double *)malloc((nb+2)*sizeof(double));
  loclod=(double *)malloc((nb+2)*sizeof(double));
  kidcyt=(int **)malloc((nkid+1) * sizeof(int *));
  parcyt=(int **)malloc((npar+1) * sizeof(int *));
  fath=(int *)malloc((nkid+1) * sizeof(int));

  for (i=1; i<=nkid; i++)
    {
      fath[i]=0;
      kidgen[i]=(int *)malloc((nloc+1) * sizeof(int));      
      kidcyt[i]=(int *)malloc((cyt+1) * sizeof(int));
    }
  for (i=1; i<=npar; i++)
    {
      pargen[i]=(int *)malloc((nloc+1) * sizeof(int));  
      parcyt[i]=(int *)malloc((cyt+1) * sizeof(int));
    }
    

  read_gen_dat_pat_dom (npar, nkid, name_kid, name_par, name_mum, nloc, cyt, kidgen, pargen, kidcyt, parcyt);

  f = fopen ("resfath", "w");  
  printf("\n ***** Compact results will be given in file \"resfath\"\n");
  printf("\t\t\t  (Number of observations at the end of the file)\n");
  nb_off_fath=0; 

  /* Recherche des p�res  les plus probables*/
  for (i=1; i<=nkid; ++i)
    {
      printf ("\n kid %d, mother %d: ", name_kid[i], name_mum[i]);
      printf("( %.0f missing locus on %d nuclear loci)\n", missing_dom(kidgen[i],(nloc-cyt)),(nloc-cyt));  
      npod=0; bc=1.0E6; /* Number Possible fathers */
      for (k=0; k< nb+1; ++k) 
	{
	  best_dads[k] =0; 
	  score[k]=0.0;
	  delta[k]=0.0;
	  miss_dad[k] =0; 
	  missm_dad[k] =0; 
	  loclod[k] =0;
	}
      
      for (j=1; j<=npar; ++j)
	{
	  for (ii=1;ii<=npar;++ii) 
	    {
	      if (name_par[ii]==name_mum[i]) mere=ii; 
	    }
	  cc = pater_dom((nloc-cyt), kidgen[i],pargen[mere],pargen[j], pf, E, F); /* proba father:non father*/
	  if (cyt > 0 && cytmater==0) cc+=likr_pat_cyt(cyt, kidcyt[i], parcyt[j], pfc, E, nallc);
	  /*           printf("\n score : %f",cc); */
	  if (cc > 0.0 && finite(cc)==1) 
	    { 
	      ++npod; 
	      if (npod < nb +1) 
		{
		  best_dads[npod] = name_par[j]; 
		  score[npod]=cc; 
		  miss_dad[npod]=missing_dom(pargen[j], (nloc-cyt));
		  missm_dad[npod]=mismatch2_dom(kidgen[i], pargen[mere], pargen[j],(nloc-cyt));
		  loclod[npod]=loc_lod_pater_dom((nloc-cyt), kidgen[i], pargen[mere], pargen[j], pf, E, F);		  
		  if (cc < bc)  bc = cc; 
		} /* bc sera le score min parmi les 8 premiers >0 */
	      else
		{
		  if (cc > bc) /*score sup�rieur au min pr�c�dent*/
		    { 
		      k = dexmin(score, nb); /* rang du score minimum parmi les nb*/
		      best_dads[k] = name_par[j];  /*on remplace le p�re k  ...  */
		      score[k] = cc;               /* par le j, qui est meilleur */ 
		      miss_dad[k]=missing_dom(pargen[j], (nloc-cyt));
		      missm_dad[k]=mismatch2_dom(kidgen[i], pargen[mere], pargen[j],(nloc-cyt));
		      loclod[k]=loc_lod_pater_dom((nloc-cyt), kidgen[i], pargen[mere], pargen[j], pf, E, F);		  
		      bc = valmin(score, nb); 
		    }
		}  /*nouveau score min*/
	    }
	}
      /* � la fin on a les nb meilleurs p�re */
      
      /* Ins�rer un tri sur best_dads[k] et score[k], 1<=k<=nb */
      sort5(nb,score,best_dads,miss_dad, missm_dad, loclod);			
      deltamax=score[nb];
      for (k=nb; k>=1; --k){ if (k==nb) delta[k]=deltamax; else if (k<nb && score[k]>0) delta[k]=deltamax-score[k];}
      

     /* Affichage */
      jj=0;
      kk=0;
      for (k=nb; k>=1; --k) {
	if (test_type==1){
	  if (score[k] > SEUIL_P) {
	    ++jj;
	    printf ("\tLikely father n� %d: %5.0f\tscore:  %5.2f",jj, best_dads[k], score[k]);
	    printf ("\t %3.0f/%3.0f/%3.0f", miss_dad[k], loclod[k], missm_dad[k]);  printf ("\n"); 
	    if (kk==0)  { fath[i] = best_dads[k]; kk+=1;} 
	  }
	}  
	else if (test_type==2){
	  if (delta[k] > SEUIL_d) {
	    ++jj;
	    printf ("\tLikely father n� %d: %5.0f\tdelta:  %5.2f",jj, best_dads[k], delta[k]);
	    printf ("\t %3.0f/%3.0f/%3.0f", miss_dad[k], loclod[k], nloc-cyt-missm_dad[k]);  printf ("\n"); 
	    if (kk==0)  { fath[i] = best_dads[k]; kk+=1;} 
	  }
	}
	else if (test_type==3){
	  if (score[k] > SEUIL_P && delta[k] > SEUIL_d) {
	    ++jj;
	    printf ("\tLikely father n� %d: %5.0f\tlod score:  %5.2f\tdelta:  %5.2f",jj, best_dads[k], score[k],delta[k]);
	    printf ("\t %3.0f/%3.0f/%3.0f", miss_dad[k], loclod[k], nloc-cyt-missm_dad[k]);  printf ("\n"); 
	    if (kk==0)  { fath[i] = best_dads[k]; kk+=1;} 
	  }
	}
	if (jj!=0)  nb_off_fath+=1;  
	if (jj==0) printf ("\tNo likely father inside the stand\n");	      
	
	fflush(stdout);    
      
      }
    }
  printf("\n Among %d offspring, %d have one father among the genotyped one", nkid, nb_off_fath);
  printf ("\n");
  
  for (i=1; i<=nkid; i++) 
    if ( f != NULL && fath[i]!=0) fprintf (f, "\n %d %d", name_kid[i], fath[i]);
  if ( f != NULL) fprintf (f, "\n %d ", nb_off_fath);  
  
  fclose(f);
  return(0); 
}
